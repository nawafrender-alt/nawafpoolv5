#!/data/data/com.termux/files/usr/bin/bash
set -eu

if [ -z "${PREFIX:-}" ] || ! command -v pkg >/dev/null 2>&1; then
    echo "شغّل هذا الملف من تطبيق Termux."
    exit 1
fi

SDK_ROOT="$HOME/android-sdk"
GRADLE_VERSION="8.7"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "تثبيت متطلبات Termux..."
pkg update -y
pkg install -y openjdk-21 wget unzip aapt aapt2
termux-setup-storage

if [ -d "$PREFIX/lib/jvm/java-21-openjdk" ]; then
    export JAVA_HOME="$PREFIX/lib/jvm/java-21-openjdk"
    export PATH="$JAVA_HOME/bin:$PATH"
fi

if ! command -v java >/dev/null 2>&1; then
    echo "لم أجد Java بعد التثبيت. أغلق Termux وافتحه ثم أعد تشغيل الملف."
    exit 1
fi

SDKMANAGER="$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
if [ ! -x "$SDKMANAGER" ]; then
    DOWNLOADS="$HOME/storage/downloads"
    SDK_ZIP=""
    if [ -d "$DOWNLOADS" ]; then
        SDK_ZIP="$(find "$DOWNLOADS" -maxdepth 1 -type f -name 'commandlinetools-linux-*_latest.zip' -print -quit 2>/dev/null || true)"
    fi

    if [ -z "$SDK_ZIP" ]; then
        echo
        echo "نزّل Android Command-line Tools (Linux) وضع ملف ZIP في مجلد Downloads:"
        echo "https://developer.android.com/studio#command-line-tools-only"
        if command -v termux-open-url >/dev/null 2>&1; then
            termux-open-url "https://developer.android.com/studio#command-line-tools-only"
        fi
        echo "بعد التنزيل، شغّل هذا الملف مرة أخرى."
        exit 1
    fi

    echo "إعداد Android SDK..."
    TEMP_DIR="$(mktemp -d)"
    unzip -q "$SDK_ZIP" -d "$TEMP_DIR"
    if [ ! -f "$TEMP_DIR/cmdline-tools/bin/sdkmanager" ]; then
        rm -rf "$TEMP_DIR"
        echo "لم أجد sdkmanager داخل الملف الذي تم تنزيله."
        exit 1
    fi
    mkdir -p "$SDK_ROOT/cmdline-tools/latest"
    cp -R "$TEMP_DIR/cmdline-tools/." "$SDK_ROOT/cmdline-tools/latest/"
    rm -rf "$TEMP_DIR"
fi

export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export PATH="$SDK_ROOT/cmdline-tools/latest/bin:$SDK_ROOT/platform-tools:$PATH"

echo "تثبيت Android SDK 34 وتراخيصه..."
"$SDKMANAGER" --sdk_root="$SDK_ROOT" "platform-tools" "platforms;android-34" "build-tools;34.0.0"
yes | "$SDKMANAGER" --sdk_root="$SDK_ROOT" --licenses

echo "إعداد aapt2 الخاص بـ Termux..."
mkdir -p "$HOME/.gradle"
GRADLE_PROPERTIES="$HOME/.gradle/gradle.properties"
if grep -q '^android.aapt2FromMavenOverride=' "$GRADLE_PROPERTIES" 2>/dev/null; then
    sed -i "s|^android.aapt2FromMavenOverride=.*|android.aapt2FromMavenOverride=$PREFIX/bin/aapt2|" "$GRADLE_PROPERTIES"
else
    printf '\nandroid.aapt2FromMavenOverride=%s/bin/aapt2\n' "$PREFIX" >> "$GRADLE_PROPERTIES"
fi

GRADLE_HOME="$HOME/.gradle/gradle-$GRADLE_VERSION"
if [ ! -x "$GRADLE_HOME/bin/gradle" ]; then
    echo "تنزيل Gradle $GRADLE_VERSION..."
    TEMP_DIR="$(mktemp -d)"
    wget -q --show-progress "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -O "$TEMP_DIR/gradle.zip"
    unzip -q "$TEMP_DIR/gradle.zip" -d "$HOME/.gradle"
    rm -rf "$TEMP_DIR"
fi

echo "بناء APK..."
cd "$PROJECT_DIR"
"$GRADLE_HOME/bin/gradle" assembleDebug --no-daemon

APK="$PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"
if [ ! -f "$APK" ]; then
    echo "انتهى Gradle لكن ملف APK غير موجود في المسار المتوقع."
    exit 1
fi

DEST="$HOME/storage/downloads/PoolOverlay-debug.apk"
mkdir -p "$(dirname "$DEST")"
cp "$APK" "$DEST"
echo "اكتمل البناء: $DEST"
echo "إذا لم يظهر مثبت Android تلقائيًا، افتح الملف من Downloads."
if command -v termux-open >/dev/null 2>&1; then
    termux-open "$DEST" || true
fi
