package com.pooloverlay.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Shot planner: straight pots, one-cushion banks, kick shots (cue ball off a cushion first), break and a safe fallback. */
final class PoolPlanner {
    static final int DIRECT = 0, BANK = 1, KICK = 2, TOUCH = 3, BREAK = 4;

    static final class Plan {
        int type;
        PoolVision.Ball target;
        float cx, cy;                 // cue ball
        float kx, ky; boolean hasK;   // cue ball cushion point (kick)
        float gx, gy;                 // where the cue ball must touch the object ball (ghost ball centre)
        float ox, oy;                 // object ball
        float bx, by; boolean hasB;   // object ball cushion point (bank)
        float px, py;                 // pocket
        float p;                      // rough success chance 0..1
        float ai = 1f;                // PoolSimAI quality 0..1 (geometry, reach, obstacles, robustness)
        int power;                    // 20..100
        float cut;                    // degrees
        boolean scratchRisk;
        String note = "";
    }

    // group: 0 = any, 1 = solids, 2 = stripes, 3 = 8-ball
    static List<Plan> plan(PoolVision.Scene s, int group, boolean full, PoolMemory memory) {
        List<Plan> out = new ArrayList<>();
        if (!s.ok || s.cue == null) return out;
        final float R = s.R;
        final float Lc = s.L + R, Rc = s.Rt - R, Tc = s.T + R, Bc = s.B - R;
        final float len = Math.max(s.Rt - s.L, s.B - s.T);
        final float cx = s.cue.x, cy = s.cue.y;

        if (s.rack) {                                        // break: hit the front ball of the triangle squarely
            PoolVision.Ball apex = null; float bd = 1e9f;
            for (PoolVision.Ball b : s.balls) {
                if (b == s.cue) continue;
                float d = (float) Math.hypot(b.x - cx, b.y - cy);
                if (d < bd) { bd = d; apex = b; }
            }
            if (apex != null) {
                Plan p = new Plan();
                p.type = BREAK; p.target = apex;
                p.cx = cx; p.cy = cy; p.ox = apex.x; p.oy = apex.y;
                float dx = apex.x - cx, dy = apex.y - cy, dl = (float) Math.hypot(dx, dy);
                p.gx = apex.x - dx / dl * 2 * R; p.gy = apex.y - dy / dl * 2 * R;
                p.px = apex.x; p.py = apex.y;
                p.p = 0.9f; p.power = 100; p.note = "كسر: ضربة قوية على رأس المثلث";
                out.add(p);
                return out;
            }
        }

        List<PoolVision.Ball> targets = new ArrayList<>();
        int solids = 0, stripes = 0;
        for (PoolVision.Ball b : s.balls) { if (b.kind == PoolVision.SOLID) solids++; if (b.kind == PoolVision.STRIPE) stripes++; }
        for (PoolVision.Ball b : s.balls) {
            if (b == s.cue) continue;
            boolean ok;
            switch (group) {
                case 1: ok = b.kind == PoolVision.SOLID || (solids == 0 && b.kind == PoolVision.EIGHT); break;
                case 2: ok = b.kind == PoolVision.STRIPE || (stripes == 0 && b.kind == PoolVision.EIGHT); break;
                case 3: ok = b.kind == PoolVision.EIGHT; break;
                default: ok = b.kind != PoolVision.EIGHT || (solids + stripes == 0);
            }
            if (ok) targets.add(b);
        }

        float slack = 0.3f * R;
        for (PoolVision.Ball o : targets) {
            for (int pi = 0; pi < 6; pi++) {
                float px = s.pockets[pi][0], py = s.pockets[pi][1];
                boolean side = pi >= 4;
                // ---------- straight pot
                float dx = px - o.x, dy = py - o.y, dl = (float) Math.hypot(dx, dy);
                if (dl > 2 * R) {
                    float ux = dx / dl, uy = dy / dl;
                    float gx = o.x - ux * 2 * R, gy = o.y - uy * 2 * R;
                    float pf = pocketFactor(s, pi, ux, uy);
                    if (pf > 0 && inside(gx, gy, Lc, Tc, Rc, Bc, slack) && clearPath(s, o, px, py, o.x, o.y, true, R)) {
                        // direct
                        float ax = gx - cx, ay = gy - cy, al = (float) Math.hypot(ax, ay);
                        if (al > 1) {
                            float cosT = (ax * ux + ay * uy) / al;
                            if (cosT > 0.17f && clearPath(s, o, gx, gy, cx, cy, false, R)) {
                                Plan p = base(DIRECT, s, o, gx, gy, px, py);
                                p.cut = deg(cosT);
                                p.p = 0.97f * (float) Math.pow(cosT, 1.6) * (float) Math.exp(-(0.9f * al + 1.6f * dl) / len) * pf;
                                p.power = power(al + dl, len, 0);
                                scratch(s, p, ux, uy, ax / al, ay / al, R);
                                out.add(p);
                            }
                        }
                        // kick: cue ball off one cushion first, then pots straight
                        if (full) kicks(s, out, o, gx, gy, px, py, ux, uy, pf, dl, len, R, Lc, Tc, Rc, Bc);
                    }
                }
                // ---------- one-cushion bank for the object ball
                if (full) banks(s, out, o, pi, side, len, R, Lc, Tc, Rc, Bc, slack);
            }
        }

        PoolPhysics.refine(s, out, memory);
        PoolSimAI.evaluate(s, out, memory);
        Collections.sort(out, new Comparator<Plan>() {
            @Override public int compare(Plan a, Plan b) { return Float.compare(b.p, a.p); }
        });
        // keep the best few, one per (target,type)
        List<Plan> keep = new ArrayList<>();
        for (Plan p : out) {
            boolean dup = false;
            for (Plan k : keep) if (k.target == p.target && k.type == p.type) dup = true;
            if (!dup) keep.add(p);
            if (keep.size() >= 3) break;
        }
        if (keep.isEmpty() || keep.get(0).p < 0.06f) {            // nothing reasonable: touch the nearest legal ball softly
            PoolVision.Ball near = null; float bd = 1e9f;
            for (PoolVision.Ball o : targets) {
                float d = (float) Math.hypot(o.x - cx, o.y - cy);
                if (d < bd && clearPath(s, o, o.x, o.y, cx, cy, false, R)) { bd = d; near = o; }
            }
            if (near != null) {
                Plan p = new Plan();
                p.type = TOUCH; p.target = near;
                p.cx = cx; p.cy = cy; p.ox = near.x; p.oy = near.y; p.gx = near.x; p.gy = near.y;
                p.px = near.x; p.py = near.y; p.p = 0.05f; p.power = 28;
                p.note = "ما فيه إدخال مضمون — دفاع: المس أقرب كرة بخفة";
                keep.add(p);
            }
        }
        return keep;
    }

    // ------------------------------------------------------------------ banks
    private static void banks(PoolVision.Scene s, List<Plan> out, PoolVision.Ball o, int pi, boolean side, float len,
                              float R, float Lc, float Tc, float Rc, float Bc, float slack) {
        float px = s.pockets[pi][0], py = s.pockets[pi][1];
        float cx = s.cue.x, cy = s.cue.y;
        for (int w = 0; w < 4; w++) {                         // 0 left, 1 right, 2 top, 3 bottom cushion
            float mx, my;                                      // pocket mirrored across the cushion line
            switch (w) {
                case 0: mx = 2 * Lc - px; my = py; break;
                case 1: mx = 2 * Rc - px; my = py; break;
                case 2: mx = px; my = 2 * Tc - py; break;
                default: mx = px; my = 2 * Bc - py;
            }
            float dx = mx - o.x, dy = my - o.y;
            float t;
            if (w < 2) { float line = w == 0 ? Lc : Rc; if (Math.abs(dx) < 1e-3f) continue; t = (line - o.x) / dx; }
            else { float line = w == 2 ? Tc : Bc; if (Math.abs(dy) < 1e-3f) continue; t = (line - o.y) / dy; }
            if (t <= 0.02f || t >= 0.98f) continue;
            float hx = o.x + dx * t, hy = o.y + dy * t;
            // bounce point must be on the cushion, away from pocket mouths
            float m = 1.7f * R;
            if (hx < Lc + (w < 2 ? 0 : m) || hx > Rc - (w < 2 ? 0 : m) || hy < Tc + (w >= 2 ? 0 : m) || hy > Bc - (w >= 2 ? 0 : m)) continue;
            if (nearPocket(s, hx, hy, 1.9f * R)) continue;
            float d1 = (float) Math.hypot(hx - o.x, hy - o.y), d2 = (float) Math.hypot(px - hx, py - hy);
            if (d1 < 2.5f * R || d2 < 1.5f * R) continue;
            float ux = (hx - o.x) / d1, uy = (hy - o.y) / d1;
            float vx = (px - hx) / d2, vy = (py - hy) / d2;
            float pf = pocketFactor(s, pi, vx, vy);
            if (pf <= 0) continue;
            float gx = o.x - ux * 2 * R, gy = o.y - uy * 2 * R;
            if (!inside(gx, gy, Lc, Tc, Rc, Bc, slack)) continue;
            float ax = gx - cx, ay = gy - cy, al = (float) Math.hypot(ax, ay);
            if (al < 1) continue;
            float cosT = (ax * ux + ay * uy) / al;
            if (cosT < 0.35f) continue;
            if (!clearPath(s, o, gx, gy, cx, cy, false, R)) continue;
            if (!clearPath(s, o, hx, hy, o.x, o.y, true, R)) continue;
            if (!clearPath(s, o, px, py, hx, hy, true, R)) continue;
            Plan p = base(BANK, s, o, gx, gy, px, py);
            p.bx = hx; p.by = hy; p.hasB = true;
            p.cut = deg(cosT);
            p.p = 0.55f * (float) Math.pow(cosT, 1.6) * (float) Math.exp(-0.9f * al / len)
                    * (float) Math.exp(-(d1 + d2) / (0.9f * len)) * pf;
            p.power = power(al + d1 + d2, len, 12);
            p.note = "بنك: الكرة تضرب الجدار وترجع تدخل";
            out.add(p);
        }
    }

    // ------------------------------------------------------------------ kicks
    private static void kicks(PoolVision.Scene s, List<Plan> out, PoolVision.Ball o, float gx, float gy, float px, float py,
                              float ux, float uy, float pf, float dl, float len, float R, float Lc, float Tc, float Rc, float Bc) {
        float cx = s.cue.x, cy = s.cue.y;
        for (int w = 0; w < 4; w++) {
            float mx, my;
            switch (w) {
                case 0: mx = 2 * Lc - gx; my = gy; break;
                case 1: mx = 2 * Rc - gx; my = gy; break;
                case 2: mx = gx; my = 2 * Tc - gy; break;
                default: mx = gx; my = 2 * Bc - gy;
            }
            float dx = mx - cx, dy = my - cy, t;
            if (w < 2) { float line = w == 0 ? Lc : Rc; if (Math.abs(dx) < 1e-3f) continue; t = (line - cx) / dx; }
            else { float line = w == 2 ? Tc : Bc; if (Math.abs(dy) < 1e-3f) continue; t = (line - cy) / dy; }
            if (t <= 0.02f || t >= 0.98f) continue;
            float kx = cx + dx * t, ky = cy + dy * t;
            if (kx < Lc || kx > Rc || ky < Tc || ky > Bc) continue;
            float m = 1.7f * R;
            if (w < 2 ? (ky < Tc + m || ky > Bc - m) : (kx < Lc + m || kx > Rc - m)) continue;
            if (nearPocket(s, kx, ky, 1.9f * R)) continue;
            float d1 = (float) Math.hypot(kx - cx, ky - cy), d2 = (float) Math.hypot(gx - kx, gy - ky);
            if (d1 < 2 * R || d2 < 1.5f * R) continue;
            float ax = (gx - kx) / d2, ay = (gy - ky) / d2;
            float cosT = ax * ux + ay * uy;
            if (cosT < 0.3f) continue;
            if (!clearPath(s, o, kx, ky, cx, cy, false, R)) continue;
            if (!clearPath(s, o, gx, gy, kx, ky, false, R)) continue;
            Plan p = base(KICK, s, o, gx, gy, px, py);
            p.kx = kx; p.ky = ky; p.hasK = true;
            p.cut = deg(cosT);
            p.p = 0.30f * (float) Math.pow(cosT, 1.6) * (float) Math.exp(-(0.9f * (d1 + d2) + 1.6f * dl) / len) * pf;
            p.power = power(d1 + d2 + dl, len, 6);
            p.note = "ضرب من الجدار: الأبيض يلمس الجدار أولاً ثم الكرة";
            out.add(p);
        }
    }

    // ------------------------------------------------------------------ helpers
    private static Plan base(int type, PoolVision.Scene s, PoolVision.Ball o, float gx, float gy, float px, float py) {
        Plan p = new Plan();
        p.type = type; p.target = o;
        p.cx = s.cue.x; p.cy = s.cue.y; p.gx = gx; p.gy = gy;
        p.ox = o.x; p.oy = o.y; p.px = px; p.py = py;
        return p;
    }

    private static boolean inside(float x, float y, float l, float t, float r, float b, float slack) {
        return x >= l - slack && x <= r + slack && y >= t - slack && y <= b + slack;
    }

    private static float deg(float cos) { return (float) Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, cos)))); }

    private static int power(float total, float len, int extra) {
        float v = 18 + 82 * Math.min(1f, total / (1.35f * len)) + extra;
        return Math.max(20, Math.min(100, Math.round(v)));
    }

    static boolean nearPocket(PoolVision.Scene s, float x, float y, float r) {
        for (int i = 0; i < 6; i++) {
            float measured = s.pocketRadii[i] > 0 ? s.pocketRadii[i] + 0.25f * s.R : 0;
            if (Math.hypot(x - s.pockets[i][0], y - s.pockets[i][1]) < Math.max(r, measured)) return true;
        }
        return false;
    }

    /** the ball must enter the pocket mouth at a sensible angle (corner pockets ~ diagonal, side pockets ~ straight) */
    static float pocketFactor(PoolVision.Scene s, int pi, float ux, float uy) {
        float mx = (s.L + s.Rt) / 2f, my = (s.T + s.B) / 2f;
        float ox = s.pockets[pi][0] - mx, oy = s.pockets[pi][1] - my;
        if (pi >= 4) {                                        // side pocket: outward axis is along the short direction
            if (Math.abs(ox) > Math.abs(oy)) { oy = 0; } else { ox = 0; }
        }
        float ol = (float) Math.hypot(ox, oy);
        if (ol < 1) return 0;
        float cos = (ux * ox + uy * oy) / ol;
        float limit = pi >= 4 ? 0.52f : 0.42f;               // cos(58°) / cos(65°)
        if (cos < limit) return 0;
        return (float) Math.pow(cos, 0.8);
    }

    /** segment a->b must stay 2R away from every other ball (except `skip` and the cue ball unless `includeCue`) */
    private static boolean clearPath(PoolVision.Scene s, PoolVision.Ball skip, float bx, float by, float ax, float ay,
                                     boolean objectPath, float R) {
        float lim = 2f * R * 0.96f;
        for (PoolVision.Ball b : s.balls) {
            if (b == skip) continue;
            if (objectPath && b == s.cue) continue;
            if (!objectPath && b == s.cue) continue;
            if (distSeg(b.x, b.y, ax, ay, bx, by) < lim) {
                if (objectPath && Math.hypot(b.x - bx, b.y - by) < 2.4f * R && nearPocket(s, bx, by, 1f)) continue;
                return false;
            }
        }
        return true;
    }

    static float distSeg(float px, float py, float ax, float ay, float bx, float by) {
        float dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
        float t = l2 < 1e-6f ? 0 : ((px - ax) * dx + (py - ay) * dy) / l2;
        t = Math.max(0, Math.min(1, t));
        return (float) Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
    }

    /** after the hit the cue ball runs along the tangent: if that line ends in a pocket it is a scratch risk */
    private static void scratch(PoolVision.Scene s, Plan p, float ux, float uy, float cux, float cuy, float R) {
        float dot = cux * ux + cuy * uy;
        float tx = cux - ux * dot, ty = cuy - uy * dot, tl = (float) Math.hypot(tx, ty);
        if (tl < 0.12f) return;                               // straight on: stop-ball, cue ball stays
        tx /= tl; ty /= tl;
        float len = 2.5f * Math.max(s.Rt - s.L, s.B - s.T);
        for (int i = 0; i < 6; i++) {
            float dx = s.pockets[i][0] - p.gx, dy = s.pockets[i][1] - p.gy;
            float proj = dx * tx + dy * ty;
            if (proj > 3 * R && proj < len && Math.abs(dx * ty - dy * tx) < 1.3f * R) {
                p.scratchRisk = true; p.p *= 0.5f; p.note = "انتبه: الأبيض ممكن يدخل بعد الضربة"; return;
            }
        }
    }
}
