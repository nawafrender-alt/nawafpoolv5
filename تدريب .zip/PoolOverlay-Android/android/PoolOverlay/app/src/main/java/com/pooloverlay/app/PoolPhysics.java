package com.pooloverlay.app;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Small deterministic shot simulator. Work is deliberately bounded for the capture thread. */
final class PoolPhysics {
    private static final int MAX_CANDIDATES = 16;
    private static final int SAMPLES = 9;
    private static final int MAX_STEPS = 220;
    // Wider deterministic aim-error sweep catches fragile cut shots without random behavior.
    private static final float[] ANGLE_ERROR = {-0.024f, -0.018f, -0.012f, -0.006f, 0f, 0.006f, 0.012f, 0.018f, 0.024f};

    private PoolPhysics() { }

    static void refine(final PoolVision.Scene s, List<PoolPlanner.Plan> plans, PoolMemory memory) {
        if (s == null || plans == null || plans.isEmpty() || s.cue == null) return;
        Collections.sort(plans, new Comparator<PoolPlanner.Plan>() {
            @Override public int compare(PoolPlanner.Plan a, PoolPlanner.Plan b) {
                return Float.compare(b.p, a.p);
            }
        });
        int count = Math.min(MAX_CANDIDATES, plans.size());
        for (int i = 0; i < count; i++) {
            PoolPlanner.Plan p = plans.get(i);
            float geometric = p.p;
            float simulated = 0f;
            for (int sample = 0; sample < SAMPLES; sample++) {
                float friction = clamp((memory == null ? 0.984f : memory.friction())
                        + (sample - 2) * 0.0025f, 0.965f, 0.996f);
                float rail = clamp((memory == null ? 0.82f : memory.railRestitution())
                        + (sample - 2) * 0.035f, 0.68f, 0.96f);
                float ball = clamp((memory == null ? 0.94f : memory.ballRestitution())
                        + (2 - sample) * 0.012f, 0.86f, 0.99f);
                simulated += simulate(s, p, ANGLE_ERROR[sample], friction, rail, ball);
            }
            simulated /= SAMPLES;
            float blended = 0.38f * geometric + 0.62f * simulated;
            if (p.scratchRisk) blended *= 0.72f;
            if (memory != null) blended *= memory.reliabilityMultiplier(p.type);
            float classConfidence = Math.min(confidence(s.cue), confidence(p.target));
            p.p = clamp(blended * (0.82f + 0.18f * classConfidence), 0f, 0.97f);
        }
    }

    private static float simulate(PoolVision.Scene s, PoolPlanner.Plan p, float angleError,
                                  float friction, float railRestitution, float ballRestitution) {
        final int n = Math.min(20, s.balls.size());
        int cue = -1, target = -1;
        for (int i = 0; i < n; i++) {
            if (s.balls.get(i) == s.cue) cue = i;
            if (s.balls.get(i) == p.target) target = i;
        }
        if (cue < 0 || target < 0) return 0f;

        float[] x = new float[n], y = new float[n], vx = new float[n], vy = new float[n];
        boolean[] active = new boolean[n];
        for (int i = 0; i < n; i++) {
            PoolVision.Ball b = s.balls.get(i);
            x[i] = b.x; y[i] = b.y; active[i] = true;
        }
        float aimX = p.hasK ? p.kx : p.gx;
        float aimY = p.hasK ? p.ky : p.gy;
        float angle = (float) Math.atan2(aimY - s.cue.y, aimX - s.cue.x) + angleError;
        // The previous cap (0.71 R/frame) under-reached long shots on large tables.
        // Keep power monotonic while allowing a full-table shot to travel far enough.
        float speed = s.R * (0.20f + 0.80f * Math.max(0, Math.min(100, p.power)) / 100f);
        vx[cue] = (float) Math.cos(angle) * speed;
        vy[cue] = (float) Math.sin(angle) * speed;

        float left = s.L + s.R, right = s.Rt - s.R, top = s.T + s.R, bottom = s.B - s.R;
        int firstCueHit = -1;
        boolean targetPocketed = false, cuePocketed = false;

        for (int step = 0; step < MAX_STEPS; step++) {
            boolean moving = false;
            for (int i = 0; i < n; i++) {
                if (!active[i]) continue;
                x[i] += vx[i]; y[i] += vy[i];
                int pocket = pocketAt(s, x[i], y[i], vx[i], vy[i]);
                if (pocket >= 0) {
                    active[i] = false; vx[i] = 0; vy[i] = 0;
                    if (i == cue) cuePocketed = true;
                    if (i == target) targetPocketed = true;
                    continue;
                }
                if (x[i] < left) { x[i] = left; vx[i] = Math.abs(vx[i]) * railRestitution; }
                else if (x[i] > right) { x[i] = right; vx[i] = -Math.abs(vx[i]) * railRestitution; }
                if (y[i] < top) { y[i] = top; vy[i] = Math.abs(vy[i]) * railRestitution; }
                else if (y[i] > bottom) { y[i] = bottom; vy[i] = -Math.abs(vy[i]) * railRestitution; }
            }

            for (int i = 0; i < n; i++) {
                if (!active[i]) continue;
                for (int j = i + 1; j < n; j++) {
                    if (!active[j]) continue;
                    float dx = x[j] - x[i], dy = y[j] - y[i];
                    float d2 = dx * dx + dy * dy, min = 2f * s.R;
                    if (d2 >= min * min || d2 < 1e-8f) continue;
                    float d = (float) Math.sqrt(d2), nx = dx / d, ny = dy / d;
                    float overlap = min - d;
                    x[i] -= nx * overlap * 0.5f; y[i] -= ny * overlap * 0.5f;
                    x[j] += nx * overlap * 0.5f; y[j] += ny * overlap * 0.5f;
                    float rel = (vx[i] - vx[j]) * nx + (vy[i] - vy[j]) * ny;
                    if (rel > 0) {
                        float impulse = (1f + ballRestitution) * rel * 0.5f;
                        vx[i] -= impulse * nx; vy[i] -= impulse * ny;
                        vx[j] += impulse * nx; vy[j] += impulse * ny;
                        if (i == cue && firstCueHit < 0) firstCueHit = j;
                        else if (j == cue && firstCueHit < 0) firstCueHit = i;
                    }
                }
            }

            float energy = 0;
            for (int i = 0; i < n; i++) {
                if (!active[i]) continue;
                vx[i] *= friction; vy[i] *= friction;
                float v2 = vx[i] * vx[i] + vy[i] * vy[i];
                energy += v2;
                if (v2 < s.R * s.R * 0.000025f) { vx[i] = 0; vy[i] = 0; }
                else moving = true;
            }
            if (!moving || energy < s.R * s.R * 0.00008f) break;
        }
        if (targetPocketed && !cuePocketed && firstCueHit == target) return 1f;
        if (firstCueHit == target && !cuePocketed) return 0.08f;
        return 0f;
    }

    private static int pocketAt(PoolVision.Scene s, float x, float y, float vx, float vy) {
        float speed = (float) Math.hypot(vx, vy);
        if (speed < 1e-5f) return -1;
        for (int i = 0; i < 6; i++) {
            float dx = s.pockets[i][0] - x, dy = s.pockets[i][1] - y;
            float d = (float) Math.hypot(dx, dy);
            float radius = i < 4 ? 2.15f * s.R : 2.55f * s.R;
            if (s.pocketRadii[i] > 0) radius = Math.max(radius, s.pocketRadii[i] + 0.45f * s.R);
            if (d <= radius && (vx * dx + vy * dy) / (speed * Math.max(1e-4f, d)) > 0.08f
                    && PoolPlanner.pocketFactor(s, i, vx / speed, vy / speed) > 0.05f) return i;
        }
        return -1;
    }

    private static float confidence(PoolVision.Ball b) {
        return b == null || b.confidence <= 0 ? 0.65f : clamp(b.confidence, 0.25f, 1f);
    }

    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
}
