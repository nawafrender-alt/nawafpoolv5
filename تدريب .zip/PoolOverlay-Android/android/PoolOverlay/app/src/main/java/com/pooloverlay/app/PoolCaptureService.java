package com.pooloverlay.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;

/** Captures the screen (about 10 frames a second when something changes) and feeds the table reader. */
public class PoolCaptureService extends Service {
    private static final String TAG = "PoolOverlay";
    private static final String CHANNEL = "pool_overlay";

    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler bg, ui;
    private PoolOverlay overlay;
    private final PoolVision vision = new PoolVision();
    private boolean running = false;
    private long last = 0;
    private Image held;
    private boolean scheduled = false;
    private static final long MIN_GAP_MS = 60;
    private int[] pxBuf, rowBuf;
    private final Runnable processRunnable = new Runnable() {
        @Override public void run() { processHeld(); }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) return START_NOT_STICKY;
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Pool Overlay", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("مساعد البلياردو شغّال")
                .setContentText("يقرأ الطاولة من الشاشة")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }

        int code = intent.getIntExtra("code", 0);
        Intent data = Build.VERSION.SDK_INT >= 33
                ? intent.getParcelableExtra("data", Intent.class)
                : intent.getParcelableExtra("data");
        if (data == null) { stopSelf(); return START_NOT_STICKY; }
        try {
            start(code, data);
            running = true;
        } catch (Throwable t) {
            Log.e(TAG, "start failed", t);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void start(int code, Intent data) {
        ui = new Handler(Looper.getMainLooper());
        thread = new HandlerThread("pool-vision");
        thread.start();
        bg = new Handler(thread.getLooper());

        SharedPreferences prefs = getSharedPreferences("pool", MODE_PRIVATE);
        boolean practice = prefs.getBoolean("practice", false);

        DisplayManager dm = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
        DisplayMetrics m = new DisplayMetrics();
        d.getRealMetrics(m);
        float scale = Math.min(1f, 720f / Math.min(m.widthPixels, m.heightPixels));
        final int capW = Math.round(m.widthPixels * scale), capH = Math.round(m.heightPixels * scale);

        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        overlay = new PoolOverlay(this, wm, vision, scale, practice, new Runnable() {
            @Override public void run() { stopSelf(); }
        });
        overlay.show();

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        projectionCallback = new MediaProjection.Callback() {
            @Override public void onStop() {
                ui.post(new Runnable() { @Override public void run() { stopSelf(); } });
            }
        };
        projection.registerCallback(projectionCallback, ui);

        reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 3);
        reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override public void onImageAvailable(ImageReader r) { handle(r); }
        }, bg);
        display = projection.createVirtualDisplay("pool-capture", capW, capH, m.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
    }

    private void handle(ImageReader r) {
        try {
            Image img = r.acquireLatestImage();
            if (img == null) return;
            if (held != null) held.close();
            held = img;
            if (!scheduled) {
                long delay = Math.max(0, last + MIN_GAP_MS - SystemClock.uptimeMillis());
                scheduled = true;
                bg.postDelayed(processRunnable, delay);
            }
        } catch (Throwable t) {
            Log.e(TAG, "acquire failed", t);
        }
    }

    private void processHeld() {
        scheduled = false;
        Image img = held;
        if (img == null) return;
        held = null;
        try {
            int w = img.getWidth(), h = img.getHeight();
            if (pxBuf == null || pxBuf.length != w * h) pxBuf = new int[w * h];
            int[] px = toPixels(img, w, h, pxBuf);
            final PoolVision.Scene scene = vision.analyse(px, w, h);
            final PoolVision.Aim aim = vision.aim();
            ui.post(new Runnable() {
                @Override public void run() { if (overlay != null) { overlay.update(scene); overlay.updateAim(aim); } }
            });
        } catch (Throwable t) {
            Log.e(TAG, "frame failed", t);
        } finally {
            img.close();
            last = SystemClock.uptimeMillis();
        }
    }

    private int[] toPixels(Image img, int w, int h, int[] px) {
        Image.Plane pl = img.getPlanes()[0];
        ByteBuffer buf = pl.getBuffer();
        int rs = pl.getRowStride(), ps = pl.getPixelStride();
        if (ps == 4 && rs % 4 == 0) {
            // fast path: read a whole row of ints at once, swap R/B
            buf.order(ByteOrder.LITTLE_ENDIAN);
            IntBuffer ib = buf.asIntBuffer();
            int rsi = rs / 4;
            if (rowBuf == null || rowBuf.length < w) rowBuf = new int[w];
            int[] row = rowBuf;
            for (int y = 0; y < h; y++) {
                int pos = y * rsi;
                if (pos + w > ib.limit()) break;
                ib.position(pos);
                ib.get(row, 0, w);
                int o = y * w;
                for (int x = 0; x < w; x++) {
                    int v = row[x];
                    px[o + x] = 0xFF000000 | ((v & 0xFF) << 16) | (v & 0xFF00) | ((v >> 16) & 0xFF);
                }
            }
            return px;
        }
        byte[] row = new byte[rs];
        for (int y = 0; y < h; y++) {
            buf.position(y * rs);
            buf.get(row, 0, Math.min(rs, buf.remaining()));
            int o = y * w;
            for (int x = 0; x < w; x++) {
                int i = x * ps;
                px[o + x] = 0xFF000000 | ((row[i] & 255) << 16) | ((row[i + 1] & 255) << 8) | (row[i + 2] & 255);
            }
        }
        return px;
    }

    @Override
    public void onDestroy() {
        running = false;
        try { if (reader != null) reader.setOnImageAvailableListener(null, null); } catch (Throwable ignored) { }
        try { if (display != null) display.release(); } catch (Throwable ignored) { }
        try { if (held != null) held.close(); } catch (Throwable ignored) { }
        try { if (reader != null) reader.close(); } catch (Throwable ignored) { }
        try {
            if (projection != null) {
                if (projectionCallback != null) projection.unregisterCallback(projectionCallback);
                projection.stop();
            }
        } catch (Throwable ignored) { }
        try { if (overlay != null) overlay.hide(); } catch (Throwable ignored) { }
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }
}
