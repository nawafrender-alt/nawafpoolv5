# PoolOverlay Android

تطبيق Android أصلي يقرأ طاولة البلياردو في وضع التدريب، يقترح الضربات ويحاكيها محلياً دون تنفيذ الضربة نيابة عن اللاعب.

## Run & Operate

- Android source: `android/PoolOverlay`
- Build APK: `cd android/PoolOverlay && gradle assembleDebug --no-daemon`
- Requirements: Java 17, Gradle 8.7, Android SDK 34
- Root workflow `.github/workflows/pool-overlay-build.yml` builds and uploads a debug APK on push or manual run.
- This native Android project does not have a browser preview; build it in Android Studio, CI, or an environment with Android SDK.

## Stack

- Android Java, Gradle, Android Gradle Plugin 8.5.2
- Android API 26 minimum; compile/target SDK 34
- The surrounding Replit workspace retains its pnpm packages and shared mockup/API scaffolds.

## Where things live

- `android/PoolOverlay/app/src/main/java/com/pooloverlay/app/` — capture service, overlay, vision, planner, physics, and local history.
- `android/PoolOverlay/app/src/main/AndroidManifest.xml` — screen capture and overlay permissions.
- `.github/workflows/pool-overlay-build.yml` — root-level Android APK build.

## Architecture decisions

- Keep this as native Android Java: screen capture via MediaProjection and a floating overlay require Android APIs not provided by a standard Expo app.
- The app only displays advice in explicit training mode; it does not inject touches or play automatically.
- Store bounded shot history and model coefficients locally; never persist captured screen pixels.
- Bound physics scoring to 12 candidate shots, 5 variants each, and 180 simulation steps per variant.

## Product

Reads the visible pool table, estimates ball and pocket geometry, suggests direct/bank/kick shots, and refines route reliability from training results.

## User preferences

- Keep the project focused on the existing Android app, avoid full rewrites, and use one quick verification pass.

## Gotchas

- Build from `android/PoolOverlay`, not the repository root.
- The Replit preview cannot run this native Android overlay; a JDK, Android SDK, and Gradle are required for APK builds.

## Pointers

- See `android/PoolOverlay/README_AR.md` for Arabic build and usage notes.
