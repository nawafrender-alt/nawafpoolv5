package com.pooloverlay.app;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class CaptureResourceRegistryTest {
    @Test public void sessionClosesResourcesOnceInReverseOwnershipOrder() {
        CaptureResourceRegistry registry = new CaptureResourceRegistry();
        List<Integer> released = new ArrayList<>();
        registry.register(() -> released.add(1));
        registry.register(() -> released.add(2));
        registry.register(() -> released.add(3));

        registry.closeAll();
        registry.closeAll();

        assertEquals(Arrays.asList(3, 2, 1), released);
        assertEquals(0, registry.activeCount());
        assertTrue(registry.isClosed());
    }

    @Test public void replacementCanReleaseOldReaderBeforeSessionStops() {
        CaptureResourceRegistry registry = new CaptureResourceRegistry();
        int[] released = {0, 0};
        CaptureResourceRegistry.Lease oldReader = registry.register(() -> released[0]++);
        registry.register(() -> released[1]++);

        registry.release(oldReader);
        registry.release(oldReader);
        assertEquals(1, released[0]);
        assertEquals(0, released[1]);

        registry.closeAll();
        assertEquals(1, released[0]);
        assertEquals(1, released[1]);
    }

    @Test public void stoppedSessionCanBeReplacedByAFreshSession() {
        int[] released = {0};
        CaptureResourceRegistry first = new CaptureResourceRegistry();
        first.register(() -> released[0]++);
        first.closeAll();

        CaptureResourceRegistry restarted = new CaptureResourceRegistry();
        restarted.register(() -> released[0]++);
        restarted.closeAll();
        assertEquals(2, released[0]);
    }

    @Test public void registrationAfterStopReleasesImmediately() {
        CaptureResourceRegistry registry = new CaptureResourceRegistry();
        int[] released = {0};
        registry.closeAll();
        registry.register(() -> released[0]++);
        assertEquals(1, released[0]);
    }
}
