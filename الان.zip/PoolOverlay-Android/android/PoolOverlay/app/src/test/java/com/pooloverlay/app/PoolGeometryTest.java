package com.pooloverlay.app;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

public class PoolGeometryTest {
    @Test public void straightGhostBallUsesBothBallRadii() {
        PoolGeometry.Point ghost = PoolGeometry.ghostBall(100, 50, 200, 50, 10, 10);
        assertNotNull(ghost);
        assertEquals(80f, ghost.x, 0.001f);
        assertEquals(50f, ghost.y, 0.001f);
        assertEquals(0f, PoolGeometry.cutAngleDegrees(20, 50, ghost, 100, 50, 200, 50), 0.001f);
    }

    @Test public void angledGhostBallHasExpectedContactOffset() {
        PoolGeometry.Point ghost = PoolGeometry.ghostBall(100, 100, 200, 200, 10, 10);
        assertNotNull(ghost);
        assertEquals(100f - (float) Math.sqrt(200f), ghost.x, 0.01f);
        assertEquals(100f - (float) Math.sqrt(200f), ghost.y, 0.01f);
        assertTrue(PoolGeometry.cutAngleDegrees(20, 100, ghost, 100, 100, 200, 200) > 0f);
    }

    @Test public void segmentRejectsBallBlockerAndAllowsClearPassage() {
        float[][] blocker = {{50f, 0f, 10f}};
        assertFalse(PoolGeometry.segmentClear(0, 0, 100, 0, blocker, 10, 0.5f));
        blocker[0][1] = 21f;
        assertTrue(PoolGeometry.segmentClear(0, 0, 100, 0, blocker, 10, 0.5f));
    }

    @Test public void touchingOrNearlyTouchingBallsBlockTheRoute() {
        float[][] touching = {{50f, 19.5f, 10f}};
        assertFalse(PoolGeometry.segmentClear(0, 0, 100, 0, touching, 10, 0.25f));
        touching[0][1] = 20.5f;
        assertTrue(PoolGeometry.segmentClear(0, 0, 100, 0, touching, 10, 0.25f));
    }

    @Test public void ghostCenterMustRemainInsideBallCenterBoundsNearRail() {
        assertTrue(PoolGeometry.insideBallCenterBounds(12, 50, 10, 10, 190, 90, 0));
        assertFalse(PoolGeometry.insideBallCenterBounds(8, 50, 10, 10, 190, 90, 0));
        assertFalse(PoolGeometry.insideBallCenterBounds(188, 50, 10, 10, 190, 90, 3));
    }

    @Test public void singleBankReflectionProducesAValidOneBouncePoint() {
        PoolGeometry.Point mirrored = PoolGeometry.reflectAcrossHorizontal(180, 50, 90);
        assertEquals(180f, mirrored.x, 0.001f);
        assertEquals(130f, mirrored.y, 0.001f);
        float t = (90f - 50f) / (mirrored.y - 50f);
        float bounceX = 40f + (mirrored.x - 40f) * t;
        assertEquals(110f, bounceX, 0.001f);
        assertTrue(bounceX > 10f && bounceX < 190f);
    }

    @Test public void routeCannotLeaveRailBeforeThePocketMouth() {
        assertFalse(PoolGeometry.routeToPocketInside(30, 50, 220, 50,
                10, 10, 190, 90, 220, 50, 15, 3));
        assertTrue(PoolGeometry.routeToPocketInside(100, 50, 200, 50,
                10, 10, 190, 90, 200, 50, 15, 3));
    }

    @Test public void transformSupportsPortraitLandscapeAndLetterboxing() {
        ScreenTransform portrait = new ScreenTransform(720, 1600, 1080, 2400);
        assertEquals(540f, portrait.frameToViewX(360), 0.01f);
        assertEquals(1200f, portrait.frameToViewY(800), 0.01f);
        assertEquals(360f, portrait.viewToFrameX(540), 0.01f);

        ScreenTransform letterboxed = new ScreenTransform(1600, 900, 1080, 2400);
        assertFalse(letterboxed.containsViewPoint(100, 100));
        assertTrue(letterboxed.containsViewPoint(540, 1200));
        assertEquals(800f, letterboxed.viewToFrameX(540), 0.01f);
        assertEquals(450f, letterboxed.viewToFrameY(1200), 0.01f);
    }

    @Test public void noCueBallNeverProducesAPlan() {
        PoolVision.Scene scene = new PoolVision.Scene();
        scene.ok = true;
        scene.confidence = 0.9f;
        scene.R = 10f;
        assertTrue(PoolPlanner.plan(scene, 0, true, null).isEmpty());
    }

    @Test public void unobstructedStraightShotProducesAValidatedDirectPlan() {
        PoolVision.Scene scene = simpleTable();
        PoolVision.Ball cue = ball(30, 50, PoolVision.CUE);
        PoolVision.Ball target = ball(100, 50, PoolVision.SOLID);
        scene.cue = cue;
        scene.balls.add(cue);
        scene.balls.add(target);

        List<PoolPlanner.Plan> plans = PoolPlanner.plan(scene, 0, false, null);
        boolean hasDirect = false;
        for (PoolPlanner.Plan plan : plans) {
            if (plan.type == PoolPlanner.DIRECT && plan.target == target) hasDirect = true;
        }
        assertTrue("an unobstructed direct shot should survive geometry and physics checks", hasDirect);
    }

    @Test public void blockerInvalidatesTheObjectBallRoute() {
        PoolVision.Scene scene = simpleTable();
        PoolVision.Ball target = ball(100, 50, PoolVision.SOLID);
        PoolVision.Ball blocker = ball(150, 50, PoolVision.STRIPE);
        PoolVision.Ball cue = ball(30, 50, PoolVision.CUE);
        scene.cue = cue;
        scene.balls.add(cue);
        scene.balls.add(target);
        scene.balls.add(blocker);
        assertFalse(PoolPlanner.clearPath(scene, target, 220, 50, target.x, target.y, true, scene.R));
    }

    @Test public void cueCannotPassThroughTheTargetToReachItsGhostBall() {
        PoolVision.Scene scene = simpleTable();
        PoolVision.Ball target = ball(100, 50, PoolVision.SOLID);
        assertFalse(PoolPlanner.approachAvoidsTarget(scene, target, 30, 50, 120, 50, scene.R));
    }

    @Test public void temporalSmoothingFollowsSmallMotionInsteadOfFreezingTheBall() {
        PoolVision vision = new PoolVision();
        PoolVision.Scene first = trackedScene(50, 100);
        vision.stabilize(first);
        PoolVision.Scene moved = trackedScene(51, 160);
        PoolVision.Scene result = vision.stabilize(moved);
        assertTrue(result.cue.x > 50f);
        assertTrue(result.cue.x < 51f);
    }

    @Test public void largeTrackingJumpNeedsASecondConsistentFrame() {
        PoolVision vision = new PoolVision();
        vision.stabilize(trackedScene(50, 100));
        PoolVision.Scene firstJump = vision.stabilize(trackedScene(88, 160));
        assertEquals(50f, firstJump.cue.x, 0.001f);
        PoolVision.Scene confirmed = vision.stabilize(trackedScene(89, 220));
        assertEquals(88f, confirmed.cue.x, 0.001f);
    }

    @Test public void darkOrInvalidFrameIsRejectedWithoutInventingACueBall() {
        int[] dark = new int[64 * 64];
        for (int i = 0; i < dark.length; i++) dark[i] = 0xFF000000;
        PoolVision.Scene scene = new PoolVision().analyse(dark, 64, 64, 1L);
        assertFalse(scene.ok);
        assertNull(scene.cue);
        assertFalse(new PoolVision().analyse(new int[8], 64, 64, 2L).ok);
    }

    private static PoolVision.Scene simpleTable() {
        PoolVision.Scene scene = new PoolVision.Scene();
        scene.ok = true;
        scene.confidence = 0.95f;
        scene.R = 10f;
        scene.L = 0f;
        scene.T = 0f;
        scene.Rt = 220f;
        scene.B = 100f;
        float[][] pockets = {{0, 0}, {220, 0}, {0, 100}, {220, 100}, {0, 50}, {220, 50}};
        for (int i = 0; i < pockets.length; i++) {
            scene.pockets[i][0] = pockets[i][0];
            scene.pockets[i][1] = pockets[i][1];
            scene.pocketRadii[i] = 14f;
        }
        return scene;
    }

    private static PoolVision.Ball ball(float x, float y, int kind) {
        PoolVision.Ball ball = new PoolVision.Ball();
        ball.x = x;
        ball.y = y;
        ball.radius = 10f;
        ball.kind = kind;
        ball.confidence = 0.95f;
        if (kind == PoolVision.CUE) ball.white = 0.99f;
        return ball;
    }

    private static PoolVision.Scene trackedScene(float cueX, long timestamp) {
        PoolVision.Scene scene = simpleTable();
        scene.timestampMs = timestamp;
        PoolVision.Ball cue = ball(cueX, 50, PoolVision.CUE);
        scene.cue = cue;
        scene.balls.add(cue);
        return scene;
    }
}
