package com.pooloverlay.app;

/** Deterministic, Android-free geometry used by the planner and its unit tests. */
final class PoolGeometry {
    static final class Point {
        final float x;
        final float y;

        Point(float x, float y) {
            this.x = x;
            this.y = y;
        }
    }

    private PoolGeometry() { }

    static Point ghostBall(float objectX, float objectY, float pocketX, float pocketY,
                           float cueRadius, float objectRadius) {
        float dx = pocketX - objectX;
        float dy = pocketY - objectY;
        float length = (float) Math.hypot(dx, dy);
        if (length < 1e-5f) return null;
        float contactDistance = Math.max(0f, cueRadius) + Math.max(0f, objectRadius);
        return new Point(objectX - dx / length * contactDistance,
                objectY - dy / length * contactDistance);
    }

    static float cutAngleDegrees(float cueX, float cueY, Point ghost,
                                 float objectX, float objectY, float pocketX, float pocketY) {
        if (ghost == null) return Float.NaN;
        float ax = ghost.x - cueX, ay = ghost.y - cueY;
        float bx = pocketX - objectX, by = pocketY - objectY;
        float al = (float) Math.hypot(ax, ay), bl = (float) Math.hypot(bx, by);
        if (al < 1e-5f || bl < 1e-5f) return Float.NaN;
        float cosine = (ax * bx + ay * by) / (al * bl);
        cosine = Math.max(-1f, Math.min(1f, cosine));
        return (float) Math.toDegrees(Math.acos(cosine));
    }

    static boolean insideBallCenterBounds(float x, float y, float left, float top,
                                          float right, float bottom, float tolerance) {
        return x >= left + tolerance && x <= right - tolerance
                && y >= top + tolerance && y <= bottom - tolerance;
    }

    static float pointSegmentDistance(float px, float py, float ax, float ay, float bx, float by) {
        float dx = bx - ax, dy = by - ay;
        float lengthSquared = dx * dx + dy * dy;
        float t = lengthSquared < 1e-7f ? 0f
                : ((px - ax) * dx + (py - ay) * dy) / lengthSquared;
        t = Math.max(0f, Math.min(1f, t));
        return (float) Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
    }

    /**
     * Checks a center-line against circular blockers. The collision threshold is the
     * sum of both radii minus a small numeric tolerance, not a guessed visual line width.
     */
    static boolean segmentClear(float ax, float ay, float bx, float by,
                                float[][] blockers, float movingRadius, float margin) {
        if (blockers == null) return true;
        for (float[] blocker : blockers) {
            if (blocker == null || blocker.length < 3) continue;
            float required = movingRadius + blocker[2] - margin;
            if (required > 0f && pointSegmentDistance(blocker[0], blocker[1], ax, ay, bx, by) < required) {
                return false;
            }
        }
        return true;
    }

    /** A single-bank reflection; double-bank paths are intentionally not represented. */
    static Point reflectAcrossVertical(float x, float y, float railX) {
        return new Point(2f * railX - x, y);
    }

    static Point reflectAcrossHorizontal(float x, float y, float railY) {
        return new Point(x, 2f * railY - y);
    }

    /**
     * Ensures a ball-center route stays inside the playable rectangle until it enters
     * the intended pocket mouth. Sampling is bounded by geometry size, not frame count.
     */
    static boolean routeToPocketInside(float ax, float ay, float px, float py,
                                       float left, float top, float right, float bottom,
                                       float pocketX, float pocketY, float pocketRadius,
                                       float sampleStep) {
        float dx = px - ax, dy = py - ay;
        float length = (float) Math.hypot(dx, dy);
        int steps = Math.max(1, (int) Math.ceil(length / Math.max(1f, sampleStep)));
        for (int i = 0; i <= steps; i++) {
            float t = i / (float) steps;
            float x = ax + dx * t, y = ay + dy * t;
            boolean inside = x >= left && x <= right && y >= top && y <= bottom;
            if (!inside && Math.hypot(x - pocketX, y - pocketY) > pocketRadius) return false;
        }
        return true;
    }
}
