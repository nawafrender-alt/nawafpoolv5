package com.pooloverlay.app;

/**
 * Maps captured-frame pixels to overlay-window pixels while preserving aspect ratio.
 * Any unused area is treated as letterboxing and is excluded when converting taps back.
 */
final class ScreenTransform {
    final int frameWidth;
    final int frameHeight;
    final int viewWidth;
    final int viewHeight;
    final float scale;
    final float offsetX;
    final float offsetY;

    ScreenTransform(int frameWidth, int frameHeight, int viewWidth, int viewHeight) {
        this.frameWidth = Math.max(1, frameWidth);
        this.frameHeight = Math.max(1, frameHeight);
        this.viewWidth = Math.max(1, viewWidth);
        this.viewHeight = Math.max(1, viewHeight);
        scale = Math.min(this.viewWidth / (float) this.frameWidth,
                this.viewHeight / (float) this.frameHeight);
        offsetX = (this.viewWidth - this.frameWidth * scale) * 0.5f;
        offsetY = (this.viewHeight - this.frameHeight * scale) * 0.5f;
    }

    float frameToViewX(float x) { return offsetX + x * scale; }
    float frameToViewY(float y) { return offsetY + y * scale; }

    float viewToFrameX(float x) { return (x - offsetX) / scale; }
    float viewToFrameY(float y) { return (y - offsetY) / scale; }

    boolean containsViewPoint(float x, float y) {
        return x >= offsetX && y >= offsetY
                && x <= offsetX + frameWidth * scale
                && y <= offsetY + frameHeight * scale;
    }
}
