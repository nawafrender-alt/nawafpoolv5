package com.pooloverlay.app;

/** Follows the aim read from the game's own guide line: where the cue ball goes, what it hits, where that ball ends up. */
final class PoolAim {
    static final class Pts {
        final float[] v = new float[32];
        int n;
        void add(float x, float y) { if (n < 16) { v[2 * n] = x; v[2 * n + 1] = y; n++; } }
    }

    static final class Live {
        final Pts cue = new Pts();      // cue ball path: centre -> cushion points -> ghost ball centre
        final Pts obj = new Pts();      // object ball path (from its centre)
        final Pts after = new Pts();    // cue ball after the hit
        boolean hit, pocketed, scratch, blocked;
        float gx, gy, ox, oy;
        int pocketIdx = -1;
        PoolVision.Ball target;
    }

    static Live trace(PoolVision.Scene s, float ux, float uy) {
        Live lv = new Live();
        if (!s.ok || s.cue == null) return lv;
        final float R = s.R;
        final float Lc = s.L + R, Rc = s.Rt - R, Tc = s.T + R, Bc = s.B - R;
        float x = s.cue.x, y = s.cue.y, dx = ux, dy = uy;
        lv.cue.add(x, y);
        PoolVision.Ball[] who = new PoolVision.Ball[1];
        PoolVision.Ball target = null;
        for (int bounce = 0; bounce < 4; bounce++) {
            who[0] = null;
            float bt = firstBall(s, x, y, dx, dy, R, s.cue, null, who);
            float tc = distToWall(x, y, dx, dy, Lc, Tc, Rc, Bc);
            if (who[0] != null && bt <= tc) {
                target = who[0];
                lv.hit = true;
                lv.target = target;
                lv.gx = x + dx * bt; lv.gy = y + dy * bt;
                lv.ox = target.x; lv.oy = target.y;
                lv.cue.add(lv.gx, lv.gy);
                break;
            }
            if (tc == Float.MAX_VALUE) break;
            float wx = x + dx * tc, wy = y + dy * tc;
            lv.cue.add(wx, wy);
            if (PoolPlanner.nearPocket(s, wx, wy, 1.9f * R)) lv.scratch = true;
            boolean vert = (dx > 0 && Math.abs(wx - Rc) < 0.5f) || (dx < 0 && Math.abs(wx - Lc) < 0.5f);
            boolean horiz = (dy > 0 && Math.abs(wy - Bc) < 0.5f) || (dy < 0 && Math.abs(wy - Tc) < 0.5f);
            if (vert) dx = -dx;
            if (horiz) dy = -dy;
            x = wx; y = wy;
            if (!vert && !horiz) break;
        }
        if (!lv.hit) return lv;

        // direction the object ball takes: along the line of centres
        float nx = lv.ox - lv.gx, ny = lv.oy - lv.gy, nl = (float) Math.hypot(nx, ny);
        if (nl < 1e-3f) return lv;
        nx /= nl; ny /= nl;

        // the cue ball after the hit runs along the tangent
        float dot = dx * nx + dy * ny;
        float tx = dx - nx * dot, ty = dy - ny * dot, tl = (float) Math.hypot(tx, ty);
        if (tl > 0.12f) {
            tx /= tl; ty /= tl;
            lv.after.add(lv.gx, lv.gy);
            x = lv.gx; y = lv.gy;
            float budget = 0.9f * Math.max(s.Rt - s.L, s.B - s.T);
            for (int bounce = 0; bounce < 2 && budget > 2 * R; bounce++) {
                float wall = distToWall(x, y, tx, ty, Lc, Tc, Rc, Bc);
                if (wall == Float.MAX_VALUE || wall < 0.5f) break;
                float hitBall = firstBall(s, x, y, tx, ty, R, s.cue, target, null);   // it stops when it meets another ball
                if (hitBall < wall && hitBall < budget) {
                    lv.after.add(x + tx * hitBall, y + ty * hitBall);
                    break;
                }
                float seg = Math.min(wall, budget);
                float wx = x + tx * seg, wy = y + ty * seg;
                lv.after.add(wx, wy);
                if (rayCrossesPocket(s, x, y, tx, ty, seg, R)) lv.scratch = true;
                if (seg < wall) break;
                budget -= seg;
                boolean vert = (tx > 0 && Math.abs(wx - Rc) < 0.5f) || (tx < 0 && Math.abs(wx - Lc) < 0.5f);
                boolean horiz = (ty > 0 && Math.abs(wy - Bc) < 0.5f) || (ty < 0 && Math.abs(wy - Tc) < 0.5f);
                float ntx = vert ? -tx : tx, nty = horiz ? -ty : ty;
                if (!vert && !horiz) break;
                if (ntx * tx + nty * ty < -0.9f) break;          // coming straight back: would draw two lines on top of each other
                tx = ntx; ty = nty;
                x = wx; y = wy;
            }
        }

        // the object ball: follow to a pocket/obstacle or up to five cushion bounces
        x = lv.ox; y = lv.oy; dx = nx; dy = ny;
        lv.obj.add(x, y);
        for (int bounce = 0; bounce < 3; bounce++) {
            float tc = distToWall(x, y, dx, dy, Lc, Tc, Rc, Bc);
            int pi = -1; float pt = 0;
            for (int i = 0; i < 6; i++) {
                float qx = s.pockets[i][0] - x, qy = s.pockets[i][1] - y;
                float proj = qx * dx + qy * dy;
                if (proj <= 0 || (tc != Float.MAX_VALUE && proj > tc + 3f * R)) continue;
                if (Math.abs(qx * dy - qy * dx) > 1.15f * R) continue;
                if (PoolPlanner.pocketFactor(s, i, dx, dy) <= 0) continue;
                if (pi < 0 || proj < pt) { pi = i; pt = proj; }
            }
            float bt = firstBall(s, x, y, dx, dy, R, target, s.cue, null);
            float limit = pi >= 0 ? pt : tc;
            if (bt < limit - 0.5f) {
                lv.obj.add(x + dx * bt, y + dy * bt);
                lv.blocked = true;
                break;
            }
            if (pi >= 0) {
                lv.pocketed = true; lv.pocketIdx = pi;
                lv.obj.add(s.pockets[pi][0], s.pockets[pi][1]);
                break;
            }
            if (tc == Float.MAX_VALUE) break;
            float wx = x + dx * tc, wy = y + dy * tc;
            lv.obj.add(wx, wy);
            boolean vert = (dx > 0 && Math.abs(wx - Rc) < 0.5f) || (dx < 0 && Math.abs(wx - Lc) < 0.5f);
            boolean horiz = (dy > 0 && Math.abs(wy - Bc) < 0.5f) || (dy < 0 && Math.abs(wy - Tc) < 0.5f);
            if (vert) dx = -dx;
            if (horiz) dy = -dy;
            x = wx; y = wy;
            if (!vert && !horiz) break;
        }
        return lv;
    }

    private static float distToWall(float x, float y, float dx, float dy, float Lc, float Tc, float Rc, float Bc) {
        float tc = Float.MAX_VALUE;
        if (dx > 1e-6f) tc = Math.min(tc, (Rc - x) / dx); else if (dx < -1e-6f) tc = Math.min(tc, (Lc - x) / dx);
        if (dy > 1e-6f) tc = Math.min(tc, (Bc - y) / dy); else if (dy < -1e-6f) tc = Math.min(tc, (Tc - y) / dy);
        return tc < 0 ? 0 : tc;
    }

    private static boolean rayCrossesPocket(PoolVision.Scene s, float x, float y, float dx, float dy, float length, float R) {
        for (int i = 0; i < 6; i++) {
            float qx = s.pockets[i][0] - x, qy = s.pockets[i][1] - y;
            float proj = qx * dx + qy * dy;
            if (proj > 2.4f * R && proj < length + 1.4f * R
                    && Math.abs(qx * dy - qy * dx) < Math.max(1.3f * R, s.pocketRadii[i] + 0.3f * R)) return true;
        }
        return false;
    }

    /** distance along the ray at which a ball of radius R first touches another ball (centres 2R apart) */
    private static float firstBall(PoolVision.Scene s, float x, float y, float dx, float dy, float R,
                                   PoolVision.Ball skip1, PoolVision.Ball skip2, PoolVision.Ball[] who) {
        float bt = Float.MAX_VALUE;
        for (PoolVision.Ball b : s.balls) {
            if (b == skip1 || b == skip2) continue;
            float vx = b.x - x, vy = b.y - y;
            float t = vx * dx + vy * dy;
            if (t <= 0) continue;
            float sumR = R + (b.radius > 0f ? b.radius : R);
            float perp2 = vx * vx + vy * vy - t * t, lim = sumR * sumR;
            if (perp2 >= lim) continue;
            float th = Math.max(0f, t - (float) Math.sqrt(lim - perp2));
            if (th < bt) { bt = th; if (who != null) who[0] = b; }
        }
        return bt;
    }
}
