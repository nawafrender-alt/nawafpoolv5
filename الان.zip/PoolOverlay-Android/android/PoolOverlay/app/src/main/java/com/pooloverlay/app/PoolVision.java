package com.pooloverlay.app;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.List;

/**
 * Reads a pool table from a screenshot: cloth rectangle, pockets, every ball (cue / solid / stripe / 8) and whether the
 * balls are still in the triangle. Works on any cloth colour that is green-ish; no templates, no per-game setup.
 */
final class PoolVision {
    static final int CUE = 0, SOLID = 1, STRIPE = 2, EIGHT = 3;

    static final class Ball {
        float x, y;
        float radius;
        int kind;
        float white, dark, ring;      // debug features
        float confidence;
        float pendingX, pendingY;
        int pendingFrames;
    }

    static final class Scene {
        boolean ok, secure;
        boolean manuallyCalibrated;
        String msg = "";
        long timestampMs;
        float L, T, Rt, B;               // cushion contact rectangle (edge of the cloth)
        float R;                         // ball radius
        float confidence;
        final float[][] pockets = new float[6][2];   // 4 corners then the 2 side pockets
        final float[] pocketRadii = new float[6];    // locally measured opening radius
        final List<Ball> balls = new ArrayList<>();
        Ball cue;
        boolean rack;
        float rackX, rackY;
        long sig;
        int rr, gg, bb;                  // reference cloth colour
    }

    private volatile float[] ignoreSegs = new float[0];     // x1,y1,x2,y2,...  (our own arrow, treated as cloth)
    private volatile float[] ignoreRect = null;             // l,t,r,b          (our own panel)

    private volatile int ignoreVersion = 0;
    private Scene lastScene;
    private long lastFp;
    private int lastIgnoreVersion = -1, lastW, lastH;
    private float[][] manualPocketNormalized;
    private int[] bitmapPixels;

    void setManualPockets(float[][] normalized) {
        if (normalized == null || normalized.length != 6) {
            manualPocketNormalized = null;
        } else {
            float[][] copy = new float[6][2];
            for (int i = 0; i < 6; i++) {
                if (normalized[i] == null || normalized[i].length < 2
                        || !Float.isFinite(normalized[i][0]) || !Float.isFinite(normalized[i][1])
                        || normalized[i][0] < 0f || normalized[i][0] > 1f
                        || normalized[i][1] < 0f || normalized[i][1] > 1f) {
                    manualPocketNormalized = null;
                    resetTemporal();
                    return;
                }
                copy[i][0] = normalized[i][0];
                copy[i][1] = normalized[i][1];
            }
            manualPocketNormalized = copy;
        }
        resetTemporal();
    }

    void resetTemporal() {
        lastScene = null;
        lastFp = 0;
        lastIgnoreVersion = -1;
        stableScene = null;
        heldFrames = 0;
        smAim = null;
        aimMiss = 0;
        aimPending = 0;
    }

    void setIgnore(float[] segs, float[] rect) {
        ignoreSegs = segs == null ? new float[0] : segs;
        ignoreRect = rect;
        ignoreVersion++;
    }

    /** cheap hash of the table area: if nothing changed on screen the previous reading is still right */
    private static long fingerprint(int[] px, int w, int h, Scene s) {
        long f = 1469598103934665603L;
        int x0 = Math.max(0, (int) s.L), x1 = Math.min(w, (int) s.Rt), y0 = Math.max(0, (int) s.T), y1 = Math.min(h, (int) s.B);
        for (int y = y0; y < y1; y += 5)
            for (int x = x0; x < x1; x += 7) f = (f ^ (px[y * w + x] & 0xF8F8F8)) * 1099511628211L;
        return f;
    }

    // ------------------------------------------------------------------ helpers
    private static boolean isCloth(int p) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        return g > r + 25 && g > b + 28 && g > 80;
    }

    private static boolean isBlackFrame(int[] px) {
        int n = 0, dark = 0;
        for (int i = 0; i < px.length; i += 211) {
            int p = px[i];
            n++;
            if (((p >> 16) & 255) < 16 && ((p >> 8) & 255) < 16 && (p & 255) < 16) dark++;
        }
        return n > 0 && dark >= n * 0.85;
    }

    private static int l1(int p, int rr, int gg, int bb) {
        return Math.abs(((p >> 16) & 255) - rr) + Math.abs(((p >> 8) & 255) - gg) + Math.abs((p & 255) - bb);
    }

    // ------------------------------------------------------------------ aim line of the game + shot watch
    /** the direction the game's own white aim line points to, read every frame */
    static final class Aim {
        float ux, uy, angle, run;
    }

    private volatile Aim lastAim;
    Aim aim() { return lastAim; }

    private final Object watchLock = new Object();
    private boolean watchOn;
    private float watchX, watchY, watchR;
    private int[] watchRef;
    private volatile float watchDiff = 0;

    /** remember what the cue ball looks like now; watchDiff() jumps when it leaves its spot (= a shot) */
    void setWatch(float x, float y, float r) {
        synchronized (watchLock) { watchX = x; watchY = y; watchR = r; watchRef = null; watchDiff = 0; watchOn = true; }
    }

    void clearWatch() {
        synchronized (watchLock) { watchOn = false; watchRef = null; watchDiff = 0; }
    }

    float watchDiff() { return watchDiff; }

    private void updateWatch(int[] px, int w, int h) {
        synchronized (watchLock) {
            if (!watchOn) return;
            int cx = (int) watchX, cy = (int) watchY, rad = Math.max(3, (int) (0.6f * watchR));
            int side = rad + 1;
            int[] cur = new int[side * side * 3];
            int i = 0;
            for (int dy = -rad; dy <= rad; dy += 2) {
                for (int dx = -rad; dx <= rad; dx += 2) {
                    int x = Math.min(w - 1, Math.max(0, cx + dx)), y = Math.min(h - 1, Math.max(0, cy + dy));
                    int p = px[y * w + x];
                    cur[i++] = (p >> 16) & 255; cur[i++] = (p >> 8) & 255; cur[i++] = p & 255;
                }
            }
            if (watchRef == null || watchRef.length != cur.length) { watchRef = cur; watchDiff = 0; return; }
            long sum = 0;
            for (int k = 0; k < cur.length; k++) sum += Math.abs(cur[k] - watchRef[k]);
            watchDiff = sum / (float) cur.length;
        }
    }

    /** stage 1: coarse sweep over 720 directions; stage 2: 41 fine directions centred on what stage 1 found */
    private static final int AIM_N = 720, AIM_FINE = 41, AIM_WIN = 16;
    private static final double AIM_FINE_HALF = Math.toRadians(1.0);   // fine sweep covers +-1 degree
    private static float[] COS_T, SIN_T;
    private final float[] aimLens = new float[AIM_N];
    private final float[] fineLens = new float[AIM_FINE];
    private final double[] fineAng = new double[AIM_FINE];

    /** the game's aim line is pale, unsaturated and thin: lighter than the cloth in red AND blue, but not yellow like the stick */
    private static boolean isGuide(int p, int rr, int gg, int bb) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        return r > rr + 30 && b > bb + 30 && g > gg - 5 && Math.abs(r - b) <= 24 && Math.max(r, Math.max(g, b)) > 115;
    }

    private static float rayRun(int[] px, int w, int h, float cx, float cy, float R, float ux, float uy,
                                int rr, int gg, int bb, int maxD) {
        int d0 = (int) (1.3f * R), d1 = (int) (2.3f * R);
        int hits = 0;
        for (int k = d0; k < d1; k++) {
            int x = (int) (cx + ux * k + 0.5f), y = (int) (cy + uy * k + 0.5f);
            if (x < 0 || y < 0 || x >= w || y >= h) return 0;
            if (isGuide(px[y * w + x], rr, gg, bb)) hits++;
        }
        if (hits < 3) return 0;
        int gap = 0, last = d1;
        for (int k = d1; k < maxD; k++) {
            int x = (int) (cx + ux * k + 0.5f), y = (int) (cy + uy * k + 0.5f);
            if (x < 0 || y < 0 || x >= w || y >= h) break;
            if (isGuide(px[y * w + x], rr, gg, bb)) { last = k; gap = 0; }
            else if (++gap > 4) break;
        }
        return last;
    }

    private Aim detectAim(int[] px, int w, int h, Scene s) {
        if (COS_T == null) {
            COS_T = new float[AIM_N]; SIN_T = new float[AIM_N];
            for (int i = 0; i < AIM_N; i++) {
                double a = 2 * Math.PI * i / AIM_N;
                COS_T[i] = (float) Math.cos(a); SIN_T[i] = (float) Math.sin(a);
            }
        }
        final float R = s.R, cx = s.cue.x, cy = s.cue.y;
        final int rr = s.rr, gg = s.gg, bb = s.bb;
        final int maxD = (int) (1.6f * Math.max(s.Rt - s.L, s.B - s.T));
        float best = 0; int bestI = -1;
        for (int i = 0; i < AIM_N; i++) {
            float l = rayRun(px, w, h, cx, cy, R, COS_T[i], SIN_T[i], rr, gg, bb, maxD);
            aimLens[i] = l;
            if (l > best) { best = l; bestI = i; }
        }
        if (bestI < 0 || best < 3.2f * R) return null;
        // centre of the coarse rays that follow the same line as the best one (+-8 degrees)
        double sx = 0, sy = 0;
        for (int j = -AIM_WIN; j <= AIM_WIN; j++) {
            int i = (bestI + j + AIM_N) % AIM_N;
            if (aimLens[i] >= 0.9f * best) { sx += COS_T[i]; sy += SIN_T[i]; }
        }
        double th0 = Math.atan2(sy, sx);
        // stage 2: 41 fine rays around th0 (depends on stage 1, not on a fixed direction)
        float fbest = 0;
        for (int k = 0; k < AIM_FINE; k++) {
            double ang = th0 + (k - AIM_FINE / 2) * (AIM_FINE_HALF / (AIM_FINE / 2));
            fineAng[k] = ang;
            float l = rayRun(px, w, h, cx, cy, R, (float) Math.cos(ang), (float) Math.sin(ang), rr, gg, bb, maxD);
            fineLens[k] = l;
            if (l > fbest) fbest = l;
        }
        double th = th0;
        if (fbest >= 0.9f * best) {
            double fx = 0, fy = 0;
            for (int k = 0; k < AIM_FINE; k++)
                if (fineLens[k] >= 0.97f * fbest) { fx += Math.cos(fineAng[k]); fy += Math.sin(fineAng[k]); }
            if (fx != 0 || fy != 0) th = Math.atan2(fy, fx);
            best = Math.max(best, fbest);
        }
        // refine: fit a straight line through the centre of the aim line along its length
        double ux = Math.cos(th), uy = Math.sin(th), nx = -uy, ny = ux;
        double sd = 0, so = 0, sdd = 0, sdo = 0; int n = 0;
        for (int k = (int) (2.4f * R); k < best; k += 2) {
            double wsum = 0, osum = 0;
            for (int o = -4; o <= 4; o++) {
                int x = (int) (cx + ux * k + nx * o + 0.5), y = (int) (cy + uy * k + ny * o + 0.5);
                if (x < 0 || y < 0 || x >= w || y >= h) continue;
                int p = px[y * w + x];
                if (isGuide(p, rr, gg, bb)) { double wg = (p & 255) - bb; wsum += wg; osum += wg * o; }
            }
            if (wsum > 0) { double off = osum / wsum; sd += k; so += off; sdd += (double) k * k; sdo += k * off; n++; }
        }
        if (n >= 20) {
            double den = n * sdd - sd * sd;
            if (den > 1e-6) th += Math.atan((n * sdo - sd * so) / den);
        }
        Aim a = new Aim();
        a.angle = (float) th; a.ux = (float) Math.cos(th); a.uy = (float) Math.sin(th); a.run = best;
        return a;
    }

    // ------------------------------------------------------------------ main entry
    Scene analyse(Bitmap bitmap, long frameTimeMs) {
        if (bitmap == null || bitmap.isRecycled() || bitmap.getWidth() < 1 || bitmap.getHeight() < 1) {
            Scene failed = new Scene();
            failed.msg = "تعذر قراءة إطار الشاشة";
            return failed;
        }
        int w = bitmap.getWidth(), h = bitmap.getHeight();
        int required = w * h;
        if (bitmapPixels == null || bitmapPixels.length != required) bitmapPixels = new int[required];
        bitmap.getPixels(bitmapPixels, 0, w, 0, 0, w, h);
        return analyse(bitmapPixels, w, h, frameTimeMs);
    }

    Scene analyse(int[] px, int w, int h) {
        return analyse(px, w, h, System.currentTimeMillis());
    }

    Scene analyse(int[] px, int w, int h, long frameTimeMs) {
        if (px == null || w < 2 || h < 2 || (long) w * h > px.length) {
            Scene failed = new Scene();
            failed.msg = "أبعاد إطار غير صالحة";
            return failed;
        }
        updateWatch(px, w, h);
        Scene r;
        if (lastScene != null && lastScene.ok && lastW == w && lastH == h && lastIgnoreVersion == ignoreVersion
                && lastFp != 0 && fingerprint(px, w, h, lastScene) == lastFp) {
            r = lastScene;
        } else {
            Scene fresh = analyse0(px, w, h);
            fresh.timestampMs = frameTimeMs;
            heldNow = false;
            r = stabilize(fresh);
            lastScene = r; lastW = w; lastH = h; lastIgnoreVersion = ignoreVersion;
            lastFp = (r.ok && !heldNow) ? fingerprint(px, w, h, r) : 0;
        }
        Aim a = null;
        if (r.ok && r.cue != null) {
            try { a = detectAim(px, w, h, r); } catch (Throwable ignored) { a = null; }
            lastAim = stabilizeAim(a);
        } else {
            smAim = null; aimMiss = 0; aimPending = 0;
            lastAim = null;
        }
        return r;
    }

    // ------------------------------------------------------------------ temporal stability
    private Scene stableScene;
    private int heldFrames;
    private boolean heldNow;
    private Aim smAim;
    private int aimMiss, aimPending;
    private float aimPendingAngle;

    private static float wrapPi(float a) {
        while (a > Math.PI) a -= 2 * Math.PI;
        while (a < -Math.PI) a += 2 * Math.PI;
        return a;
    }

    private static long sigOf(List<Ball> balls) {
        long sig = 1125899906842597L;
        for (Ball b : balls) sig = sig * 31 + (Math.round(b.x / 2f) * 977L + Math.round(b.y / 2f) * 13L + b.kind);
        return sig;
    }

    /** removes sub-pixel jitter against the previous reading; a lost frame reuses the last REAL reading for at most 3 frames */
    Scene stabilize(Scene n) {
        Scene p = stableScene;
        if (!n.ok) {
            if (n.secure) { stableScene = null; heldFrames = 0; return n; }
            if (p != null && heldFrames < 3) { heldFrames++; heldNow = true; return p; }
            stableScene = null; heldFrames = 0;
            return n;
        }
        heldFrames = 0;
        if (p != null && p.ok) {
            if (Math.abs(n.L - p.L) < 2f && Math.abs(n.Rt - p.Rt) < 2f && Math.abs(n.T - p.T) < 2f && Math.abs(n.B - p.B) < 2f) {
                n.L = p.L; n.Rt = p.Rt; n.T = p.T; n.B = p.B;
                if (Math.abs(n.R - p.R) < 0.5f) n.R = p.R;
                for (int i = 0; i < 6; i++) {
                    if (Math.hypot(n.pockets[i][0] - p.pockets[i][0], n.pockets[i][1] - p.pockets[i][1]) < 2f) {
                        n.pockets[i][0] = p.pockets[i][0]; n.pockets[i][1] = p.pockets[i][1];
                        n.pocketRadii[i] = p.pocketRadii[i];
                    }
                }
            }
            boolean[] used = new boolean[p.balls.size()];
            long elapsed = Math.max(0L, Math.min(500L, n.timestampMs - p.timestampMs));
            float matchRadius = n.R * Math.max(4f, Math.min(12f, 2.5f + elapsed / 35f));
            float jumpRadius = n.R * Math.max(3f, Math.min(9f, 2.2f + elapsed / 45f));
            for (Ball b : n.balls) {
                int bi = -1; float bd = matchRadius;
                for (int i = 0; i < p.balls.size(); i++) {
                    if (used[i]) continue;
                    Ball pb = p.balls.get(i);
                    boolean cueMatch = (b.kind == CUE) == (pb.kind == CUE);
                    if (!cueMatch) continue;
                    float d = (float) Math.hypot(pb.x - b.x, pb.y - b.y);
                    if (d < bd) { bd = d; bi = i; }
                }
                if (bi < 0) continue;
                used[bi] = true;
                Ball pb = p.balls.get(bi);
                if (bd > jumpRadius) {
                    if (pb.pendingFrames > 0
                            && Math.hypot(b.x - pb.pendingX, b.y - pb.pendingY) < 0.55f * n.R) {
                        pb.pendingFrames++;
                    } else {
                        pb.pendingX = b.x;
                        pb.pendingY = b.y;
                        pb.pendingFrames = 1;
                    }
                    b.pendingX = pb.pendingX;
                    b.pendingY = pb.pendingY;
                    b.pendingFrames = pb.pendingFrames;
                    if (pb.pendingFrames < 2) {
                        b.x = pb.x;
                        b.y = pb.y;
                        b.confidence *= 0.9f;
                    } else {
                        b.x = pb.pendingX;
                        b.y = pb.pendingY;
                        b.pendingFrames = 0;
                        pb.pendingFrames = 0;
                    }
                } else {
                    pb.pendingFrames = 0;
                    b.pendingFrames = 0;
                    float alpha = bd < 0.08f * n.R ? 0.20f
                            : Math.max(0.38f, Math.min(0.78f, 0.38f + bd / (4f * n.R) * 0.42f));
                    b.x = pb.x + (b.x - pb.x) * alpha;
                    b.y = pb.y + (b.y - pb.y) * alpha;
                }
                boolean sameGroup = (b.kind == SOLID || b.kind == STRIPE) && (pb.kind == SOLID || pb.kind == STRIPE);
                if (sameGroup && b.kind != pb.kind && b.confidence < 0.8f) b.kind = pb.kind;
            }
            n.sig = sigOf(n.balls);
        }
        stableScene = n;
        return n;
    }

    /** keeps the aim line steady: tiny jitter is ignored, small moves are blended, big jumps need two agreeing frames */
    private Aim stabilizeAim(Aim raw) {
        if (raw == null) {
            if (smAim != null && ++aimMiss <= 2) return smAim;          // a missed frame or two: keep the last real reading
            smAim = null; aimPending = 0;
            return null;
        }
        aimMiss = 0;
        if (smAim == null) { smAim = raw; aimPending = 0; return raw; }
        float d = wrapPi(raw.angle - smAim.angle), ad = Math.abs(d);
        if (ad > 0.07f) {                                               // > ~4 degrees
            if (aimPending > 0 && Math.abs(wrapPi(raw.angle - aimPendingAngle)) < 0.03f) aimPending++;
            else { aimPending = 1; aimPendingAngle = raw.angle; }
            if (aimPending < 2) return smAim;
            smAim = raw; aimPending = 0;
            return raw;
        }
        aimPending = 0;
        float k = ad < 0.0004f ? 0f : (ad < 0.02f ? 0.5f : 0.75f);
        float na = smAim.angle + d * k;
        Aim o = new Aim();
        o.angle = na; o.ux = (float) Math.cos(na); o.uy = (float) Math.sin(na); o.run = raw.run;
        smAim = o;
        return o;
    }

    private Scene analyse0(int[] px, int w, int h) {
        Scene s = new Scene();
        if (isBlackFrame(px)) { s.secure = true; s.msg = "الشاشة محمية من التصوير 🔒"; return s; }

        // 1) cloth bounding box from row / column projections
        int[] colCnt = new int[w], rowCnt = new int[h];
        int maxC = 1, maxR = 1;
        for (int y = 0; y < h; y += 2) {
            for (int x = 0; x < w; x += 2) {
                if (isCloth(px[y * w + x])) { colCnt[x]++; rowCnt[y]++; }
            }
        }
        for (int x = 0; x < w; x++) maxC = Math.max(maxC, colCnt[x]);
        for (int y = 0; y < h; y++) maxR = Math.max(maxR, rowCnt[y]);
        int x0 = -1, x1 = -1, y0 = -1, y1 = -1, nx = 0, ny = 0;
        for (int x = 0; x < w; x++) if (colCnt[x] > 0.3 * maxC) nx++;
        for (int y = 0; y < h; y++) if (rowCnt[y] > 0.3 * maxR) ny++;
        int trimX = Math.max(0, nx / 100), trimY = Math.max(0, ny / 100), ix = 0, iy = 0;
        for (int x = 0; x < w; x++) if (colCnt[x] > 0.3 * maxC) {
            if (ix++ == trimX) x0 = x;
            x1 = x;
        }
        for (int y = 0; y < h; y++) if (rowCnt[y] > 0.3 * maxR) {
            if (iy++ == trimY) y0 = y;
            y1 = y;
        }
        if (nx > 2 * trimX) { int n = 0; for (int x = 0; x < w; x++) if (colCnt[x] > 0.3 * maxC && n++ == nx - trimX - 1) { x1 = x; break; } }
        if (ny > 2 * trimY) { int n = 0; for (int y = 0; y < h; y++) if (rowCnt[y] > 0.3 * maxR && n++ == ny - trimY - 1) { y1 = y; break; } }
        if (x0 < 0 || y0 < 0 || x1 - x0 < 0.3 * Math.min(w, h) || y1 - y0 < 0.3 * Math.min(w, h)) {
            s.msg = "ما لقيت طاولة بلياردو على الشاشة";
            return s;
        }
        float detectedAspect = Math.max((x1 - x0) / (float) Math.max(1, y1 - y0),
                (y1 - y0) / (float) Math.max(1, x1 - x0));
        if (detectedAspect < 1.25f || detectedAspect > 2.45f) {
            s.msg = "حدود سطح الطاولة غير مؤكدة";
            return s;
        }

        // 2) reference cloth colour (median of cloth pixels in the middle of the box)
        int[] hr = new int[256], hg = new int[256], hb = new int[256];
        int hn = 0, sampled = 0;
        for (int y = y0 + (y1 - y0) / 5; y < y1 - (y1 - y0) / 5; y += 3) {
            for (int x = x0 + (x1 - x0) / 5; x < x1 - (x1 - x0) / 5; x += 3) {
                sampled++;
                int p = px[y * w + x];
                if (!isCloth(p)) continue;
                hr[(p >> 16) & 255]++; hg[(p >> 8) & 255]++; hb[p & 255]++; hn++;
            }
        }
        float surfaceSupport = sampled == 0 ? 0f : hn / (float) sampled;
        if (hn < 200 || surfaceSupport < 0.30f) {
            s.msg = "سطح اللعب غير واضح — جرّب إظهار الطاولة كاملة";
            return s;
        }
        s.confidence = Math.min(1f, 0.55f + surfaceSupport * 0.45f);
        int rr = median(hr, hn), gg = median(hg, hn), bb = median(hb, hn);
        s.rr = rr; s.gg = gg; s.bb = bb;

        // 3) cushion thickness: how far in from the edge does the main cloth colour start
        float tl = 0, tr = 0, tt = 0, tb = 0;
        int[] fr = {35, 65};
        for (int k = 0; k < 2; k++) {
            int yy = y0 + (y1 - y0) * fr[k] / 100, xx = x0 + (x1 - x0) * fr[k] / 100;
            int a = 0; while (x0 + a < x1 && l1(px[yy * w + x0 + a], rr, gg, bb) > 40 && a < 60) a++;
            tl += a / 2f;
            a = 0; while (x1 - a > x0 && l1(px[yy * w + x1 - a], rr, gg, bb) > 40 && a < 60) a++;
            tr += a / 2f;
            a = 0; while (y0 + a < y1 && l1(px[(y0 + a) * w + xx], rr, gg, bb) > 40 && a < 60) a++;
            tt += a / 2f;
            a = 0; while (y1 - a > y0 && l1(px[(y1 - a) * w + xx], rr, gg, bb) > 40 && a < 60) a++;
            tb += a / 2f;
        }
        s.L = x0 + tl; s.Rt = x1 - tr; s.T = y0 + tt; s.B = y1 - tb;
        float tw = s.Rt - s.L, th = s.B - s.T;
        if (tw < 12f || th < 12f || Math.max(tw, th) / Math.max(1f, Math.min(tw, th)) < 1.25f
                || Math.max(tw, th) / Math.max(1f, Math.min(tw, th)) > 2.45f) {
            s.msg = "حدود سطح الطاولة غير مؤكدة";
            return s;
        }
        s.R = 0.0318f * Math.min(tw, th);
        float R = s.R;

        // 4) pockets: nominal positions, refined with the black blob around them
        float midY = (s.T + s.B) / 2f, midX = (s.L + s.Rt) / 2f;
        boolean portrait = th >= tw;
        float[][] nom;
        if (portrait) {
            nom = new float[][]{{s.L - .5f * R, s.T - .5f * R}, {s.Rt + .5f * R, s.T - .5f * R},
                    {s.L - .5f * R, s.B + .5f * R}, {s.Rt + .5f * R, s.B + .5f * R},
                    {s.L - 1.4f * R, midY}, {s.Rt + 1.4f * R, midY}};
        } else {
            nom = new float[][]{{s.L - .5f * R, s.T - .5f * R}, {s.Rt + .5f * R, s.T - .5f * R},
                    {s.L - .5f * R, s.B + .5f * R}, {s.Rt + .5f * R, s.B + .5f * R},
                    {midX, s.T - 1.4f * R}, {midX, s.B + 1.4f * R}};
        }
        for (int i = 0; i < 6; i++) {
            int rad = (int) (2.6f * R);
            int cx = (int) nom[i][0], cy = (int) nom[i][1];
            int[] hx = new int[2 * rad + 1], hy = new int[2 * rad + 1];
            int n = 0, minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
            int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
            for (int y = Math.max(0, cy - rad); y < Math.min(h, cy + rad); y += 2)
                for (int x = Math.max(0, cx - rad); x < Math.min(w, cx + rad); x += 2) {
                    int p = px[y * w + x];
                    if (((p >> 16) & 255) < 48 && ((p >> 8) & 255) < 48 && (p & 255) < 52
                            && (x - cx) * (x - cx) + (y - cy) * (y - cy) < rad * rad) {
                        hx[x - cx + rad]++; hy[y - cy + rad]++; n++;
                        minX = Math.min(minX, x); maxX = Math.max(maxX, x);
                        minY = Math.min(minY, y); maxY = Math.max(maxY, y);
                    }
                }
            float fx = nom[i][0], fy = nom[i][1];
            if (n > 40) {
                float mx = cx + medianOffset(hx, n) - rad, my = cy + medianOffset(hy, n) - rad;
                float dx = mx - fx, dy = my - fy, dl = (float) Math.hypot(dx, dy);
                float cap = 1.0f * R;
                if (dl > cap) { dx *= cap / dl; dy *= cap / dl; }
                fx += dx; fy += dy;
                s.pocketRadii[i] = Math.max(0.85f * R, Math.min(1.65f * R,
                        0.23f * Math.max(maxX - minX + 1, maxY - minY + 1)));
            } else {
                s.pocketRadii[i] = 1.2f * R;
            }
            s.pockets[i][0] = fx; s.pockets[i][1] = fy;
        }
        float[][] calibrated = manualPocketNormalized;
        if (calibrated != null) {
            for (int i = 0; i < 6; i++) {
                s.pockets[i][0] = calibrated[i][0] * (w - 1);
                s.pockets[i][1] = calibrated[i][1] * (h - 1);
                s.pocketRadii[i] = 1.25f * R;
            }
            s.manuallyCalibrated = true;
        }

        // 5) foreground mask (anything that is not cloth) inside the contact rectangle
        int rx0 = Math.max(0, (int) s.L), ry0 = Math.max(0, (int) s.T);
        int rx1 = Math.min(w, (int) s.Rt), ry1 = Math.min(h, (int) s.B);
        int rw = rx1 - rx0, rh = ry1 - ry0;
        if (rw < 50 || rh < 50) { s.msg = "الطاولة صغيرة جداً"; return s; }
        final int BS = 48;
        int bw = rw / BS + 1, bh = rh / BS + 1;
        int[][] bref = new int[bw * bh][];
        for (int by = 0; by < bh; by++) {
            for (int bx = 0; bx < bw; bx++) {
                long sr = 0, sg = 0, sb = 0; int n = 0;
                for (int y = ry0 + by * BS; y < Math.min(ry1, ry0 + (by + 1) * BS); y += 2)
                    for (int x = rx0 + bx * BS; x < Math.min(rx1, rx0 + (bx + 1) * BS); x += 2) {
                        int p = px[y * w + x];
                        if (isCloth(p) && l1(p, rr, gg, bb) < 80) { sr += (p >> 16) & 255; sg += (p >> 8) & 255; sb += p & 255; n++; }
                    }
                bref[by * bw + bx] = n > 25 ? new int[]{(int) (sr / n), (int) (sg / n), (int) (sb / n)} : new int[]{rr, gg, bb};
            }
        }
        byte[] mask = new byte[rw * rh];
        float[] seg = ignoreSegs;
        float[] ir = ignoreRect;
        for (int y = 0; y < rh; y++) {
            for (int x = 0; x < rw; x++) {
                int p = px[(ry0 + y) * w + rx0 + x];
                int[] ref = bref[(y / BS) * bw + (x / BS)];
                if (l1(p, ref[0], ref[1], ref[2]) > 58) mask[y * rw + x] = 1;
            }
        }
        // pocket jaws are black and overlap the corners of the rectangle: never balls
        float pr2 = (2.3f * R) * (2.3f * R);
        for (int i = 0; i < 6; i++) {
            int cx = (int) s.pockets[i][0] - rx0, cy = (int) s.pockets[i][1] - ry0, rad = (int) (2.4f * R) + 1;
            for (int y = Math.max(0, cy - rad); y < Math.min(rh, cy + rad); y++)
                for (int x = Math.max(0, cx - rad); x < Math.min(rw, cx + rad); x++)
                    if ((x - cx) * (x - cx) + (y - cy) * (y - cy) < pr2) mask[y * rw + x] = 0;
        }
        // our own arrow and panel are painted over the screen: treat them as cloth
        for (int i = 0; i + 3 < seg.length; i += 4) {
            float ax = seg[i] - rx0, ay = seg[i + 1] - ry0, bx = seg[i + 2] - rx0, by = seg[i + 3] - ry0;
            int steps = (int) Math.max(1, Math.hypot(bx - ax, by - ay) / 2);
            for (int k = 0; k <= steps; k++) {
                int cx = (int) (ax + (bx - ax) * k / steps), cy = (int) (ay + (by - ay) * k / steps);
                for (int yy = cy - 5; yy <= cy + 5; yy++) for (int xx = cx - 5; xx <= cx + 5; xx++)
                    if (xx >= 0 && yy >= 0 && xx < rw && yy < rh) mask[yy * rw + xx] = 0;
            }
        }
        if (ir != null) {
            for (int y = Math.max(0, (int) ir[1] - ry0); y < Math.min(rh, (int) ir[3] - ry0); y++)
                for (int x = Math.max(0, (int) ir[0] - rx0); x < Math.min(rw, (int) ir[2] - rx0); x++) mask[y * rw + x] = 0;
        }
        byte[] orig = mask.clone();

        // 6) circle fitting: best covered disc, erase it, repeat (works for touching balls too)
        int Ri = Math.max(4, Math.round(R));
        int[] dxs = new int[2 * Ri + 1];
        for (int dy = -Ri; dy <= Ri; dy++) dxs[dy + Ri] = (int) Math.floor(Math.sqrt(Ri * Ri - dy * dy + 0.01));
        int[] pref = new int[(rw + 1) * rh];
        for (int y = 0; y < rh; y++) for (int x = 0; x < rw; x++) pref[y * (rw + 1) + x + 1] = pref[y * (rw + 1) + x] + mask[y * rw + x];
        int margin = Math.max(1, Math.round(0.8f * R));
        int step = 2;
        int gx = (rw - 2 * margin) / step + 1, gy = (rh - 2 * margin) / step + 1;
        if (gx < 1 || gy < 1) { s.msg = "الطاولة صغيرة جداً"; return s; }
        float[] score = new float[gx * gy];
        float area = 0;
        for (int dy = -Ri; dy <= Ri; dy++) area += 2 * dxs[dy + Ri] + 1;
        for (int j = 0; j < gy; j++) for (int i = 0; i < gx; i++) score[j * gx + i] = disc(pref, rw, rh, margin + i * step, margin + j * step, Ri, dxs) / area;

        List<float[]> found = new ArrayList<>();
        for (int iter = 0; iter < 24; iter++) {
            int best = -1; float bs = 0.66f;
            for (int k = 0; k < score.length; k++) if (score[k] > bs) { bs = score[k]; best = k; }
            if (best < 0) break;
            // among near-equal candidates in a plateau prefer the middle of the plateau
            int bi = best % gx, bj = best / gx;
            double sx = 0, sy = 0; int cnt = 0;
            for (int j = Math.max(0, bj - 4); j <= Math.min(gy - 1, bj + 4); j++)
                for (int i = Math.max(0, bi - 4); i <= Math.min(gx - 1, bi + 4); i++)
                    if (score[j * gx + i] >= bs - 0.015f) { sx += i; sy += j; cnt++; }
            int ci = margin + (int) Math.round(sx / cnt) * step, cj = margin + (int) Math.round(sy / cnt) * step;
            found.add(new float[]{ci, cj, bs});
            // erase the disc from the mask and refresh the scores around it
            for (int dy = -Ri; dy <= Ri; dy++) {
                int yy = cj + dy;
                if (yy < 0 || yy >= rh) continue;
                for (int x = Math.max(0, ci - dxs[dy + Ri]); x <= Math.min(rw - 1, ci + dxs[dy + Ri]); x++) mask[yy * rw + x] = 0;
            }
            for (int yy = Math.max(0, cj - Ri); yy <= Math.min(rh - 1, cj + Ri); yy++)
                for (int x = 0; x < rw; x++) pref[yy * (rw + 1) + x + 1] = pref[yy * (rw + 1) + x] + mask[yy * rw + x];
            int ri0 = Math.max(0, (ci - 2 * Ri - margin) / step), ri1 = Math.min(gx - 1, (ci + 2 * Ri - margin) / step + 1);
            int rj0 = Math.max(0, (cj - 2 * Ri - margin) / step), rj1 = Math.min(gy - 1, (cj + 2 * Ri - margin) / step + 1);
            for (int j = rj0; j <= rj1; j++) for (int i = ri0; i <= ri1; i++)
                score[j * gx + i] = disc(pref, rw, rh, margin + i * step, margin + j * step, Ri, dxs) / area;
        }

        // 7) refine isolated balls with the centroid of their pixels, classify
        for (int k = 0; k < found.size(); k++) {
            float cx = found.get(k)[0], cy = found.get(k)[1];
            float shapeConfidence = found.get(k)[2];
            boolean alone = true;
            for (int q = 0; q < found.size(); q++)
                if (q != k && Math.hypot(found.get(q)[0] - cx, found.get(q)[1] - cy) < 3.2f * R) alone = false;
            if (alone) {
                for (int it = 0; it < 2; it++) {
                    double sx = 0, sy = 0; int n = 0;
                    int rad = (int) (1.25f * R);
                    for (int y = Math.max(0, (int) cy - rad); y <= Math.min(rh - 1, (int) cy + rad); y++)
                        for (int x = Math.max(0, (int) cx - rad); x <= Math.min(rw - 1, (int) cx + rad); x++)
                            if (orig[y * rw + x] != 0 && (x - cx) * (x - cx) + (y - cy) * (y - cy) <= rad * rad) { sx += x; sy += y; n++; }
                    if (n > 0.5 * area) { cx = (float) (sx / n); cy = (float) (sy / n); }
                }
            }
            Ball b = new Ball();
            b.x = rx0 + cx + 0.5f; b.y = ry0 + cy + 0.5f;
            b.radius = R;
            classify(b, px, w, h, R, shapeConfidence);
            if (b.confidence >= 0.48f) s.balls.add(b);
        }

        if (s.balls.size() > 16) {
            s.balls.clear();
            s.msg = "الكشف غير موثوق — ظهرت أجسام أكثر من عدد كرات الطاولة";
            s.confidence = 0f;
            return s;
        }

        // with all 14 coloured balls on the table exactly 7 are stripes: take the 7 with the most white on their rim
        List<Ball> col14 = new ArrayList<>();
        for (Ball b : s.balls) if (b.kind == SOLID || b.kind == STRIPE) col14.add(b);
        if (col14.size() == 14) {
            java.util.Collections.sort(col14, new java.util.Comparator<Ball>() {
                @Override public int compare(Ball a, Ball b) { return Float.compare(b.ring, a.ring); }
            });
            for (int i = 0; i < 14; i++) col14.get(i).kind = i < 7 ? STRIPE : SOLID;
        }

        // 8) the cue ball (the whitest), rack detection, signature
        float bestWhite = 0;
        for (Ball b : s.balls) {
            if (b.kind == CUE && b.white > 0.80f && b.confidence >= 0.56f
                    && b.white * b.confidence > bestWhite) {
                bestWhite = b.white * b.confidence;
                s.cue = b;
            }
        }
        for (Ball b : s.balls) if (b.kind == CUE && b != s.cue) b.kind = STRIPE;
        int close = 0; double ax = 0, ay = 0;
        for (Ball a : s.balls) {
            for (Ball b : s.balls) if (a != b && Math.hypot(a.x - b.x, a.y - b.y) < 2.3f * R) { close++; ax += a.x; ay += a.y; break; }
        }
        if (close >= 9) { s.rack = true; s.rackX = (float) (ax / close); s.rackY = (float) (ay / close); }
        long sig = sigOf(s.balls);
        s.sig = sig;
        s.ok = true;
        s.confidence *= s.balls.isEmpty() ? 0.55f : 0.85f + Math.min(0.15f, s.balls.size() * 0.01f);
        s.msg = s.cue == null ? s.balls.size() + " كرة — لم تتأكد الكرة البيضاء" : s.balls.size() + " كرة";
        return s;
    }

    private static int disc(int[] pref, int rw, int rh, int cx, int cy, int R, int[] dxs) {
        int sum = 0;
        for (int dy = -R; dy <= R; dy++) {
            int y = cy + dy;
            if (y < 0 || y >= rh) continue;
            int dx = dxs[dy + R];
            int a = Math.max(0, cx - dx), b = Math.min(rw, cx + dx + 1);
            sum += pref[y * (rw + 1) + b] - pref[y * (rw + 1) + a];
        }
        return sum;
    }

    private static int median(int[] hist, int n) {
        int acc = 0;
        for (int i = 0; i < 256; i++) { acc += hist[i]; if (acc * 2 >= n) return i; }
        return 128;
    }

    private static int medianOffset(int[] hist, int n) {
        int acc = 0;
        for (int i = 0; i < hist.length; i++) {
            acc += hist[i];
            if (acc * 2 >= n) return i;
        }
        return hist.length / 2;
    }

    private static void classify(Ball b, int[] px, int w, int h, float R, float shapeConfidence) {
        int n = 0, white = 0, dark = 0, col = 0, rn = 0, rwhite = 0;
        int rad = (int) (0.92f * R);
        float inner = 0.55f * R, core = 0.72f * R;
        for (int dy = -rad; dy <= rad; dy++) {
            for (int dx = -rad; dx <= rad; dx++) {
                float d2 = dx * dx + dy * dy;
                if (d2 > rad * rad) continue;
                int x = (int) b.x + dx, y = (int) b.y + dy;
                if (x < 0 || y < 0 || x >= w || y >= h) continue;
                int p = px[y * w + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, bl = p & 255;
                int mx = Math.max(r, Math.max(g, bl)), mn = Math.min(r, Math.min(g, bl));
                boolean isWhite = mn > 150 && mx - mn < 60;
                if (d2 <= core * core) {
                    n++;
                    if (isWhite) white++; else if (mx < 80) dark++; else col++;
                }
                if (d2 >= inner * inner) { rn++; if (isWhite) rwhite++; }
            }
        }
        if (n == 0 || rn == 0) { b.kind = SOLID; b.confidence = 0f; return; }
        b.white = white / (float) n; b.dark = dark / (float) n;
        b.ring = rwhite / (float) rn;
        float classConfidence;
        if (b.white > 0.72f) {
            b.kind = CUE;
            classConfidence = Math.min(1f, 0.48f + Math.max(0f, b.white - 0.72f) * 1.7f);
        } else if (b.dark > 0.55f) {
            b.kind = EIGHT;
            classConfidence = Math.min(1f, 0.50f + (b.dark - 0.55f) * 1.6f);
        } else if (b.ring > RING_STRIPE) {
            b.kind = STRIPE;
            classConfidence = Math.min(1f, 0.50f + (b.ring - RING_STRIPE) * 1.4f);
        } else {
            b.kind = SOLID;
            classConfidence = Math.min(1f, 0.50f + (RING_STRIPE - b.ring) * 1.8f);
        }
        b.confidence = (float) Math.sqrt(Math.max(0f, shapeConfidence) * classConfidence);
    }
    static float RING_STRIPE = 0.19f;
}
