package com.pooloverlay.app;

import java.util.List;

/**
 * Geometric "AI simulator" layer on top of the planner. It is NOT a trained model: it scores every candidate with
 * four measurable features (reach, obstacle clearance, geometric validity, aim-error robustness) and uses the result
 * to demote risky shots. Plug a trained model in later with {@link #setEvaluator} without touching the rest.
 */
final class PoolSimAI {
    private static final int MAX_CANDIDATES = 12;
    private static final float[] SWEEP = {-0.024f, -0.018f, -0.012f, -0.006f, 0f, 0.006f, 0.012f, 0.018f, 0.024f};

    static final class Features {
        float reach = 1f, clearance = 1f, validity = 1f, robustness = 1f;
    }

    /** extension point: return 0..1 quality for a plan given its measured features (default = built-in blend) */
    interface Evaluator { float quality(PoolVision.Scene s, PoolPlanner.Plan p, Features f); }

    private static volatile Evaluator evaluator = new Evaluator() {
        @Override public float quality(PoolVision.Scene s, PoolPlanner.Plan p, Features f) {
            return f.validity * (0.55f + 0.45f * f.reach) * (0.6f + 0.4f * f.clearance) * (0.45f + 0.55f * f.robustness);
        }
    };

    private PoolSimAI() { }

    static void setEvaluator(Evaluator e) { if (e != null) evaluator = e; }

    /** plans must already be sorted best-first (PoolPhysics.refine does that); only the top candidates are scored */
    static void evaluate(PoolVision.Scene s, List<PoolPlanner.Plan> plans, PoolMemory memory) {
        if (s == null || !s.ok || s.cue == null || plans == null) return;
        int n = Math.min(MAX_CANDIDATES, plans.size());
        for (int i = 0; i < n; i++) {
            PoolPlanner.Plan p = plans.get(i);
            if (p.type == PoolPlanner.BREAK || p.type == PoolPlanner.TOUCH) continue;
            try {
                Features f = measure(s, p);
                float q = evaluator.quality(s, p, f);
                if (p.afterScratch) q *= 0.55f;
                if (memory != null) {                                   // blend in what this device has learned from real results
                    int n0 = memory.aiSamples();
                    if (n0 >= 8) {
                        float a = Math.min(0.6f, n0 / 60f);
                        q = (1f - a) * q + a * predict(memory.aiWeights(), f);
                    }
                }
                q = Math.max(0f, Math.min(1f, q));
                p.ai = q;
                p.score = Math.max(0f, Math.min(0.97f, p.score * (0.65f + 0.35f * q)));
            } catch (Throwable ignored) { /* never break planning because of the scorer */ }
        }
    }

    private static float predict(float[] w, Features f) {
        double z = w[0] * f.reach + w[1] * f.clearance + w[2] * f.validity + w[3] * f.robustness + w[4];
        return (float) (1.0 / (1.0 + Math.exp(-z)));
    }

    /** online learning: one gradient step of logistic regression per real shot result (pot = 1, miss = 0) */
    static void learn(PoolVision.Scene before, PoolPlanner.Plan plan, boolean potted, PoolMemory memory) {
        if (before == null || plan == null || memory == null || !before.ok || before.cue == null || plan.target == null) return;
        if (plan.type != PoolPlanner.DIRECT && plan.type != PoolPlanner.BANK && plan.type != PoolPlanner.KICK) return;
        try {
            Features f = measure(before, plan);
            float[] w = memory.aiWeights();
            float err = (potted ? 1f : 0f) - predict(w, f), lr = 0.12f;
            w[0] += lr * err * f.reach; w[1] += lr * err * f.clearance; w[2] += lr * err * f.validity;
            w[3] += lr * err * f.robustness; w[4] += lr * err;
            for (int i = 0; i < w.length; i++) w[i] = Math.max(-6f, Math.min(6f, w[i]));
            memory.saveAiWeights(w, memory.aiSamples() + 1);
        } catch (Throwable ignored) { }
    }

    static Features measure(PoolVision.Scene s, PoolPlanner.Plan p) {
        final float R = s.R;
        Features f = new Features();
        float ax = p.hasK ? p.kx : p.gx, ay = p.hasK ? p.ky : p.gy;

        // reach: soft clearance of the cue ball's path to the first aim point(s)
        float m1 = clearance(s, p.target, s.cue.x, s.cue.y, ax, ay, R);
        if (p.hasK) m1 = Math.min(m1, clearance(s, p.target, ax, ay, p.gx, p.gy, R));
        f.reach = m1 <= 0 ? 0f : Math.min(1f, 0.5f + 0.5f * m1);

        // obstacles: the object ball's way to the pocket (via the cushion for banks)
        float m2;
        if (p.hasB) m2 = Math.min(clearance(s, p.target, p.ox, p.oy, p.bx, p.by, R), clearance(s, p.target, p.bx, p.by, p.px, p.py, R));
        else m2 = clearance(s, p.target, p.ox, p.oy, p.px, p.py, R);
        f.clearance = m2 <= 0 ? 0f : Math.min(1f, 0.4f + 0.6f * m2);

        // geometric validity: ghost ball on the cloth, sane cut, not aimed into a pocket mouth
        float v = 1f;
        float slack = 0.3f * R;
        if (p.gx < s.L + R - slack || p.gx > s.Rt - R + slack || p.gy < s.T + R - slack || p.gy > s.B - R + slack) v *= 0.3f;
        if (p.cut > 70f) v *= 0.55f; else if (p.cut > 55f) v *= 0.8f;
        if (PoolPlanner.nearPocket(s, p.gx, p.gy, 1.2f * R)) v *= 0.4f;
        f.validity = v;

        // robustness: sweep the aim angle +-1.4 degrees and see how often the shot still works (straight pots analysed exactly)
        f.robustness = robustness(s, p, ax, ay);
        return f;
    }

    /** min over other balls of (distance to segment - 2R) in ball radii; <= 0 means blocked */
    private static float clearance(PoolVision.Scene s, PoolVision.Ball skip, float ax, float ay, float bx, float by, float R) {
        float best = 4f;
        for (PoolVision.Ball b : s.balls) {
            if (b == skip || b == s.cue) continue;
            float d = PoolPlanner.distSeg(b.x, b.y, ax, ay, bx, by);
            if (d < 2f * R * 0.96f && PoolPlanner.nearPocket(s, bx, by, 1f)) continue;   // sitting in the pocket mouth
            best = Math.min(best, (d - 2f * R) / R);
        }
        return best;
    }

    private static float robustness(PoolVision.Scene s, PoolPlanner.Plan p, float aimX, float aimY) {
        final float R = s.R, cx = s.cue.x, cy = s.cue.y;
        float base = (float) Math.atan2(aimY - cy, aimX - cx);
        int pocket = -1; float pd = 1e9f;
        for (int i = 0; i < 6; i++) {
            float d = (float) Math.hypot(p.px - s.pockets[i][0], p.py - s.pockets[i][1]);
            if (d < pd) { pd = d; pocket = i; }
        }
        float pr = pocket >= 0 && s.pocketRadii[pocket] > 0 ? s.pocketRadii[pocket] : 1.2f * R;
        int ok = 0;
        for (float e : SWEEP) {
            float a = base + e, dx = (float) Math.cos(a), dy = (float) Math.sin(a);
            // first hit of the cue ball's centre line with the circle of radius 2R around the object ball
            float ox = p.ox - cx, oy = p.oy - cy;
            float proj = ox * dx + oy * dy;
            if (p.hasK) { ok += 1; continue; }                       // kick: first leg ends on the cushion, judged by the sweep below only for hits
            if (proj <= 0) continue;
            float perp2 = ox * ox + oy * oy - proj * proj;
            float h2 = 4 * R * R - perp2;
            if (h2 <= 0) continue;                                    // aim error: cue ball misses the object ball
            if (p.hasB) { ok += 1; continue; }                        // bank: contact is enough here
            float t = proj - (float) Math.sqrt(h2);
            float qx = cx + dx * t, qy = cy + dy * t;                 // cue ball centre at contact
            float ux = p.ox - qx, uy = p.oy - qy, ul = (float) Math.hypot(ux, uy);
            if (ul < 1e-3f) continue;
            ux /= ul; uy /= ul;
            float px = p.px - p.ox, py = p.py - p.oy;
            float along = px * ux + py * uy;
            if (along <= 0) continue;
            float off = Math.abs(px * uy - py * ux);                  // distance of pocket centre from the object ball's line
            if (off < Math.max(0.3f * R, pr - 0.6f * R)) ok++;
        }
        return ok / (float) SWEEP.length;
    }
}
