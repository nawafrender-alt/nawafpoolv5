package com.pooloverlay.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Shot planner: straight pots, one-cushion banks, kick shots (cue ball off a cushion first), break and a safe fallback. */
final class PoolPlanner {
    static final int DIRECT = 0, BANK = 1, KICK = 2, TOUCH = 3, BREAK = 4;

    static final class Plan {
        int type;
        PoolVision.Ball target;
        float cx, cy;                 // cue ball
        float kx, ky; boolean hasK;   // cue ball cushion point (kick)
        float gx, gy;                 // where the cue ball must touch the object ball (ghost ball centre)
        float ox, oy;                 // object ball
        float bx, by; boolean hasB;   // object ball cushion point (bank)
        float px, py;                 // pocket
        float score;                  // uncalibrated geometric ranking score, not a success probability
        float ai = 1f;                // PoolSimAI quality 0..1 (geometry, reach, obstacles, robustness)
        int power;                    // 20..100
        float cut;                    // degrees
        boolean scratchRisk;
        float[] cueAfter = new float[0];
        boolean afterScratch;
        String note = "";
    }

    // group: 0 = any, 1 = solids, 2 = stripes, 3 = 8-ball
    static List<Plan> plan(PoolVision.Scene s, int group, boolean full, PoolMemory memory) {
        List<Plan> out = new ArrayList<>();
        if (!s.ok || s.cue == null || s.confidence < 0.48f || s.cue.confidence < 0.56f) return out;
        final float R = s.R;
        final float Lc = s.L + R, Rc = s.Rt - R, Tc = s.T + R, Bc = s.B - R;
        final float len = Math.max(s.Rt - s.L, s.B - s.T);
        final float cx = s.cue.x, cy = s.cue.y;

        if (s.rack) {                                        // break: hit the front ball of the triangle squarely
            PoolVision.Ball apex = null; float bd = 1e9f;
            for (PoolVision.Ball b : s.balls) {
                if (b == s.cue) continue;
                float d = (float) Math.hypot(b.x - cx, b.y - cy);
                if (d < bd) { bd = d; apex = b; }
            }
            if (apex != null) {
                Plan p = new Plan();
                p.type = BREAK; p.target = apex;
                p.cx = cx; p.cy = cy; p.ox = apex.x; p.oy = apex.y;
                float dx = apex.x - cx, dy = apex.y - cy, dl = (float) Math.hypot(dx, dy);
                p.gx = apex.x - dx / dl * 2 * R; p.gy = apex.y - dy / dl * 2 * R;
                p.px = apex.x; p.py = apex.y;
                p.score = 0.9f; p.power = 86; p.note = "كسر: ضربة قوية على رأس المثلث";
                out.add(p);
                return out;
            }
        }

        List<PoolVision.Ball> targets = new ArrayList<>();
        int solids = 0, stripes = 0;
        for (PoolVision.Ball b : s.balls) { if (b.kind == PoolVision.SOLID) solids++; if (b.kind == PoolVision.STRIPE) stripes++; }
        for (PoolVision.Ball b : s.balls) {
            if (b == s.cue) continue;
            if (b.confidence < 0.52f) continue;
            boolean ok;
            switch (group) {
                case 1: ok = b.kind == PoolVision.SOLID || (solids == 0 && b.kind == PoolVision.EIGHT); break;
                case 2: ok = b.kind == PoolVision.STRIPE || (stripes == 0 && b.kind == PoolVision.EIGHT); break;
                case 3: ok = b.kind == PoolVision.EIGHT; break;
                default: ok = b.kind != PoolVision.EIGHT || (solids + stripes == 0);
            }
            if (ok) targets.add(b);
        }

        float slack = 0f;
        for (PoolVision.Ball o : targets) {
            for (int pi = 0; pi < 6; pi++) {
                float px = s.pockets[pi][0], py = s.pockets[pi][1];
                boolean side = pi >= 4;
                // ---------- straight pot
                float dx = px - o.x, dy = py - o.y, dl = (float) Math.hypot(dx, dy);
                if (dl > 2 * R) {
                    float ux = dx / dl, uy = dy / dl;
                    PoolGeometry.Point ghost = PoolGeometry.ghostBall(o.x, o.y, px, py, R, R);
                    float gx = ghost == null ? Float.NaN : ghost.x;
                    float gy = ghost == null ? Float.NaN : ghost.y;
                    float pf = pocketFactor(s, pi, ux, uy);
                    if (pf > 0 && inside(gx, gy, Lc, Tc, Rc, Bc, slack)
                            && clearPath(s, o, px, py, o.x, o.y, true, R)) {
                        // direct
                        float ax = gx - cx, ay = gy - cy, al = (float) Math.hypot(ax, ay);
                        if (al > 1) {
                            float cosT = (ax * ux + ay * uy) / al;
                            if (cosT > 0.17f && clearPath(s, o, gx, gy, cx, cy, false, R)
                                    && approachAvoidsTarget(s, o, cx, cy, gx, gy, R)) {
                                Plan p = base(DIRECT, s, o, gx, gy, px, py);
                                p.cut = deg(cosT);
                                p.score = 0.97f * (float) Math.pow(cosT, 1.6)
                                        * (float) Math.exp(-(0.9f * al + 1.6f * dl) / len) * pf;
                                p.power = power(al + dl, len, 0);
                                scratch(s, p, ux, uy, ax / al, ay / al, R);
                                out.add(p);
                            }
                        }
                        // kick: cue ball off one cushion first, then pots straight
                        if (full) kicks(s, out, o, gx, gy, px, py, ux, uy, pf, dl, len, R, Lc, Tc, Rc, Bc);
                    }
                }
                // ---------- one-cushion bank for the object ball
                if (full) banks(s, out, o, pi, side, len, R, Lc, Tc, Rc, Bc, slack);
            }
        }

        Collections.sort(out, new Comparator<Plan>() {
            @Override public int compare(Plan a, Plan b) { return Float.compare(b.score, a.score); }
        });
        attachCueLeavePaths(s, out);
        PoolPhysics.refine(s, out, memory);
        PoolSimAI.evaluate(s, out, memory);
        Collections.sort(out, new Comparator<Plan>() {
            @Override public int compare(Plan a, Plan b) { return Float.compare(b.score, a.score); }
        });
        // keep the best few, one per (target,type)
        List<Plan> keep = new ArrayList<>();
        for (Plan p : out) {
            boolean dup = false;
            for (Plan k : keep) if (k.target == p.target && k.type == p.type) dup = true;
            if (!dup && (p.type == BREAK || p.type == TOUCH || p.score >= 0.18f)) keep.add(p);
            if (keep.size() >= 3) break;
        }
        if (keep.isEmpty()) {            // no credible pot: show a clear uncertainty state unless a safe touch exists
            PoolVision.Ball near = null; float bd = 1e9f;
            for (PoolVision.Ball o : targets) {
                if (o.confidence < 0.62f) continue;
                float d = (float) Math.hypot(o.x - cx, o.y - cy);
                if (d < bd && clearPath(s, o, o.x, o.y, cx, cy, false, R)) { bd = d; near = o; }
            }
            if (near != null) {
                Plan p = new Plan();
                p.type = TOUCH; p.target = near;
                p.cx = cx; p.cy = cy; p.ox = near.x; p.oy = near.y; p.gx = near.x; p.gy = near.y;
                p.px = near.x; p.py = near.y; p.score = 0.10f; p.power = 28;
                p.note = "ما فيه إدخال مضمون — دفاع: المس أقرب كرة بخفة";
                keep.add(p);
            }
        }
        return keep;
    }

    // ------------------------------------------------------------------ banks
    private static void banks(PoolVision.Scene s, List<Plan> out, PoolVision.Ball o, int pi, boolean side, float len,
                              float R, float Lc, float Tc, float Rc, float Bc, float slack) {
        float px = s.pockets[pi][0], py = s.pockets[pi][1];
        float cx = s.cue.x, cy = s.cue.y;
        for (int w = 0; w < 4; w++) {                         // 0 left, 1 right, 2 top, 3 bottom cushion
            float mx, my;                                      // pocket mirrored across the cushion line
            switch (w) {
                case 0: mx = 2 * Lc - px; my = py; break;
                case 1: mx = 2 * Rc - px; my = py; break;
                case 2: mx = px; my = 2 * Tc - py; break;
                default: mx = px; my = 2 * Bc - py;
            }
            float dx = mx - o.x, dy = my - o.y;
            float t;
            if (w < 2) { float line = w == 0 ? Lc : Rc; if (Math.abs(dx) < 1e-3f) continue; t = (line - o.x) / dx; }
            else { float line = w == 2 ? Tc : Bc; if (Math.abs(dy) < 1e-3f) continue; t = (line - o.y) / dy; }
            if (t <= 0.02f || t >= 0.98f) continue;
            float hx = o.x + dx * t, hy = o.y + dy * t;
            // bounce point must be on the cushion, away from pocket mouths
            float m = 1.7f * R;
            if (hx < Lc + (w < 2 ? 0 : m) || hx > Rc - (w < 2 ? 0 : m) || hy < Tc + (w >= 2 ? 0 : m) || hy > Bc - (w >= 2 ? 0 : m)) continue;
            if (nearPocket(s, hx, hy, 1.9f * R)) continue;
            float d1 = (float) Math.hypot(hx - o.x, hy - o.y), d2 = (float) Math.hypot(px - hx, py - hy);
            if (d1 < 2.5f * R || d2 < 1.5f * R) continue;
            float ux = (hx - o.x) / d1, uy = (hy - o.y) / d1;
            float vx = (px - hx) / d2, vy = (py - hy) / d2;
            float pf = pocketFactor(s, pi, vx, vy);
            if (pf <= 0) continue;
             PoolGeometry.Point ghost = PoolGeometry.ghostBall(o.x, o.y, hx, hy, R, R);
             if (ghost == null) continue;
             float gx = ghost.x, gy = ghost.y;
            if (!inside(gx, gy, Lc, Tc, Rc, Bc, slack)) continue;
            float ax = gx - cx, ay = gy - cy, al = (float) Math.hypot(ax, ay);
            if (al < 1) continue;
            float cosT = (ax * ux + ay * uy) / al;
            if (cosT < 0.35f) continue;
            if (!clearPath(s, o, gx, gy, cx, cy, false, R)) continue;
            if (!approachAvoidsTarget(s, o, cx, cy, gx, gy, R)) continue;
            if (!clearPath(s, o, hx, hy, o.x, o.y, true, R)) continue;
            if (!clearPath(s, o, px, py, hx, hy, true, R)) continue;
            Plan p = base(BANK, s, o, gx, gy, px, py);
            p.bx = hx; p.by = hy; p.hasB = true;
            p.cut = deg(cosT);
            p.score = 0.55f * (float) Math.pow(cosT, 1.6) * (float) Math.exp(-0.9f * al / len)
                    * (float) Math.exp(-(d1 + d2) / (0.9f * len)) * pf;
            p.power = power(al + d1 + d2, len, 12);
            p.note = "بنك: الكرة تضرب الجدار وترجع تدخل";
            out.add(p);
        }
    }

    // ------------------------------------------------------------------ kicks
    private static void kicks(PoolVision.Scene s, List<Plan> out, PoolVision.Ball o, float gx, float gy, float px, float py,
                              float ux, float uy, float pf, float dl, float len, float R, float Lc, float Tc, float Rc, float Bc) {
        float cx = s.cue.x, cy = s.cue.y;
        for (int w = 0; w < 4; w++) {
            float mx, my;
            switch (w) {
                case 0: mx = 2 * Lc - gx; my = gy; break;
                case 1: mx = 2 * Rc - gx; my = gy; break;
                case 2: mx = gx; my = 2 * Tc - gy; break;
                default: mx = gx; my = 2 * Bc - gy;
            }
            float dx = mx - cx, dy = my - cy, t;
            if (w < 2) { float line = w == 0 ? Lc : Rc; if (Math.abs(dx) < 1e-3f) continue; t = (line - cx) / dx; }
            else { float line = w == 2 ? Tc : Bc; if (Math.abs(dy) < 1e-3f) continue; t = (line - cy) / dy; }
            if (t <= 0.02f || t >= 0.98f) continue;
            float kx = cx + dx * t, ky = cy + dy * t;
            if (kx < Lc || kx > Rc || ky < Tc || ky > Bc) continue;
            float m = 1.7f * R;
            if (w < 2 ? (ky < Tc + m || ky > Bc - m) : (kx < Lc + m || kx > Rc - m)) continue;
            if (nearPocket(s, kx, ky, 1.9f * R)) continue;
            float d1 = (float) Math.hypot(kx - cx, ky - cy), d2 = (float) Math.hypot(gx - kx, gy - ky);
            if (d1 < 2 * R || d2 < 1.5f * R) continue;
            float ax = (gx - kx) / d2, ay = (gy - ky) / d2;
            float cosT = ax * ux + ay * uy;
            if (cosT < 0.3f) continue;
            if (!clearPath(s, o, kx, ky, cx, cy, false, R)) continue;
            if (!clearPath(s, o, gx, gy, kx, ky, false, R)) continue;
            if (!approachAvoidsTarget(s, o, cx, cy, kx, ky, R)
                    || !approachAvoidsTarget(s, o, kx, ky, gx, gy, R)) continue;
            Plan p = base(KICK, s, o, gx, gy, px, py);
            p.kx = kx; p.ky = ky; p.hasK = true;
            p.cut = deg(cosT);
            p.score = 0.30f * (float) Math.pow(cosT, 1.6)
                    * (float) Math.exp(-(0.9f * (d1 + d2) + 1.6f * dl) / len) * pf;
            p.power = power(d1 + d2 + dl, len, 6);
            p.note = "ضرب من الجدار: الأبيض يلمس الجدار أولاً ثم الكرة";
            out.add(p);
        }
    }

    // ------------------------------------------------------------------ helpers
    private static Plan base(int type, PoolVision.Scene s, PoolVision.Ball o, float gx, float gy, float px, float py) {
        Plan p = new Plan();
        p.type = type; p.target = o;
        p.cx = s.cue.x; p.cy = s.cue.y; p.gx = gx; p.gy = gy;
        p.ox = o.x; p.oy = o.y; p.px = px; p.py = py;
        return p;
    }

    private static boolean inside(float x, float y, float l, float t, float r, float b, float slack) {
        return PoolGeometry.insideBallCenterBounds(x, y, l, t, r, b, -slack);
    }

    private static float deg(float cos) { return (float) Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, cos)))); }

    private static int power(float total, float len, int extra) {
        float reach = Math.min(1f, Math.max(0f, total / (1.8f * len)));
        float v = 28f + 52f * (float) Math.sqrt(reach) + Math.min(5, extra / 3);
        return Math.max(25, Math.min(84, Math.round(v)));
    }

    static boolean nearPocket(PoolVision.Scene s, float x, float y, float r) {
        for (int i = 0; i < 6; i++) {
            float measured = s.pocketRadii[i] > 0 ? s.pocketRadii[i] + 0.25f * s.R : 0;
            if (Math.hypot(x - s.pockets[i][0], y - s.pockets[i][1]) < Math.max(r, measured)) return true;
        }
        return false;
    }

    /** the ball must enter the pocket mouth at a sensible angle (corner pockets ~ diagonal, side pockets ~ straight) */
    static float pocketFactor(PoolVision.Scene s, int pi, float ux, float uy) {
        float mx = (s.L + s.Rt) / 2f, my = (s.T + s.B) / 2f;
        float ox = s.pockets[pi][0] - mx, oy = s.pockets[pi][1] - my;
        if (pi >= 4) {                                        // side pocket: outward axis is along the short direction
            if (Math.abs(ox) > Math.abs(oy)) { oy = 0; } else { ox = 0; }
        }
        float ol = (float) Math.hypot(ox, oy);
        if (ol < 1) return 0;
        float cos = (ux * ox + uy * oy) / ol;
        float limit = pi >= 4 ? 0.52f : 0.42f;               // cos(58°) / cos(65°)
        if (cos < limit) return 0;
        return (float) Math.pow(cos, 0.8);
    }

    /** segment a->b must stay 2R away from every other ball (except `skip` and the cue ball unless `includeCue`) */
    static boolean clearPath(PoolVision.Scene s, PoolVision.Ball skip, float bx, float by, float ax, float ay,
                             boolean objectPath, float R) {
        float left = s.L + R, right = s.Rt - R, top = s.T + R, bottom = s.B - R;
        int pocketIndex = endpointPocket(s, bx, by);
        if (pocketIndex >= 0) {
            float pocketRadius = Math.max(1.35f * R, s.pocketRadii[pocketIndex] + 1.1f * R);
            if (!PoolGeometry.routeToPocketInside(ax, ay, bx, by, left, top, right, bottom,
                    s.pockets[pocketIndex][0], s.pockets[pocketIndex][1], pocketRadius, 0.4f * R)) return false;
        } else if (!segmentInside(s, ax, ay, bx, by, R)) {
            return false;
        }
        for (PoolVision.Ball b : s.balls) {
            if (b == skip) continue;
            if (b == s.cue) continue;
            float obstacleRadius = b.radius > 0f ? b.radius : R;
            float clearance = PoolGeometry.pointSegmentDistance(b.x, b.y, ax, ay, bx, by);
            if (clearance < R + obstacleRadius - 0.08f * R) {
                return false;
            }
        }
        return true;
    }

    static float distSeg(float px, float py, float ax, float ay, float bx, float by) {
        return PoolGeometry.pointSegmentDistance(px, py, ax, ay, bx, by);
    }

    static boolean approachAvoidsTarget(PoolVision.Scene s, PoolVision.Ball target,
                                        float ax, float ay, float bx, float by, float R) {
        float targetRadius = target.radius > 0f ? target.radius : R;
        float required = R + targetRadius - 0.08f * R;
        return PoolGeometry.pointSegmentDistance(target.x, target.y, ax, ay, bx, by) >= required;
    }

    private static boolean segmentInside(PoolVision.Scene s, float ax, float ay, float bx, float by, float R) {
        float left = s.L + R, right = s.Rt - R, top = s.T + R, bottom = s.B - R;
        return ax >= left && ax <= right && ay >= top && ay <= bottom
                && bx >= left && bx <= right && by >= top && by <= bottom;
    }

    private static int endpointPocket(PoolVision.Scene s, float x, float y) {
        for (int i = 0; i < 6; i++) {
            if (Math.hypot(x - s.pockets[i][0], y - s.pockets[i][1]) < 0.5f) return i;
        }
        return -1;
    }

    private static void attachCueLeavePaths(PoolVision.Scene s, List<Plan> plans) {
        int count = Math.min(16, plans.size());
        for (int i = 0; i < count; i++) {
            Plan plan = plans.get(i);
            if (plan.type != DIRECT && plan.type != BANK && plan.type != KICK) continue;
            float aimX = plan.hasK ? plan.kx : plan.gx;
            float aimY = plan.hasK ? plan.ky : plan.gy;
            float angle = (float) Math.atan2(aimY - plan.cy, aimX - plan.cx);
            PoolAim.Live live = PoolAim.trace(s, (float) Math.cos(angle), (float) Math.sin(angle));
            if (!live.hit || live.target != plan.target) continue;
            plan.afterScratch = live.scratch;
            plan.cueAfter = new float[live.after.n * 2];
            System.arraycopy(live.after.v, 0, plan.cueAfter, 0, plan.cueAfter.length);
        }
    }

    /** after the hit the cue ball runs along the tangent: if that line ends in a pocket it is a scratch risk */
    private static void scratch(PoolVision.Scene s, Plan p, float ux, float uy, float cux, float cuy, float R) {
        float dot = cux * ux + cuy * uy;
        float tx = cux - ux * dot, ty = cuy - uy * dot, tl = (float) Math.hypot(tx, ty);
        if (tl < 0.12f) return;                               // straight on: stop-ball, cue ball stays
        tx /= tl; ty /= tl;
        float len = 2.5f * Math.max(s.Rt - s.L, s.B - s.T);
        for (int i = 0; i < 6; i++) {
            float dx = s.pockets[i][0] - p.gx, dy = s.pockets[i][1] - p.gy;
            float proj = dx * tx + dy * ty;
            if (proj > 3 * R && proj < len && Math.abs(dx * ty - dy * tx) < 1.3f * R) {
                p.scratchRisk = true; p.score *= 0.5f; p.note = "انتبه: الأبيض ممكن يدخل بعد الضربة"; return;
            }
        }
    }
}
