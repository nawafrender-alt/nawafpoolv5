package com.pooloverlay.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_PROJECTION = 100, REQ_OVERLAY = 101, REQ_NOTIF = 102;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = dp(24);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(pad, pad * 2, pad, pad);
        root.setBackgroundColor(Color.parseColor("#161512"));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = new TextView(this);
        title.setText("🎱 مساعد البلياردو");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("يقرأ الطاولة كاملة من الشاشة (كل الكرات، الصغار والكبار والثمانية، والفتحات) ويرسم لك سهم أبيض من الكرة البيضاء بالضبط.\n\n"
                + "• يفحص الضربات المباشرة والبنك الواحد ومسارات الكرة البيضاء بعد التصادم؛ لا يدعم البنك المزدوج.\n"
                + "• يعرض تقييماً هندسياً غير معاير (ليس احتمال نجاح) وقوة أولية تقريبية.\n"
                + "• يمكنك معايرة الجيوب يدوياً وتشغيل تشخيص مراكز الكرات وأنصاف أقطارها.\n"
                + "• أول ضربة: يتعرف على المثلث ويقترح الكسر.\n"
                + "• زر «الكل / الصغار / الكبار / الثمانية» تحدد مجموعتك.\n"
                + "• محاكاة التصادم والاحتكاك تقريبية؛ يعرض توصيات محلية فقط ولا ينفّذ الضربة أو يغيّر اللعبة.\n"
                + "• معالجة صور الشاشة محلية على الجهاز؛ لا تُرفع الصور إلى خادم.");
        info.setTextColor(Color.parseColor("#C9C7C2"));
        info.setTextSize(15);
        info.setPadding(0, pad, 0, pad);
        root.addView(info);

        final SharedPreferences prefs = getSharedPreferences("pool", MODE_PRIVATE);
        CheckBox practice = new CheckBox(this);
        practice.setText("وضع التدريب: ألعب ضد البوت المدرب أو أتدرب لوحدي — يطلع الاقتراحات والسهم. لا تستخدمه ضد لاعبين حقيقيين.");
        practice.setTextColor(Color.parseColor("#C9C7C2"));
        practice.setChecked(prefs.getBoolean("practice", false));
        practice.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton v, boolean on) {
                prefs.edit().putBoolean("practice", on).apply();
            }
        });
        root.addView(practice);

        Button start = new Button(this);
        start.setText("تشغيل المساعد");
        start.setTextSize(18);
        start.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { begin(); }
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("إيقاف");
        stop.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                stopService(new Intent(MainActivity.this, PoolCaptureService.class));
            }
        });
        root.addView(stop);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void begin() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات» ثم ارجع", Toast.LENGTH_LONG).show();
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())), REQ_OVERLAY);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent captureIntent = Build.VERSION.SDK_INT >= 34
                ? m.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
                : m.createScreenCaptureIntent();
        startActivityForResult(captureIntent, REQ_PROJECTION);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_NOTIF) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
                begin();
            } else {
                Toast.makeText(this, "لم تُمنح صلاحية الإشعارات؛ فعّلها من إعدادات التطبيق ثم أعد التشغيل.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) begin();
            else Toast.makeText(this, "يلزم السماح بالظهور فوق التطبيقات لتشغيل الواجهة.", Toast.LENGTH_LONG).show();
        } else if (req == REQ_PROJECTION) {
            if (res == RESULT_OK && data != null) {
                Intent svc = new Intent(this, PoolCaptureService.class);
                svc.putExtra("code", res);
                svc.putExtra("data", data);
                startForegroundService(svc);
                moveTaskToBack(true);
            } else {
                Toast.makeText(this, "لازم توافق على مشاركة الشاشة", Toast.LENGTH_LONG).show();
            }
        }
    }
}
