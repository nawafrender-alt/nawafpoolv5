package com.pooloverlay.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

import java.nio.ByteBuffer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** The only owner of MediaProjection, ImageReader, the reusable frame Bitmap, and the overlay. */
public class PoolCaptureService extends Service {
    private static final String TAG = "PoolOverlay";
    private static final String CHANNEL = "pool_overlay";

    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler bg, ui;
    private PoolOverlay overlay;
    private final PoolVision vision = new PoolVision();
    private volatile boolean running = false;
    private volatile boolean destroying = false;
    private long last = 0;
    private Image held;
    private boolean scheduled = false;
    private static final long MIN_GAP_MS = 60;
    private int[] capturePixels;
    private Bitmap frameBitmap;
    private int contentW, contentH;
    private DisplayManager displayManager;
    private DisplayManager.DisplayListener displayListener;
    private PocketCalibrationStore calibrationStore;
    private CaptureResourceRegistry resourceRegistry;
    private CaptureResourceRegistry.Lease projectionLease, displayLease, readerLease, bitmapLease;
    private int screenW, screenH, capW, capH, densityDpi, rotation;
    private final Runnable processRunnable = new Runnable() {
        @Override public void run() { processHeld(); }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) return START_NOT_STICKY;
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Pool Overlay", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("مساعد البلياردو شغّال")
                .setContentText("يقرأ الطاولة من الشاشة")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }

        int code = intent.getIntExtra("code", 0);
        Intent data = Build.VERSION.SDK_INT >= 33
                ? intent.getParcelableExtra("data", Intent.class)
                : intent.getParcelableExtra("data");
        if (data == null) { stopSelf(); return START_NOT_STICKY; }
        try {
            start(code, data);
            running = true;
        } catch (Throwable t) {
            Log.e(TAG, "start failed", t);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void start(int code, Intent data) {
        ui = new Handler(Looper.getMainLooper());
        thread = new HandlerThread("pool-vision");
        thread.start();
        bg = new Handler(thread.getLooper());

        SharedPreferences prefs = getSharedPreferences("pool", MODE_PRIVATE);
        boolean practice = prefs.getBoolean("practice", false);
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        calibrationStore = new PocketCalibrationStore(this);
        resourceRegistry = new CaptureResourceRegistry();

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        if (projection == null) throw new IllegalStateException("MediaProjection was not created");
        final MediaProjection ownedProjection = projection;
        projectionLease = resourceRegistry.register(new CaptureResourceRegistry.Releaser() {
            @Override public void release() {
                try {
                    if (projectionCallback != null) ownedProjection.unregisterCallback(projectionCallback);
                } catch (Throwable ignored) { }
                try { ownedProjection.stop(); } catch (Throwable ignored) { }
            }
        });
        projectionCallback = new MediaProjection.Callback() {
            @Override public void onStop() {
                if (ui != null) ui.post(new Runnable() { @Override public void run() { stopSelf(); } });
            }
            @Override public void onCapturedContentResize(int width, int height) {
                if (Build.VERSION.SDK_INT < 34 || width < 1 || height < 1 || destroying) return;
                setCaptureSourceSize(width, height);
                if (bg != null) bg.post(new Runnable() {
                    @Override public void run() {
                        if (!destroying) {
                            try { resizeCaptureTarget(); }
                            catch (Throwable error) {
                                Log.e(TAG, "captured-content resize failed", error);
                                ui.post(new Runnable() { @Override public void run() { stopSelf(); } });
                            }
                        }
                    }
                });
            }
        };
        projection.registerCallback(projectionCallback, ui);

        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        refreshScreenGeometry();
        applyManualCalibration();
        overlay = new PoolOverlay(this, wm, vision, capW, capH, screenW, screenH, practice,
                new Runnable() { @Override public void run() { stopSelf(); } },
                new Runnable() {
                    @Override public void run() {
                        applyManualCalibration();
                    }
                });
        overlay.show();
        installDisplayListener();
        resizeCaptureTarget();
    }

    private void installDisplayListener() {
        if (displayManager == null || displayListener != null) return;
        displayListener = new DisplayManager.DisplayListener() {
            @Override public void onDisplayAdded(int id) { }
            @Override public void onDisplayRemoved(int id) { }
            @Override public void onDisplayChanged(int id) {
                if (id == Display.DEFAULT_DISPLAY) {
                    refreshScreenGeometry();
                    if (bg != null) bg.post(new Runnable() {
                        @Override public void run() {
                            if (!destroying) {
                                try { resizeCaptureTarget(); }
                                catch (Throwable error) {
                                    Log.e(TAG, "capture resize failed", error);
                                    ui.post(new Runnable() { @Override public void run() { stopSelf(); } });
                                }
                            }
                        }
                    });
                }
            }
        };
        displayManager.registerDisplayListener(displayListener, ui);
    }

    /** Reads the actual display size; the capture and overlay share this full-display coordinate space. */
    private void refreshScreenGeometry() {
        Display d = displayManager == null ? null : displayManager.getDisplay(Display.DEFAULT_DISPLAY);
        if (d == null) throw new IllegalStateException("Default display is unavailable");
        DisplayMetrics metrics = new DisplayMetrics();
        d.getRealMetrics(metrics);
        screenW = Math.max(1, metrics.widthPixels);
        screenH = Math.max(1, metrics.heightPixels);
        densityDpi = Math.max(1, metrics.densityDpi);
        rotation = d.getRotation();
        setCaptureSourceSize(screenW, screenH);
        applyManualCalibration();
        if (overlay != null) overlay.setCaptureGeometry(capW, capH, screenW, screenH, rotation);
    }

    private void setCaptureSourceSize(int width, int height) {
        contentW = Math.max(1, width);
        contentH = Math.max(1, height);
        float scale = Math.min(1f, 720f / Math.min(contentW, contentH));
        capW = Math.max(1, Math.round(contentW * scale));
        capH = Math.max(1, Math.round(contentH * scale));
        if (overlay != null) overlay.setCaptureGeometry(capW, capH, screenW, screenH, rotation);
    }

    private void applyManualCalibration() {
        if (calibrationStore == null) return;
        final float[][] points = calibrationStore.load(screenW, screenH);
        Handler worker = bg;
        if (worker == null || reader == null) {
            vision.setManualPockets(points);
        } else {
            worker.post(new Runnable() { @Override public void run() {
                if (!destroying) vision.setManualPockets(points);
            }});
        }
    }

    /**
     * Keeps one VirtualDisplay for the consent session. On rotation, only its size and
     * surface change; Android 14 projection grants must not be reused to create a second display.
     */
    private void resizeCaptureTarget() {
        if (destroying || projection == null || capW < 1 || capH < 1) return;
        if (reader != null && capW == reader.getWidth() && capH == reader.getHeight()) {
            if (overlay != null) overlay.setCaptureGeometry(capW, capH, screenW, screenH, rotation);
            return;
        }
        ImageReader nextReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 3);
        nextReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override public void onImageAvailable(ImageReader source) { handle(source); }
        }, bg);
        Bitmap nextBitmap = null;
        try {
            nextBitmap = Bitmap.createBitmap(capW, capH, Bitmap.Config.ARGB_8888);
            if (display == null) {
                final VirtualDisplay created = projection.createVirtualDisplay("pool-capture", capW, capH, densityDpi,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, nextReader.getSurface(), null, bg);
                if (created == null) throw new IllegalStateException("VirtualDisplay was not created");
                display = created;
                displayLease = resourceRegistry.register(new CaptureResourceRegistry.Releaser() {
                    @Override public void release() { created.release(); }
                });
            } else {
                display.resize(capW, capH, densityDpi);
                display.setSurface(nextReader.getSurface());
            }
        } catch (Throwable error) {
            nextReader.setOnImageAvailableListener(null, null);
            nextReader.close();
            if (nextBitmap != null && !nextBitmap.isRecycled()) nextBitmap.recycle();
            throw error;
        }
        ImageReader oldReader = reader;
        Bitmap oldBitmap = frameBitmap;
        CaptureResourceRegistry.Lease oldReaderLease = readerLease;
        CaptureResourceRegistry.Lease oldBitmapLease = bitmapLease;
        reader = nextReader;
        frameBitmap = nextBitmap;
        capturePixels = new int[capW * capH];
        readerLease = resourceRegistry.register(new CaptureResourceRegistry.Releaser() {
            @Override public void release() {
                nextReader.setOnImageAvailableListener(null, null);
                nextReader.close();
            }
        });
        final Bitmap ownedBitmap = nextBitmap;
        bitmapLease = resourceRegistry.register(new CaptureResourceRegistry.Releaser() {
            @Override public void release() {
                if (!ownedBitmap.isRecycled()) ownedBitmap.recycle();
            }
        });
        if (resourceRegistry != null) {
            resourceRegistry.release(oldReaderLease);
            resourceRegistry.release(oldBitmapLease);
        }
        if (held != null) { held.close(); held = null; }
        vision.resetTemporal();
        if (overlay != null) overlay.setCaptureGeometry(capW, capH, screenW, screenH, rotation);
    }

    private void handle(ImageReader r) {
        if (destroying || r != reader) return;
        try {
            Image img = r.acquireLatestImage();
            if (img == null) return;
            if (held != null) held.close();
            held = img;
            if (!scheduled) {
                long delay = Math.max(0, last + MIN_GAP_MS - SystemClock.uptimeMillis());
                scheduled = true;
                bg.postDelayed(processRunnable, delay);
            }
        } catch (Throwable t) {
            Log.e(TAG, "acquire failed", t);
        }
    }

    private void processHeld() {
        scheduled = false;
        if (destroying) {
            if (held != null) { held.close(); held = null; }
            return;
        }
        Image img = held;
        if (img == null) return;
        held = null;
        try {
            int w = img.getWidth(), h = img.getHeight();
            if (frameBitmap == null || frameBitmap.isRecycled()
                    || frameBitmap.getWidth() != w || frameBitmap.getHeight() != h) {
                Log.w(TAG, "dropping frame with dimensions that do not match the active capture target");
                return;
            }
            writeBitmap(img, w, h);
            final PoolVision.Scene scene = vision.analyse(frameBitmap, SystemClock.uptimeMillis());
            final PoolVision.Aim aim = vision.aim();
            ui.post(new Runnable() {
                @Override public void run() { if (overlay != null) { overlay.update(scene); overlay.updateAim(aim); } }
            });
        } catch (Throwable t) {
            Log.e(TAG, "frame failed", t);
        } finally {
            img.close();
            last = SystemClock.uptimeMillis();
        }
    }

    /** Writes into one reusable ARGB bitmap. The Image is always closed by processHeld(). */
    private void writeBitmap(Image img, int w, int h) {
        Image.Plane pl = img.getPlanes()[0];
        ByteBuffer buf = pl.getBuffer();
        int rs = pl.getRowStride(), ps = pl.getPixelStride();
        if (capturePixels == null || capturePixels.length != w * h) capturePixels = new int[w * h];
        int limit = buf.limit();
        for (int y = 0; y < h; y++) {
            int o = y * w;
            for (int x = 0; x < w; x++) {
                int i = y * rs + x * ps;
                if (i + 2 >= limit) {
                    capturePixels[o + x] = Color.BLACK;
                    continue;
                }
                int red = buf.get(i) & 255;
                int green = buf.get(i + 1) & 255;
                int blue = buf.get(i + 2) & 255;
                capturePixels[o + x] = 0xFF000000 | (red << 16) | (green << 8) | blue;
            }
        }
        frameBitmap.setPixels(capturePixels, 0, w, 0, 0, w, h);
    }

    @Override
    public void onDestroy() {
        destroying = true;
        running = false;
        if (displayManager != null && displayListener != null) {
            try { displayManager.unregisterDisplayListener(displayListener); } catch (Throwable ignored) { }
            displayListener = null;
        }
        Handler worker = bg;
        if (worker != null && thread != null && Looper.myLooper() != thread.getLooper()) {
            CountDownLatch finished = new CountDownLatch(1);
            worker.post(new Runnable() {
                @Override public void run() {
                    cleanupCaptureResources();
                    finished.countDown();
                }
            });
            try { finished.await(1200, TimeUnit.MILLISECONDS); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        } else {
            cleanupCaptureResources();
        }
        if (overlay != null) { try { overlay.hide(); } catch (Throwable ignored) { } }
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }

    private void cleanupCaptureResources() {
        Handler worker = bg;
        if (worker != null) worker.removeCallbacksAndMessages(null);
        scheduled = false;
        try { if (reader != null) reader.setOnImageAvailableListener(null, null); } catch (Throwable ignored) { }
        try { if (held != null) held.close(); } catch (Throwable ignored) { }
        held = null;
        CaptureResourceRegistry resources = resourceRegistry;
        resourceRegistry = null;
        if (resources != null) resources.closeAll();
        displayLease = null;
        readerLease = null;
        bitmapLease = null;
        projectionLease = null;
        display = null;
        reader = null;
        frameBitmap = null;
        capturePixels = null;
        projectionCallback = null;
        projection = null;
    }
}
