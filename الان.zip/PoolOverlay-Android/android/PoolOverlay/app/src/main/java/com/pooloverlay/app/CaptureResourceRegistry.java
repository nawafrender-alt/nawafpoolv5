package com.pooloverlay.app;

import java.util.ArrayList;
import java.util.List;

/** Idempotent, reverse-order owner for resources belonging to one projection session. */
final class CaptureResourceRegistry {
    interface Releaser { void release(); }

    static final class Lease {
        private final Releaser releaser;
        private boolean released;

        private Lease(Releaser releaser) { this.releaser = releaser; }
    }

    private final List<Lease> active = new ArrayList<>();
    private boolean closed;

    synchronized Lease register(Releaser releaser) {
        if (releaser == null) throw new IllegalArgumentException("releaser is required");
        Lease lease = new Lease(releaser);
        if (!closed) {
            active.add(lease);
            return lease;
        }
        lease.released = true;
        releaser.release();
        return lease;
    }

    void release(Lease lease) {
        if (lease == null) return;
        Releaser action;
        synchronized (this) {
            if (lease.released) return;
            lease.released = true;
            active.remove(lease);
            action = lease.releaser;
        }
        action.release();
    }

    void closeAll() {
        List<Lease> closing;
        synchronized (this) {
            if (closed) return;
            closed = true;
            closing = new ArrayList<>(active);
            active.clear();
            for (Lease lease : closing) lease.released = true;
        }
        for (int i = closing.size() - 1; i >= 0; i--) {
            try { closing.get(i).releaser.release(); } catch (Throwable ignored) { }
        }
    }

    synchronized int activeCount() { return active.size(); }
    synchronized boolean isClosed() { return closed; }
}
