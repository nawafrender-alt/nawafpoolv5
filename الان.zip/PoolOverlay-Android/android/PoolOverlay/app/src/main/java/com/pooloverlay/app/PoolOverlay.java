package com.pooloverlay.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** The floating panel + the full-screen arrow layer that is drawn exactly over the real table. */
final class PoolOverlay {
    private final Context ctx;
    private final WindowManager wm;
    private final PoolVision vision;
    private final boolean practice;
    private final Runnable onClose;
    private final Runnable onCalibrationChanged;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService plannerExecutor = Executors.newSingleThreadExecutor();
    private volatile int screenW, screenH, frameW, frameH, displayRotation;
    private volatile ScreenTransform transform;

    private ArrowView arrow;
    private LinearLayout panel, body;
    private WindowManager.LayoutParams panelLp, arrowLp;
    private TextView statusTv, detailTv, groupChip, modeChip, altChip, legendTv, ownTv, debugChip;
    private boolean showAlts = false, groupManual = false, ownMine = false, debugEnabled = false;
    private PocketCalibrationOverlay calibrationView;
    private WindowManager.LayoutParams calibrationLp;
    private long lastAimRealMs = 0;
    private PoolVision.Scene ownBefore;
    private int group = 0;
    private boolean full = true, collapsed = false;
    private PoolVision.Scene shown, pending;
    private List<PoolPlanner.Plan> plans = new ArrayList<>();
    private final PoolMemory memory;
    private PoolPlanner.Plan pendingOutcomePlan;
    private PoolVision.Scene pendingOutcomeBefore;
    private int tick = 0;
    private volatile int planGeneration = 0;
    private long badSince = 0, pendingSince = 0;
    private int changeFrames = 0;
    private static final long GRACE_MS = 1500, SETTLE_MS = 180, MAX_WAIT_MS = 1200;
    private static final float WATCH_LIMIT = 45f;
    private TextView liveTv;
    private String liveText = "";
    private PoolAim.Live live;
    private PoolVision.Aim curAim;
    private long aimSeen = 0;
    private float liveAng = 0;
    // display-rate smoothing of MY line: the screen is redrawn every vsync and eases toward the latest detected angle
    private float dispAng = 0, targetAng = 0;
    private boolean haveDisp = false, animating = false;
    private long lastTickNs = 0, lastIgnoreMs = 0;
    private final Runnable animTick = new Runnable() {
        @Override public void run() {
            PoolVision.Scene sc = shown;
            if (panel == null || arrow == null || !practice || sc == null || sc.cue == null || curAim == null) { animating = false; return; }
            long ns = System.nanoTime();
            float dt = Math.min(0.05f, Math.max(0.001f, (ns - lastTickNs) / 1e9f));
            lastTickNs = ns;
            float d = angDiff(targetAng, dispAng);
            boolean done = Math.abs(d) < 0.00004f;                      // ~0.002 degree: arrived exactly on the detected angle
            if (done) dispAng = targetAng;
            else dispAng += d * (1f - (float) Math.exp(-dt / 0.040f));
            PoolAim.Live lv = PoolAim.trace(sc, (float) Math.cos(dispAng), (float) Math.sin(dispAng));
            live = lv;
            arrow.setLive(lv, transform, sc.R);
            long nowMs = SystemClock.uptimeMillis();
            if (done || nowMs - lastIgnoreMs > 90) { pushIgnore(); lastIgnoreMs = nowMs; }
            if (done) { animating = false; return; }
            arrow.postOnAnimation(this);
        }
    };

    private void startAim() {
        if (animating || arrow == null) return;
        animating = true;
        lastTickNs = System.nanoTime();
        arrow.postOnAnimation(animTick);
    }
    private boolean forceLive = false;
    private static final String[] GROUPS = {"🎱 الكل", "🟡 الصغار 1-7", "⚪ الكبار 9-15", "⚫ الثمانية"};

    PoolOverlay(Context ctx, WindowManager wm, PoolVision vision, int frameW, int frameH,
                int screenW, int screenH, boolean practice, Runnable onClose,
                Runnable onCalibrationChanged) {
        this.ctx = ctx; this.wm = wm; this.vision = vision;
        this.frameW = Math.max(1, frameW); this.frameH = Math.max(1, frameH);
        this.screenW = Math.max(1, screenW); this.screenH = Math.max(1, screenH);
        this.transform = new ScreenTransform(this.frameW, this.frameH, this.screenW, this.screenH);
        this.practice = practice; this.onClose = onClose;
        this.onCalibrationChanged = onCalibrationChanged;
        this.memory = new PoolMemory(ctx);
    }

    void setCaptureGeometry(int frameW, int frameH, int screenW, int screenH, int rotation) {
        int previousRotation = displayRotation;
        this.frameW = Math.max(1, frameW);
        this.frameH = Math.max(1, frameH);
        this.screenW = Math.max(1, screenW);
        this.screenH = Math.max(1, screenH);
        this.displayRotation = rotation;
        this.transform = new ScreenTransform(this.frameW, this.frameH, this.screenW, this.screenH);
        if (calibrationView != null && previousRotation != rotation) {
            ui.post(new Runnable() { @Override public void run() { cancelCalibration(); } });
        }
        if (arrow != null) {
            final ScreenTransform next = transform;
            ui.post(new Runnable() {
                @Override public void run() {
                    if (arrow != null) {
                        arrow.setTransform(next);
                        arrow.postInvalidate();
                        pushIgnore();
                    }
                }
            });
        }
    }

    private int dp(float v) { return (int) (v * ctx.getResources().getDisplayMetrics().density + 0.5f); }

    // ------------------------------------------------------------------ views
    void show() {
        arrow = new ArrowView(ctx);
        arrow.setTransform(transform);
        arrowLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        arrowLp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) arrowLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        wm.addView(arrow, arrowLp);

        panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(8), dp(10), dp(10));
        panel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#E6161512"));
        bg.setCornerRadius(dp(14));
        panel.setBackground(bg);

        LinearLayout head = new LinearLayout(ctx);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        statusTv = text("🎱 جاري القراءة…", 14, Color.WHITE, true);
        head.addView(statusTv, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView hide = text("▁", 18, Color.parseColor("#C9C7C2"), true);
        hide.setPadding(dp(10), 0, dp(6), 0);
        hide.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                collapsed = !collapsed;
                body.setVisibility(collapsed ? View.GONE : View.VISIBLE);
                pushIgnore();
            }
        });
        head.addView(hide);
        TextView close = text("✕", 18, Color.parseColor("#FF8A80"), true);
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (onClose != null) onClose.run(); }
        });
        head.addView(close);
        panel.addView(head);
        attachDrag(head);

        body = new LinearLayout(ctx);
        body.setOrientation(LinearLayout.VERTICAL);
        panel.addView(body);
        detailTv = text("", 13, Color.parseColor("#C9C7C2"), false);
        detailTv.setPadding(0, dp(4), 0, dp(6));
        body.addView(detailTv);
        legendTv = text("🟡 مسار الأبيض   🟢 إدخال مباشر   🟣 بنك   🔵 بعد التصادم", 12, Color.parseColor("#E8E6E1"), false);
        legendTv.setPadding(0, 0, 0, dp(4));
        body.addView(legendTv);
        ownTv = text("", 12, Color.parseColor("#E8E6E1"), true);
        ownTv.setPadding(0, 0, 0, dp(6));
        body.addView(ownTv);
        liveTv = text("", 13, Color.parseColor("#00E5FF"), true);
        liveTv.setPadding(0, 0, 0, dp(6));
        liveTv.setVisibility(View.GONE);
        body.addView(liveTv);

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        groupChip = chip(GROUPS[0], new View.OnClickListener() {
            @Override public void onClick(View v) {
                group = (group + 1) % GROUPS.length;
                groupManual = group != 0;
                updateGroupChip();
                if (shown != null) updateOwnText(shown);
                replan();
            }
        });
        modeChip = chip("🧠 مباشر + بنك + جدار", new View.OnClickListener() {
            @Override public void onClick(View v) {
                full = !full;
                modeChip.setText(full ? "🧠 مباشر + بنك + جدار" : "➡ مباشر فقط");
                replan();
            }
        });
        row.addView(groupChip);
        row.addView(modeChip);
        body.addView(row);
        LinearLayout row2 = new LinearLayout(ctx);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setPadding(0, dp(4), 0, 0);
        altChip = chip("👁 البدائل: مخفية", new View.OnClickListener() {
            @Override public void onClick(View v) {
                showAlts = !showAlts;
                altChip.setText(showAlts ? "👁 البدائل: ظاهرة" : "👁 البدائل: مخفية");
                if (shown != null && !plans.isEmpty()) showPlans(shown);
            }
        });
        row2.addView(altChip);
        body.addView(row2);

        LinearLayout row3 = new LinearLayout(ctx);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        row3.setPadding(0, dp(4), 0, 0);
        TextView calibrateChip = chip("معايرة الجيوب", new View.OnClickListener() {
            @Override public void onClick(View v) { startCalibration(); }
        });
        debugChip = chip("تشخيص: متوقف", new View.OnClickListener() {
            @Override public void onClick(View v) {
                debugEnabled = !debugEnabled;
                debugChip.setText(debugEnabled ? "تشخيص: يعمل" : "تشخيص: متوقف");
                if (arrow != null) {
                    arrow.setDebug(debugEnabled ? shown : null);
                    arrow.postInvalidate();
                }
            }
        });
        row3.addView(calibrateChip);
        row3.addView(debugChip);
        body.addView(row3);

        panelLp = new WindowManager.LayoutParams(
                dp(262), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = dp(8);
        panelLp.y = dp(24);
        wm.addView(panel, panelLp);
        ui.postDelayed(new Runnable() { @Override public void run() { pushIgnore(); } }, 300);
    }

    void hide() {
        ui.removeCallbacksAndMessages(null);
        planGeneration++;
        plannerExecutor.shutdownNow();
        cancelCalibration();
        vision.setIgnore(null, null);
        vision.clearWatch();
        try { if (panel != null) wm.removeView(panel); } catch (Throwable ignored) { }
        try { if (arrow != null) wm.removeView(arrow); } catch (Throwable ignored) { }
        panel = null; arrow = null;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView chip(String s, View.OnClickListener l) {
        TextView t = text(s, 12, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor("#3A3935"));
        d.setCornerRadius(dp(10));
        t.setBackground(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    private void attachDrag(View handle) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            private float dx, dy; private int sx, sy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = panelLp.x; sy = panelLp.y; dx = e.getRawX(); dy = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = sx + (int) (e.getRawX() - dx);
                        panelLp.y = sy + (int) (e.getRawY() - dy);
                        try { wm.updateViewLayout(panel, panelLp); } catch (Throwable ignored) { }
                        pushIgnore();
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    // ------------------------------------------------------------------ logic
    /** called on the UI thread for every analysed frame */
    void update(PoolVision.Scene s) {
        if (panel == null || calibrationView != null) return;
        long now = SystemClock.uptimeMillis();
        if (s.secure || !s.ok) {
            // a bad frame (black flash, menu, hand over the table) must not wipe the arrows
            if (badSince == 0) badSince = now;
            if (shown != null && now - badSince < GRACE_MS) return;
            drop();
            if (s.secure) setStatus("🔒 الشاشة محمية من التصوير", "اللعبة تمنع التقاط الشاشة (تظهر سوداء) — ما أقدر أقرأ الطاولة.", "#FF8A80");
            else setStatus("🎱 " + s.msg, "أظهر سطح اللعب كاملاً؛ إذا كانت حدود الجيوب فقط غير دقيقة فاستخدم «معايرة الجيوب».", "#C9C7C2");
            return;
        }
        badSince = 0;
        if (shown != null) {
            // the plan stays on screen until a REAL shot happens. Reading noise (cue stick, game aim line, our own arrows) is ignored.
            int ev = evidence(shown, s);
            if (ev == 0) { changeFrames = 0; return; }
            if (++changeFrames < (ev == 2 ? 2 : 5)) return;
            changeFrames = 0;
            ownBefore = shown;
            ownMine = now - lastAimRealMs < 2500;                      // my aim line was on screen just before the shot = my shot
            pendingOutcomePlan = practice && !plans.isEmpty() ? plans.get(0) : null;
            pendingOutcomeBefore = pendingOutcomePlan == null ? null : shown;
            planGeneration++;
            plans = new ArrayList<>();
            shown = null;
            pending = null;
            vision.clearWatch();
            arrow.clear();
            curAim = null; live = null;
            setLiveText("");
            vision.setIgnore(null, panelRect());
        }
        beginSettle(s, now);
    }

    private void beginSettle(PoolVision.Scene s, long now) {
        if (pending != null && sameScene(pending, s)) return;        // already waiting for these balls to settle
        if (pending == null) pendingSince = now;
        pending = s;
        if (now - pendingSince > MAX_WAIT_MS) { tick++; settle(); return; }   // never wait forever
        setStatus("⏳ الكرات تتحرك…", "", "#C9C7C2");
        final int my = ++tick;
        ui.postDelayed(new Runnable() { @Override public void run() { if (my == tick) settle(); } }, SETTLE_MS);
    }

    /** 0 = nothing happened, 1 = weak sign, 2 = a shot / new rack for sure */
    private int evidence(PoolVision.Scene a, PoolVision.Scene b) {
        if (a.cue != null) {
            if (vision.watchDiff() > WATCH_LIMIT) return 2;          // the cue ball left its spot
        } else if (b.cue != null) {
            return 2;
        }
        if (a.rack != b.rack) return 2;
        if (a.cue != null && b.cue != null && Math.hypot(a.cue.x - b.cue.x, a.cue.y - b.cue.y) > 0.9f * a.R) return 2;   // cue ball moved: the old arrows are stale
        float tol = Math.max(6f, 1.1f * a.R);
        if (unmatched(a.balls, b.balls, tol) >= 6 || unmatched(b.balls, a.balls, tol) >= 6) return 1;
        return 0;
    }

    private static boolean ballNear(List<PoolVision.Ball> list, float x, float y, float tol) {
        for (PoolVision.Ball q : list) if (Math.abs(q.x - x) < tol && Math.abs(q.y - y) < tol && Math.hypot(q.x - x, q.y - y) < tol) return true;
        return false;
    }

    private static int unmatched(List<PoolVision.Ball> from, List<PoolVision.Ball> in, float tol) {
        int n = 0;
        for (PoolVision.Ball p : from) if (!ballNear(in, p.x, p.y, tol)) n++;
        return n;
    }

    // ------------------------------------------------------------------ live aim (follows the game's own aim line)
    /** called on the UI thread for every analysed frame, after update() */
    void updateAim(PoolVision.Aim a) {
        if (panel == null || arrow == null || !practice || calibrationView != null) return;
        long now = SystemClock.uptimeMillis();
        if (a != null) { curAim = a; aimSeen = now; lastAimRealMs = now; }
        else if (now - aimSeen > 700) curAim = null;                 // keep it a moment if one frame misses the line
        refreshLive();
    }

    private static float angDiff(float a, float b) {
        float d = a - b;
        while (d > Math.PI) d -= 2 * Math.PI;
        while (d <= -Math.PI) d += 2 * Math.PI;
        return d;
    }

    private void refreshLive() {
        PoolVision.Scene s = shown;
        if (!practice || arrow == null || curAim == null || s == null || s.cue == null) {
            haveDisp = false;
            if (live != null) { live = null; if (arrow != null) arrow.setLive(null, transform, 1f); pushIgnore(); }
            setLiveText("");
            return;
        }
        float ang = (float) Math.atan2(curAim.uy, curAim.ux);
        if (live != null && !forceLive && Math.abs(angDiff(ang, liveAng)) < 0.0009f) return;   // < 0.05 degree: nothing new
        forceLive = false;
        liveAng = ang;
        PoolAim.Live lv = PoolAim.trace(s, curAim.ux, curAim.uy);      // exact result at the detected angle (for the text)
        targetAng = ang;
        if (!haveDisp || live == null) { dispAng = ang; haveDisp = true; live = lv; arrow.setLive(lv, transform, s.R); }
        startAim();
        StringBuilder sb = new StringBuilder();
        if (lv.hit) sb.append(lv.pocketed ? "🎯 ضربتك تدخل ✅" : "🎯 ضربتك تلمس كرة بس ما تدخل");
        else sb.append("↔ ضربتك ما تلمس أي كرة");
        if (lv.scratch) sb.append("\n⚠ الأبيض ممكن يدخل");
        if (!plans.isEmpty()) {
            PoolPlanner.Plan b = plans.get(0);
            float tx = b.hasK ? b.kx : b.gx, ty = b.hasK ? b.ky : b.gy;
            float rec = (float) Math.atan2(ty - s.cue.y, tx - s.cue.x);
            float d = (float) Math.toDegrees(angDiff(rec, ang));
            if (Math.abs(d) < 0.8f) sb.append("\n✅ مطابق للاقتراح");
            else sb.append("\n↻ دوّر ").append(d > 0 ? "يمين " : "يسار ").append(String.format(java.util.Locale.US, "%.1f", Math.abs(d))).append("°");
        }
        setLiveText(sb.toString());
        if (!animating) pushIgnore();
    }

    private void setLiveText(String t) {
        if (liveTv == null || t.equals(liveText)) return;
        liveText = t;
        liveTv.setText(t);
        liveTv.setVisibility(t.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void drop() {
        shown = null; pending = null; tick++; changeFrames = 0;
        planGeneration++;
        plans = new ArrayList<>();
        pendingOutcomePlan = null; pendingOutcomeBefore = null; ownBefore = null;
        curAim = null; live = null; haveDisp = false;
        vision.clearWatch();
        if (arrow != null) arrow.clear();
        if (arrow != null) arrow.setDebug(null);
        setLiveText("");
        vision.setIgnore(null, panelRect());
    }

    private void settle() {
        PoolVision.Scene s = pending;
        pending = null;
        if (s == null || panel == null) return;
        if (pendingOutcomePlan != null && pendingOutcomeBefore != null) {
            memory.record(pendingOutcomePlan, pendingOutcomeBefore, s);
            pendingOutcomePlan = null;
            pendingOutcomeBefore = null;
        }
        inferOwnership(s);
        shown = s;
        if (arrow != null) arrow.setDebug(debugEnabled ? s : null);
        updateOwnText(s);
        if (s.cue != null) vision.setWatch(s.cue.x, s.cue.y, s.R); else vision.clearWatch();
        if (!practice) {
            setStatus("🎱 " + s.balls.size() + " كرة", "فعّل «وضع التدريب» من التطبيق عشان تطلع لك الاقتراحات (ضد البوت المدرب فقط).", "#C9C7C2");
            return;
        }
        replan();
    }

    private void replan() {
        if (panel == null || shown == null || !practice) return;
        final PoolVision.Scene s = shown;
        if (s.confidence < 0.48f) {
            plans = new ArrayList<>();
            arrow.clear();
            setStatus("⚠ ثقة الكشف منخفضة", "لن أرسم مساراً حتى تصبح حدود الطاولة والكرات أوضح.", "#FFB300");
            return;
        }
        if (s.cue == null) {
            planGeneration++;
            plans = new ArrayList<>();
            arrow.clear();
            setStatus("⚪ ما لقيت الكرة البيضاء", "يمكن يد حرة: حطّها أول بمكانها ثم أحلل.", "#FFB300");
            vision.setIgnore(null, panelRect());
            return;
        }
        final int selectedGroup = group;
        final boolean includeBanks = full;
        final int generation = ++planGeneration;
        plans = new ArrayList<>();
        arrow.clear();
        setStatus("🧠 جاري حساب المسار…", "يستمر العرض أثناء الحساب.", "#C9C7C2");
        vision.setIgnore(null, panelRect());
        plannerExecutor.execute(new Runnable() {
            @Override public void run() {
                if (generation != planGeneration) return;
                final List<PoolPlanner.Plan> result;
                try {
                    result = PoolPlanner.plan(s, selectedGroup, includeBanks, memory);
                } catch (RuntimeException error) {
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (generation == planGeneration && panel != null && shown == s) {
                                plans = new ArrayList<>();
                                arrow.clear();
                                setStatus("⚠ تعذر حساب المسار", "أعد المحاولة بعد ثبات الكرات.", "#FF8A80");
                                vision.setIgnore(null, panelRect());
                            }
                        }
                    });
                    return;
                }
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (generation != planGeneration || panel == null || shown != s || !practice) return;
                        plans = result;
                        showPlans(s);
                    }
                });
            }
        });
    }

    private void showPlans(PoolVision.Scene s) {
        if (plans.isEmpty()) {
            arrow.clear();
            setStatus("⚠ لا توجد ضربة موثوقة", "لم يجتز أي مسار فحص العوائق والحواف. لا أُظهر خطاً تخمينياً.", "#FFB300");
            vision.setIgnore(null, panelRect());
            return;
        }
        PoolPlanner.Plan b = plans.get(0);
        String title;
        switch (b.type) {
            case PoolPlanner.BANK: title = "🔁 بنك"; break;
            case PoolPlanner.KICK: title = "↗ ضرب من الجدار"; break;
            case PoolPlanner.TOUCH: title = "🛡 دفاع"; break;
            case PoolPlanner.BREAK: title = "💥 كسر"; break;
            default: title = "🎯 مباشر";
        }
        StringBuilder sb = new StringBuilder();
        if (b.type != PoolPlanner.BREAK && b.type != PoolPlanner.TOUCH) {
            sb.append("تقييم هندسي ").append(Math.round(b.score * 100)).append("/100 (ليس احتمال نجاح)  •  ");
        }
        sb.append("قوة ابتدائية تقريبية ").append(b.power).append("%");
        if (b.type == PoolPlanner.DIRECT || b.type == PoolPlanner.BANK || b.type == PoolPlanner.KICK) sb.append("  •  زاوية ").append(Math.round(b.cut)).append("°");
        if (b.afterScratch) sb.append("\n⚠ المسار المتوقع للأبيض قد ينتهي بخدش");
        if (!b.note.isEmpty()) sb.append("\n").append(b.note);
        if (plans.size() > 1) sb.append(showAlts ? "\nالوردي الخفيف = بدائل أقل تقييماً" : "\nتوجد بدائل أقل تقييماً — اضغط «البدائل»");
        setStatus(title, sb.toString(), b.type == PoolPlanner.TOUCH ? "#FFB300" : "#7CFC9A");
        arrow.set(visiblePlans(), transform, s.R);
        arrow.setDebug(debugEnabled ? s : null);
        pushIgnore();
        forceLive = true;
        refreshLive();
    }

    private static float planAngle(PoolPlanner.Plan p) {
        float tx = p.hasK ? p.kx : p.gx, ty = p.hasK ? p.ky : p.gy;
        return (float) Math.atan2(ty - p.cy, tx - p.cx);
    }

    /** the coach draws ONE solid shot; alternatives only on request and never on top of the main one */
    private List<PoolPlanner.Plan> visiblePlans() {
        List<PoolPlanner.Plan> out = new ArrayList<>();
        if (plans.isEmpty()) return out;
        PoolPlanner.Plan best = plans.get(0);
        out.add(best);
        if (!showAlts) return out;
        for (int i = 1; i < plans.size(); i++) {
            PoolPlanner.Plan p = plans.get(i);
            boolean clash = false;
            for (PoolPlanner.Plan q : out) {
                if (Math.abs(angDiff(planAngle(p), planAngle(q))) < 0.09f || (p.px == q.px && p.py == q.py && p.target == q.target)) clash = true;
            }
            if (!clash) out.add(p);
        }
        return out;
    }

    // ------------------------------------------------------------------ my balls / the opponent's balls
    private static int countKind(PoolVision.Scene s, int kind) {
        int n = 0;
        for (PoolVision.Ball b : s.balls) if (b.kind == kind) n++;
        return n;
    }

    private void updateGroupChip() {
        if (groupChip == null) return;
        groupChip.setText(GROUPS[group] + (group != 0 && !groupManual ? " ✓تلقائي" : ""));
    }

    /**
     * Works out which group is mine from what gets potted while the table is open: a ball potted on a shot where my aim line
     * was on screen is mine; a ball potted when it was not my shot belongs to the opponent (so mine is the other group).
     * A manual choice from the chip always wins.
     */
    private void inferOwnership(PoolVision.Scene after) {
        PoolVision.Scene before = ownBefore;
        ownBefore = null;
        if (before == null || groupManual || group != 0 || after == null || !after.ok || !before.ok || before.rack) return;
        int dSolid = countKind(before, PoolVision.SOLID) - countKind(after, PoolVision.SOLID);
        int dStripe = countKind(before, PoolVision.STRIPE) - countKind(after, PoolVision.STRIPE);
        int dAll = before.balls.size() - after.balls.size();
        if (dAll < 1 || dAll > 2) return;
        boolean solid = dSolid > 0 && dStripe <= 0, stripe = dStripe > 0 && dSolid <= 0;
        if (solid == stripe) return;                                  // nothing clear (or both kinds): leave it unknown
        int potted = solid ? 1 : 2;
        group = ownMine ? potted : (potted == 1 ? 2 : 1);
        updateGroupChip();
    }

    private void updateOwnText(PoolVision.Scene s) {
        if (ownTv == null) return;
        if (s == null || !s.ok) { ownTv.setVisibility(View.GONE); return; }
        int solids = countKind(s, PoolVision.SOLID), stripes = countKind(s, PoolVision.STRIPE);
        String t;
        if (group == 1) {
            t = solids == 0 ? "🟢 كراتي: خلصت — الثمانية ⚫" : "🟢 كراتي: الصغار 1-7 (" + solids + ")  •  🔴 الخصم: الكبار (" + stripes + ")";
        } else if (group == 2) {
            t = stripes == 0 ? "🟢 كراتي: خلصت — الثمانية ⚫" : "🟢 كراتي: الكبار 9-15 (" + stripes + ")  •  🔴 الخصم: الصغار (" + solids + ")";
        } else if (group == 3) {
            t = "🟢 كراتي: الثمانية ⚫";
        } else {
            t = "❔ الطاولة مفتوحة — أول كرة تدخل تحدد كراتي (أو اخترها من الزر)";
        }
        ownTv.setText(t);
        ownTv.setVisibility(View.VISIBLE);
    }

    private void setStatus(String st, String detail, String color) {
        statusTv.setText(st);
        statusTv.setTextColor(Color.parseColor(color));
        detailTv.setText(detail);
        detailTv.setVisibility(detail.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void startCalibration() {
        if (calibrationView != null || panel == null || screenW < 1 || screenH < 1) return;
        calibrationView = new PocketCalibrationOverlay(ctx, screenW, screenH,
                new PocketCalibrationOverlay.Listener() {
                    @Override public void onComplete(float[][] points) {
                        boolean saved = new PocketCalibrationStore(ctx).save(points, screenW, screenH);
                        cancelCalibration();
                        if (!saved) {
                            setStatus("⚠ تعذرت المعايرة", "أعد المحاولة وتأكد من تسجيل ستة جيوب.", "#FF8A80");
                            return;
                        }
                        if (onCalibrationChanged != null) onCalibrationChanged.run();
                        drop();
                        setStatus("✓ حُفظت معايرة الجيوب", "النقاط محلية على هذا الجهاز؛ ستُستخدم مع نسبة الشاشة نفسها.", "#7CFC9A");
                    }

                    @Override public void onCancel() {
                        cancelCalibration();
                        setStatus("أُلغيت المعايرة", "لم تتغير النقاط المحفوظة سابقاً.", "#C9C7C2");
                    }
                });
        calibrationLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        calibrationLp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            calibrationLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        }
        try {
            wm.addView(calibrationView, calibrationLp);
            setStatus("معايرة الجيوب", "انقر مراكز الجيوب بالترتيب الظاهر؛ لا تحفظ صوراً أو بيانات شاشة.", "#00E5FF");
        } catch (Throwable error) {
            calibrationView = null;
            calibrationLp = null;
            setStatus("⚠ تعذر بدء المعايرة", "تحقق من صلاحية الظهور فوق التطبيقات.", "#FF8A80");
        }
    }

    private void cancelCalibration() {
        PocketCalibrationOverlay current = calibrationView;
        calibrationView = null;
        calibrationLp = null;
        if (current != null) {
            try { wm.removeView(current); } catch (Throwable ignored) { }
        }
    }

    private static boolean sameScene(PoolVision.Scene a, PoolVision.Scene b) {
        float tol = Math.max(3.5f, 0.3f * a.R);
        if (a.balls.size() != b.balls.size() || (a.cue == null) != (b.cue == null)) return false;
        boolean[] used = new boolean[b.balls.size()];
        for (PoolVision.Ball p : a.balls) {
            int hit = -1;
            for (int i = 0; i < b.balls.size(); i++) {
                PoolVision.Ball q = b.balls.get(i);
                if (!used[i] && Math.abs(p.x - q.x) < tol && Math.abs(p.y - q.y) < tol) { hit = i; break; }
            }
            if (hit < 0) return false;
            used[hit] = true;
        }
        return true;
    }

    // our own drawings must not be mistaken for balls: tell the vision where they are
    private float[] panelRect() {
        if (panel == null) return null;
        int[] loc = new int[2];
        panel.getLocationOnScreen(loc);
        ScreenTransform map = transform;
        if (map == null) return null;
        return new float[]{map.viewToFrameX(loc[0]) - 4, map.viewToFrameY(loc[1]) - 4,
                map.viewToFrameX(loc[0] + panel.getWidth()) + 4,
                map.viewToFrameY(loc[1] + panel.getHeight()) + 4};
    }

    private void pushIgnore() {
        if (panel == null) return;
        vision.setIgnore(arrow == null ? null : arrow.segments(), panelRect());
    }

    // ------------------------------------------------------------------ the arrow layer
    private static boolean isShot(PoolPlanner.Plan p) {
        return p.type == PoolPlanner.DIRECT || p.type == PoolPlanner.BANK || p.type == PoolPlanner.KICK;
    }

    /** point d away from (x0,y0) towards (x1,y1): our lines start at the ball's edge so they never cover the ball itself */
    private static float[] off(float x0, float y0, float x1, float y1, float d) {
        float dx = x1 - x0, dy = y1 - y0, l = (float) Math.hypot(dx, dy);
        if (l < 1e-3f || l <= d) return new float[]{x0, y0};
        return new float[]{x0 + dx / l * d, y0 + dy / l * d};
    }

    private static float[] ptsArr(PoolAim.Pts p) {
        float[] r = new float[p.n * 2];
        System.arraycopy(p.v, 0, r, 0, r.length);
        return r;
    }

    private final class ArrowView extends View {
        private List<PoolPlanner.Plan> ps = new ArrayList<>();
        private PoolAim.Live lv;
        private ScreenTransform map;
        private PoolVision.Scene debugScene;
        private float R = 10f;
        private long planStart = 0;
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG);

        ArrowView(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setStrokeJoin(Paint.Join.ROUND);
            line.setDither(true);
            line.setStrokeMiter(2f);
            fill.setStyle(Paint.Style.FILL);
            fill.setDither(true);
        }

        void setTransform(ScreenTransform transform) {
            map = transform;
            postInvalidate();
        }

        void set(List<PoolPlanner.Plan> list, ScreenTransform transform, float radius) {
            boolean fresh = ps.isEmpty() && !list.isEmpty();
            ps = new ArrayList<>(list);
            map = transform;
            R = radius;
            if (fresh) planStart = SystemClock.uptimeMillis();
            invalidate();
        }

        void setLive(PoolAim.Live l, ScreenTransform transform, float radius) {
            lv = l;
            map = transform;
            if (l != null) R = radius;
            invalidate();
        }

        void setDebug(PoolVision.Scene scene) {
            debugScene = scene;
            if (scene != null) R = scene.R;
            invalidate();
        }

        void clear() { ps = new ArrayList<>(); lv = null; invalidate(); }

        // ---- geometry in capture pixels
        private float[] cuePts(PoolPlanner.Plan p) {
            float tx = p.hasK ? p.kx : p.gx, ty = p.hasK ? p.ky : p.gy;
            float[] a = off(p.cx, p.cy, tx, ty, 1.08f * R);
            float ex = p.gx, ey = p.gy;
            if (p.type == PoolPlanner.TOUCH) {
                float[] e = off(p.gx, p.gy, p.hasK ? p.kx : p.cx, p.hasK ? p.ky : p.cy, R);
                ex = e[0]; ey = e[1];
            }
            return p.hasK ? new float[]{a[0], a[1], p.kx, p.ky, ex, ey} : new float[]{a[0], a[1], ex, ey};
        }

        private float[] objPts(PoolPlanner.Plan p) {
            float tx = p.hasB ? p.bx : p.px, ty = p.hasB ? p.by : p.py;
            float[] a = off(p.ox, p.oy, tx, ty, 1.08f * R);
            return p.hasB ? new float[]{a[0], a[1], p.bx, p.by, p.px, p.py} : new float[]{a[0], a[1], p.px, p.py};
        }

        private float[] liveCue(PoolAim.Live l) {
            float[] a = ptsArr(l.cue);
            if (a.length >= 4) { float[] s = off(a[0], a[1], a[2], a[3], 1.08f * R); a[0] = s[0]; a[1] = s[1]; }
            return a;
        }

        private float[] liveObj(PoolAim.Live l) {
            float[] a = ptsArr(l.obj);
            if (a.length >= 4) { float[] s = off(a[0], a[1], a[2], a[3], 1.08f * R); a[0] = s[0]; a[1] = s[1]; }
            return a;
        }

        /** every line we draw, in capture pixels (x1,y1,x2,y2,...) so the reader can ignore them */
        float[] segments() {
            List<Float> o = new ArrayList<>();
            for (PoolPlanner.Plan p : ps) {
                polySegs(o, cuePts(p));
                if (p.type != PoolPlanner.TOUCH) ring(o, p.gx, p.gy);
                if (isShot(p)) polySegs(o, objPts(p));
                polySegs(o, p.cueAfter);
            }
            if (lv != null) {
                polySegs(o, liveCue(lv));
                if (lv.hit) { ring(o, lv.gx, lv.gy); polySegs(o, liveObj(lv)); polySegs(o, ptsArr(lv.after)); }
            }
            if (debugScene != null) debugSegments(o, debugScene);
            float[] r = new float[o.size()];
            for (int i = 0; i < r.length; i++) r[i] = o.get(i);
            return r;
        }

        private void polySegs(List<Float> o, float[] pts) {
            for (int i = 0; i + 3 < pts.length; i += 2) add(o, pts[i], pts[i + 1], pts[i + 2], pts[i + 3]);
        }

        private void ring(List<Float> o, float x, float y) {
            for (int i = 0; i < 12; i++) {
                double a0 = i * Math.PI / 6, a1 = (i + 1) * Math.PI / 6;
                add(o, x + (float) Math.cos(a0) * R, y + (float) Math.sin(a0) * R, x + (float) Math.cos(a1) * R, y + (float) Math.sin(a1) * R);
            }
        }

        private void add(List<Float> o, float a, float b, float c, float d) { o.add(a); o.add(b); o.add(c); o.add(d); }

        private void debugSegments(List<Float> out, PoolVision.Scene scene) {
            add(out, scene.L, scene.T, scene.Rt, scene.T);
            add(out, scene.Rt, scene.T, scene.Rt, scene.B);
            add(out, scene.Rt, scene.B, scene.L, scene.B);
            add(out, scene.L, scene.B, scene.L, scene.T);
            for (PoolVision.Ball ball : scene.balls) ring(out, ball.x, ball.y);
            for (int i = 0; i < 6; i++) ring(out, scene.pockets[i][0], scene.pockets[i][1]);
        }

        // ---- drawing (screen pixels)
        private Path poly(float[] pts) {
            Path p = new Path();
            ScreenTransform t = map;
            if (t == null) return p;
            for (int i = 0; i + 1 < pts.length; i += 2) {
                float x = t.frameToViewX(pts[i]), y = t.frameToViewY(pts[i + 1]);
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            return p;
        }

        private void strokeOutlined(Canvas c, Path path, int color, float w) {
            line.setPathEffect(null);
            line.setColor(Color.argb(150, 0, 0, 0));
            line.setStrokeWidth(w + dp(2.4f));
            c.drawPath(path, line);
            line.setColor(color);
            line.setStrokeWidth(w);
            c.drawPath(path, line);
        }

        private void route(Canvas c, float[] pts, int color, float w, float arrowSize) {
            if (pts.length < 4) return;
            strokeOutlined(c, poly(pts), color, w);
            int n = pts.length;
            if (map == null) return;
            head(c, map.frameToViewX(pts[n - 4]), map.frameToViewY(pts[n - 3]),
                    map.frameToViewX(pts[n - 2]), map.frameToViewY(pts[n - 1]), arrowSize, color);
        }

        private void head(Canvas c, float x0, float y0, float x1, float y1, float size, int color) {
            float dx = x1 - x0, dy = y1 - y0, dl = (float) Math.hypot(dx, dy);
            if (dl < 1) return;
            dx /= dl; dy /= dl;
            Path h = new Path();
            h.moveTo(x1, y1);
            h.lineTo(x1 - dx * size + dy * size * 0.6f, y1 - dy * size - dx * size * 0.6f);
            h.lineTo(x1 - dx * size - dy * size * 0.6f, y1 - dy * size + dx * size * 0.6f);
            h.close();
            fill.setColor(color);
            c.drawPath(h, fill);
        }

        @Override protected void onDraw(Canvas c) {
            if (ps.isEmpty() && lv == null && debugScene == null) return;
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            c.save();
            c.translate(-loc[0], -loc[1]);
            float fade = Math.min(1f, (SystemClock.uptimeMillis() - planStart) / 160f);
            if (!ps.isEmpty()) {
                int sc = fade < 1f ? c.saveLayerAlpha(0, 0, getWidth() + loc[0], getHeight() + loc[1], (int) (255 * fade)) : -1;
                for (int i = ps.size() - 1; i >= 0; i--) drawPlan(c, ps.get(i), i == 0);
                if (sc >= 0) { c.restoreToCount(sc); postInvalidateOnAnimation(); }
            }
            if (lv != null) drawLive(c, lv);
            if (debugScene != null) drawDebug(c, debugScene);
            c.restore();
        }

        /** Cue route is yellow; direct pot route is green; one-bank pot route is purple. */
        private void drawPlan(Canvas c, PoolPlanner.Plan p, boolean best) {
            if (map == null) return;
            float r = R * map.scale;
            int main = best ? 0xFFFFEB3B : 0xAAFF4081;
            int objc = p.hasB ? (best ? 0xFFB388FF : 0x88B388FF)
                    : (best ? 0xFF00E676 : 0x8800E676);
            float w = dp(best ? 3.4f : 2.2f);
            if (isShot(p)) {
                float[] op = objPts(p);
                route(c, op, objc, dp(best ? 2.8f : 1.9f), dp(best ? 12 : 9));
                fill.setColor(objc);
                c.drawCircle(map.frameToViewX(op[op.length - 2]), map.frameToViewY(op[op.length - 1]), dp(6), fill);
                if (p.hasB) c.drawCircle(map.frameToViewX(p.bx), map.frameToViewY(p.by), dp(4.5f), fill);
                if (p.cueAfter.length >= 4) {
                    route(c, p.cueAfter, p.afterScratch ? 0xFFFF5252 : 0xFF40C4FF, dp(1.8f), dp(8));
                }
            }
            float[] cp = cuePts(p);
            strokeOutlined(c, poly(cp), main, w);
            int n = cp.length;
            float ex = map.frameToViewX(cp[n - 2]), ey = map.frameToViewY(cp[n - 1]);
            float bx = map.frameToViewX(cp[n - 4]), by = map.frameToViewY(cp[n - 3]);
            if (p.type != PoolPlanner.TOUCH) {
                line.setColor(main);
                line.setStrokeWidth(w);
                c.drawCircle(ex, ey, r, line);
                float dl = (float) Math.hypot(ex - bx, ey - by);
                if (dl > 1) { ex -= (ex - bx) / dl * r; ey -= (ey - by) / dl * r; }
            }
            head(c, bx, by, ex, ey, dp(best ? 13 : 9), main);
        }

        /** Live aim: cyan cue route, green pot route, blue predicted cue-ball leave. */
        private void drawLive(Canvas c, PoolAim.Live l) {
            if (map == null) return;
            float r = R * map.scale;
            int col = 0xFF00E5FF;
            float[] cue = liveCue(l);
            route(c, cue, col, dp(2.0f), dp(10));
            if (!l.hit) return;
            float[] op = liveObj(l);
            if (op.length >= 4) {
                int oc = l.pocketed ? 0xFF00E676 : 0xFFFF9800;
                route(c, op, oc, dp(2.0f), dp(9));
                if (l.pocketed) {
                    fill.setColor(oc);
                    c.drawCircle(map.frameToViewX(op[op.length - 2]), map.frameToViewY(op[op.length - 1]), dp(6), fill);
                }
            }
            line.setColor(col);
            line.setStrokeWidth(dp(2.4f));
            c.drawCircle(map.frameToViewX(l.gx), map.frameToViewY(l.gy), r, line);
            float[] af = ptsArr(l.after);
            if (af.length >= 4) route(c, af, l.scratch ? 0xFFFF5252 : 0xFF40C4FF, dp(1.8f), dp(8));
        }

        private void drawDebug(Canvas c, PoolVision.Scene scene) {
            if (map == null) return;
            float rScale = map.scale;
            Path table = new Path();
            table.moveTo(map.frameToViewX(scene.L), map.frameToViewY(scene.T));
            table.lineTo(map.frameToViewX(scene.Rt), map.frameToViewY(scene.T));
            table.lineTo(map.frameToViewX(scene.Rt), map.frameToViewY(scene.B));
            table.lineTo(map.frameToViewX(scene.L), map.frameToViewY(scene.B));
            table.close();
            line.setColor(0xFFFF5252);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(1.6f));
            line.setPathEffect(new android.graphics.DashPathEffect(new float[]{dp(7), dp(5)}, 0));
            c.drawPath(table, line);
            line.setPathEffect(null);
            for (int i = 0; i < 6; i++) {
                float x = map.frameToViewX(scene.pockets[i][0]);
                float y = map.frameToViewY(scene.pockets[i][1]);
                line.setColor(0xFFFFD740);
                line.setStrokeWidth(dp(1.5f));
                c.drawCircle(x, y, Math.max(dp(4), scene.pocketRadii[i] * rScale), line);
                c.drawText("P" + (i + 1), x + dp(5), y - dp(5), debugTextPaint());
            }
            for (PoolVision.Ball ball : scene.balls) {
                float x = map.frameToViewX(ball.x);
                float y = map.frameToViewY(ball.y);
                float radius = Math.max(dp(3), ball.radius * rScale);
                line.setColor(ball == scene.cue ? 0xFF00E5FF : 0xFFFFFFFF);
                line.setStrokeWidth(dp(1.6f));
                c.drawCircle(x, y, radius, line);
                c.drawLine(x - dp(4), y, x + dp(4), y, line);
                c.drawLine(x, y - dp(4), x, y + dp(4), line);
                c.drawText(String.format(java.util.Locale.US, "%.0f%%", ball.confidence * 100f),
                        x + radius, y + dp(4), debugTextPaint());
            }
            line.setStyle(Paint.Style.STROKE);
        }

        private Paint debugTextPaint() {
            fill.setColor(Color.WHITE);
            fill.setTextSize(dp(10));
            fill.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            fill.setShadowLayer(dp(2), 0, 0, Color.BLACK);
            return fill;
        }
    }
}
