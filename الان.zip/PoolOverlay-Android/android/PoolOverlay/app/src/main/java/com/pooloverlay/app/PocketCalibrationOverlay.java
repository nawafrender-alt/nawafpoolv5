package com.pooloverlay.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

/** Temporary, touchable calibration surface. The normal guide layer remains non-touchable. */
final class PocketCalibrationOverlay extends View {
    interface Listener {
        void onComplete(float[][] normalizedPoints);
        void onCancel();
    }

    private static final String[] LABELS = {
            "1/6 — انقر جيب أعلى اليسار",
            "2/6 — انقر جيب أعلى اليمين",
            "3/6 — انقر جيب أسفل اليسار",
            "4/6 — انقر جيب أسفل اليمين",
            "5/6 — انقر الجيب الجانبي الأول",
            "6/6 — انقر الجيب الجانبي الثاني"
    };

    private final int screenWidth;
    private final int screenHeight;
    private final Listener listener;
    private final float[][] points = new float[6][2];
    private final Paint dim = new Paint();
    private final Paint marker = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint banner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int count;
    private long downAt;

    PocketCalibrationOverlay(Context context, int screenWidth, int screenHeight, Listener listener) {
        super(context);
        this.screenWidth = Math.max(1, screenWidth);
        this.screenHeight = Math.max(1, screenHeight);
        this.listener = listener;
        setFocusable(true);
        setFocusableInTouchMode(true);
        requestFocus();
        dim.setColor(Color.argb(44, 0, 0, 0));
        marker.setColor(Color.rgb(0, 229, 255));
        marker.setStyle(Paint.Style.STROKE);
        marker.setStrokeWidth(dp(3));
        banner.setColor(Color.argb(210, 15, 18, 20));
        text.setColor(Color.WHITE);
        text.setTextSize(dp(15));
        text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    }

    @Override protected void onDraw(Canvas canvas) {
        canvas.drawRect(0f, 0f, getWidth(), getHeight(), dim);
        for (int i = 0; i < count; i++) {
            float x = points[i][0] * screenWidth;
            float y = points[i][1] * screenHeight;
            canvas.drawCircle(x, y, dp(12), marker);
            canvas.drawText(Integer.toString(i + 1), x + dp(10), y - dp(10), text);
        }
        float pad = dp(14);
        float top = dp(16);
        float lineHeight = dp(22);
        String current = count < LABELS.length ? LABELS[count] : "اكتملت المعايرة";
        float width = Math.min(getWidth() - 2 * pad, text.measureText(current) + 2 * pad);
        canvas.drawRoundRect(pad, top, pad + width, top + lineHeight + dp(18), dp(10), dp(10), banner);
        canvas.drawText(current, pad + dp(10), top + lineHeight, text);
        canvas.drawText("انقر مطولاً أو اضغط رجوع للإلغاء", pad, getHeight() - dp(22), text);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            downAt = event.getEventTime();
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_UP) {
            if (event.getEventTime() - downAt >= 800L) {
                if (listener != null) listener.onCancel();
                return true;
            }
            if (count < points.length) {
                points[count][0] = clamp(event.getRawX() / screenWidth, 0f, 1f);
                points[count][1] = clamp(event.getRawY() / screenHeight, 0f, 1f);
                count++;
                invalidate();
                if (count == points.length && listener != null) {
                    float[][] copy = new float[points.length][2];
                    for (int i = 0; i < points.length; i++) {
                        copy[i][0] = points[i][0];
                        copy[i][1] = points[i][1];
                    }
                    postDelayed(() -> listener.onComplete(copy), 250L);
                }
            }
            return true;
        }
        return true;
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (listener != null) listener.onCancel();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static float clamp(float value, float low, float high) {
        return Math.max(low, Math.min(high, value));
    }
}
