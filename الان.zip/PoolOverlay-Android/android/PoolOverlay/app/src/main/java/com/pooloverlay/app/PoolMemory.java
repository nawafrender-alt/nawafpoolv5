package com.pooloverlay.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Private, bounded local history. It stores shot outcomes and model settings, never captured pixels. */
final class PoolMemory {
    private static final String PREFS = "pool";
    private static final String HISTORY = "shot_history_v1";
    private final SharedPreferences prefs;

    PoolMemory(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor e = prefs.edit();
        if (!prefs.contains("physics_friction")) e.putFloat("physics_friction", 0.984f);
        if (!prefs.contains("physics_rail")) e.putFloat("physics_rail", 0.82f);
        if (!prefs.contains("physics_ball")) e.putFloat("physics_ball", 0.94f);
        e.apply();
    }

    float friction() { return clamp(prefs.getFloat("physics_friction", 0.984f), 0.965f, 0.996f); }
    float railRestitution() { return clamp(prefs.getFloat("physics_rail", 0.82f), 0.68f, 0.96f); }
    float ballRestitution() { return clamp(prefs.getFloat("physics_ball", 0.94f), 0.86f, 0.99f); }

    /** Smooths prior success rates so one lucky or missed shot cannot dominate the ranking. */
    float reliabilityMultiplier(int type) {
        String key = "type_" + type + "_";
        int wins = prefs.getInt(key + "pots", 0), misses = prefs.getInt(key + "misses", 0);
        float rate = (wins + 2f) / (wins + misses + 4f);
        return 0.80f + 0.40f * rate;
    }

    void record(PoolPlanner.Plan plan, PoolVision.Scene before, PoolVision.Scene after) {
        if (plan == null || before == null || after == null || !before.ok || !after.ok || plan.target == null) return;
        int prior = countKind(before, plan.target.kind);
        int current = countKind(after, plan.target.kind);
        int removed = before.balls.size() - after.balls.size();
        if (prior <= 0) return;

        String outcome;
        String key = "type_" + plan.type + "_";
        SharedPreferences.Editor e = prefs.edit();
        if (removed == 1 && prior - current == 1) {
            e.putInt(key + "pots", prefs.getInt(key + "pots", 0) + 1);
            outcome = "pot";
        } else if (removed == 0 && prior == current) {
            e.putInt(key + "misses", prefs.getInt(key + "misses", 0) + 1);
            outcome = "miss";
        } else {
            e.putInt("ambiguous_results", prefs.getInt("ambiguous_results", 0) + 1);
            outcome = "uncertain";
        }

        if (!outcome.equals("uncertain")) PoolSimAI.learn(before, plan, outcome.equals("pot"), this);

        String old = prefs.getString(HISTORY, "");
        String row = System.currentTimeMillis() + "," + plan.type + "," + plan.power + ","
                + Math.round(plan.score * 100f) + "," + Math.round(plan.cx) + "," + Math.round(plan.cy) + ","
                + Math.round(plan.ox) + "," + Math.round(plan.oy) + "," + Math.round(plan.px) + ","
                + Math.round(plan.py) + "," + Math.round(plan.cut) + "," + outcome;
        String[] rows = old.isEmpty() ? new String[0] : old.split("\\n");
        StringBuilder history = new StringBuilder();
        int start = Math.max(0, rows.length - 31);
        for (int i = start; i < rows.length; i++) {
            if (!rows[i].isEmpty()) history.append(rows[i]).append('\n');
        }
        history.append(row);
        e.putString(HISTORY, history.toString()).apply();
    }

    // ---- weights of the on-device learner used by PoolSimAI (5 numbers + sample count, no pixels)
    int aiSamples() { return prefs.getInt("ai_n", 0); }

    float[] aiWeights() {
        float[] w = {1.6f, 1.2f, 1.6f, 1.6f, -2.6f};          // reach, clearance, validity, robustness, bias
        String t = prefs.getString("ai_w", "");
        if (t.isEmpty()) return w;
        String[] p = t.split(",");
        if (p.length != w.length) return w;
        try { for (int i = 0; i < w.length; i++) w[i] = Float.parseFloat(p[i]); } catch (NumberFormatException e) { return new float[]{1.6f, 1.2f, 1.6f, 1.6f, -2.6f}; }
        return w;
    }

    void saveAiWeights(float[] w, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < w.length; i++) { if (i > 0) sb.append(','); sb.append(w[i]); }
        prefs.edit().putString("ai_w", sb.toString()).putInt("ai_n", n).apply();
    }

    private static int countKind(PoolVision.Scene scene, int kind) {
        int n = 0;
        for (PoolVision.Ball b : scene.balls) if (b.kind == kind) n++;
        return n;
    }

    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
}
