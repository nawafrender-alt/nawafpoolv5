package com.pooloverlay.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Stores six manually tapped pocket centers as normalized display coordinates, locally only. */
final class PocketCalibrationStore {
    private static final String PREFS = "pool";
    private static final String KEY = "pocket_calibration_v1";
    private static final String ASPECT_KEY = "pocket_calibration_aspect_v1";

    private final SharedPreferences prefs;

    PocketCalibrationStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    boolean save(float[][] points, int screenWidth, int screenHeight) {
        if (points == null || points.length != 6 || screenWidth < 1 || screenHeight < 1) return false;
        StringBuilder serialized = new StringBuilder();
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null || points[i].length < 2
                    || !Float.isFinite(points[i][0]) || !Float.isFinite(points[i][1])
                    || points[i][0] < 0f || points[i][0] > 1f
                    || points[i][1] < 0f || points[i][1] > 1f) return false;
            if (i > 0) serialized.append(';');
            serialized.append(points[i][0]).append(',').append(points[i][1]);
        }
        float aspect = screenWidth / (float) screenHeight;
        prefs.edit().putString(KEY, serialized.toString()).putFloat(ASPECT_KEY, aspect).apply();
        return true;
    }

    float[][] load(int screenWidth, int screenHeight) {
        if (screenWidth < 1 || screenHeight < 1) return null;
        String raw = prefs.getString(KEY, null);
        if (raw == null) return null;
        float savedAspect = prefs.getFloat(ASPECT_KEY, 0f);
        float currentAspect = screenWidth / (float) screenHeight;
        if (savedAspect <= 0f || Math.abs(savedAspect - currentAspect) > 0.08f) return null;
        String[] entries = raw.split(";");
        if (entries.length != 6) return null;
        float[][] out = new float[6][2];
        try {
            for (int i = 0; i < entries.length; i++) {
                String[] pair = entries[i].split(",");
                if (pair.length != 2) return null;
                out[i][0] = Float.parseFloat(pair[0]);
                out[i][1] = Float.parseFloat(pair[1]);
                if (!Float.isFinite(out[i][0]) || !Float.isFinite(out[i][1])
                        || out[i][0] < 0f || out[i][0] > 1f || out[i][1] < 0f || out[i][1] > 1f) return null;
            }
        } catch (NumberFormatException e) {
            return null;
        }
        return out;
    }

    void clear() {
        prefs.edit().remove(KEY).remove(ASPECT_KEY).apply();
    }
}
