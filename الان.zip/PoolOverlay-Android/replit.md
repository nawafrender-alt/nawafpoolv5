# PoolOverlay Android

Native Android Java overlay that reads billiards screenshots locally and displays optional training guidance.

## Run & Operate

- Android project: `android/PoolOverlay`
- Build: `./android/PoolOverlay/gradlew --project-dir android/PoolOverlay testDebugUnitTest assembleDebug`
- Debug APK: `android/PoolOverlay/app/build/outputs/apk/debug/app-debug.apk`
- Requires Java 17 and Android SDK platform 34.
- No server, network API, or external service is used for frame analysis.

## Stack

- Java 17, Android Gradle Plugin 8.5.2, Gradle 8.7
- Android SDK compile/target 34; minimum SDK 26
- Screen capture: one MediaProjection, one VirtualDisplay, one ImageReader, and one reused frame Bitmap

## Where things live

- `android/PoolOverlay/app/src/main/java/com/pooloverlay/app` — Android UI, capture service, vision, geometry, planning, and local training history
- `android/PoolOverlay/app/src/test` — deterministic local JVM geometry tests
- `.github/workflows/pool-overlay-build.yml` — the single repository-level Android build workflow

## Architecture decisions

- Keep the existing Java package and single capture/overlay service; do not add the helper repository's second capture service.
- Frame analysis and pocket calibration remain on-device. Do not store or upload screen pixels.
- A plan's displayed score is a heuristic index, not a measured probability of success.
- One-bank geometry is supported; double-bank shots are not claimed.

## Product

- Optional local training guidance for billiards; users still perform the shot themselves.
- Preserve the existing floating controls and practice-only suggestions.

## User preferences

- Preserve `applicationId` and Java package `com.pooloverlay.app`.
- Keep processing local and do not inject game input or modify game memory.

## Gotchas

- MediaProjection consent is per session. Rotation must resize the existing VirtualDisplay rather than create a second one.
- Manual pocket points are normalized to display dimensions and are ignored when the display aspect ratio changes; recalibrate in that orientation.
- The overlay code has only been built/tested on Android devices if explicitly noted in the current delivery report.

## Pointers

- `android/PoolOverlay/README_AR.md` — build steps, behavior, limitations, and license audit
